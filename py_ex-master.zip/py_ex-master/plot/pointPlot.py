import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

import random



mpl.rcParams['legend.fontsize'] = 20
fig = plt.figure()
ax = fig.gca(projection='3d')

x = np.array([random.randint(0, 10) for _ in range(10)])
y = np.array([random.randint(0, 100) for _ in range(10)])
b = np.array([5]*10)

z = 3 * x + 4 * y + b

ax.scatter(x, y, z, c='r', marker='o')
ax.legend()

plt.show()
