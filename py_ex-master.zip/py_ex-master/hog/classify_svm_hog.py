from sklearn import svm
import sklearn
import numpy as np
data = np.random.randint(0,100,100)
data = np.reshape(data, (20,5))
label = np.random.randint(0,3,20)
label = np.expand_dims(label, axis=0)
label = np.transpose(label)

train_data,test_data,train_label,test_label =sklearn.model_selection.train_test_split(data,label, random_state=1, train_size=0.6,test_size=0.4)
classifier=svm.SVC(C=2,kernel='rbf',gamma=10,decision_function_shape='ovr')
classifier.fit(train_data,train_label.ravel())
print("训练集：",classifier.score(train_data,train_label))
print("测试集：",classifier.score(test_data,test_label))