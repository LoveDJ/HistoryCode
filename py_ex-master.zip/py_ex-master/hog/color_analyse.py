import cv2 as cv
import numpy as np
import os


# 循环计算每个图片色调的均值
# color_mean_arr1 = [] # 存放所有图片色调的均值
# dir_path = r'F:\code\c\images\SEM'
# for root, dirs, files in os.walk(dir_path):
#     for file in files:
#         file_path = os.path.join(dir_path, file)
#         img = cv.imread(file_path)
#         img = cv.cvtColor(img, cv.COLOR_BGR2HSV)
#         h_mean = np.mean(img[:,:,0])
#         color_mean_arr1.append(h_mean)
# color_mean_arr1 = np.array(color_mean_arr1)
# color1_mean = np.mean(color_mean_arr1)
# color1_std = np.std(color_mean_arr1)
# print('SEM颜色1 mean = %.5f std = %.5f'%(color1_mean, color1_std))
#
# dir_path = r'F:\code\c\images\AFM'
# color_mean_arr2 = []
# for root, dirs, files in os.walk(dir_path):
#     for file in files:
#         file_path = os.path.join(dir_path, file)
#         img = cv.imread(file_path)
#         img = cv.cvtColor(img, cv.COLOR_BGR2HSV)
#         h_mean = np.mean(img[:,:,0])
#         color_mean_arr2.append(h_mean)
# color_mean_arr2 = np.array(color_mean_arr2)
# color2_mean = np.mean(color_mean_arr2)
# color2_std = np.std(color_mean_arr2)
# print('AFM颜色2 mean = %.5f std = %.5f'%(color2_mean, color2_std))
#
# dir_path = r'F:\code\c\images\SAXS'
# color_mean_arr3 = []
# for root, dirs, files in os.walk(dir_path):
#     for file in files:
#         file_path = os.path.join(dir_path, file)
#         img = cv.imread(file_path)
#         img = cv.cvtColor(img, cv.COLOR_BGR2HSV)
#         h_mean = np.mean(img[:,:,0])
#         color_mean_arr3.append(h_mean)
# color_mean_arr3 = np.array(color_mean_arr3)
# color3_mean = np.mean(color_mean_arr3)
# color3_std = np.std(color_mean_arr3)
# print('SAXS颜色3 mean = %.5f std = %.5f'%(color3_mean, color3_std))

dir_path = r'E:\code\c\images\WAXD'
color_mean_arr4 = []
for root, dirs, files in os.walk(dir_path):
    for file in files:
        file_path = os.path.join(dir_path, file)
        img = cv.imread(file_path)
        img = cv.cvtColor(img, cv.COLOR_BGR2HSV)
        h_mean = np.mean(img[:,:,0])
        color_mean_arr4.append(h_mean)
color_mean_arr4 = np.array(color_mean_arr4)
color4_mean = np.mean(color_mean_arr4)
color4_std = np.std(color_mean_arr4)
print('WAXD颜色4 mean = %.5f std = %.5f'%(color4_mean, color4_std))




'''
结果：
SEM颜色1 mean = 0.00000 std = 0.00000
AFM颜色2 mean = 7.27689 std = 0.26853
SAXS颜色3 mean = 64.97992 std = 0.43129
WAXD颜色4 mean = 3.69587 std = 0.34202 仅测试了三张图片
'''