import cv2
import numpy as np
import math
import matplotlib.pyplot as plt
import os
from sklearn import svm
import sklearn

class Hog_descriptor():
    def __init__(self, img, cell_size=16, bin_size=9):
        self.img = img
        # self.img = np.sqrt(img / np.max(img))
        # self.img = img * 255
        self.cell_size = cell_size
        self.bin_size = bin_size
        self.angle_unit = int(360/ self.bin_size)

        assert type(self.bin_size) == int, "bin_size should be integer,"
        assert type(self.cell_size) == int, "cell_size should be integer,"
        assert type(self.angle_unit) == int, "bin_size should be divisible by 360"

    def extract(self):
        height, width = self.img.shape
        gradient_magnitude, gradient_angle = self.global_gradient()
        gradient_magnitude = abs(gradient_magnitude)
        cell_gradient_vector = np.zeros((int(height / self.cell_size), int(width / self.cell_size), int(self.bin_size)))
        for i in range(cell_gradient_vector.shape[0]):
            for j in range(cell_gradient_vector.shape[1]):
                cell_magnitude = gradient_magnitude[i * self.cell_size:(i + 1) * self.cell_size,
                                 j * self.cell_size:(j + 1) * self.cell_size]
                cell_angle = gradient_angle[i * self.cell_size:(i + 1) * self.cell_size,
                             j * self.cell_size:(j + 1) * self.cell_size]
                cell_gradient_vector[i][j] = self.cell_gradient(cell_magnitude, cell_angle)

        hog_vector = cell_gradient_vector.sum(axis=0)
        hog_vector = hog_vector.sum(axis=0)
        return hog_vector

    def global_gradient(self):
        gradient_values_x = cv2.Sobel(self.img, cv2.CV_64F, 1, 0, ksize=5)
        gradient_values_y = cv2.Sobel(self.img, cv2.CV_64F, 0, 1, ksize=5)
        gradient_magnitude = cv2.addWeighted(gradient_values_x, 0.5, gradient_values_y, 0.5, 0)
        gradient_angle = cv2.phase(gradient_values_x, gradient_values_y, angleInDegrees=True)
        return gradient_magnitude, gradient_angle

    def cell_gradient(self, cell_magnitude, cell_angle):
        orientation_centers = [0] * self.bin_size
        for i in range(cell_magnitude.shape[0]):
            for j in range(cell_magnitude.shape[1]):
                gradient_strength = cell_magnitude[i][j]
                gradient_angle = cell_angle[i][j]
                min_angle, max_angle, mod = self.get_closest_bins(gradient_angle)
                orientation_centers[min_angle] += (gradient_strength * (1 - (mod / self.angle_unit)))
                orientation_centers[max_angle] += (gradient_strength * (mod / self.angle_unit))
        return orientation_centers

    def get_closest_bins(self, gradient_angle):
        idx = int(gradient_angle / self.angle_unit)
        mod = gradient_angle % self.angle_unit
        return idx, (idx + 1) % self.bin_size, mod


dir_path = '../data/AFM/'
label_arr = []
hog_arr = []
hog_arr_1 = []
for root, dirs, files in os.walk(dir_path):
    for file_name in files:
        file_path = os.path.join(root, file_name)
        label_arr.append(file_name[0])
        img = cv2.imdecode(np.fromfile(file_path, dtype=np.uint8), cv2.IMREAD_GRAYSCALE)
        hog = Hog_descriptor(img, cell_size=8, bin_size=9)
        vector = hog.extract()
        if file_name[0]=='S':
            hog_arr.append(vector)
        elif file_name[0]=='X':
            hog_arr_1.append(vector)
label_arr = np.array(label_arr)
hog_arr = np.array(hog_arr)
hog_arr_1 = np.array(hog_arr_1)

print(hog_arr[:,0])
print(hog_arr[:,1])
print(hog_arr_1[:,0])
print(hog_arr_1[:,1])

plt.xlabel('feature0')
plt.ylabel('feature1')
plt.legend()
plt.scatter(hog_arr[:,2], hog_arr[:,4], s=20, c="#ff1212", marker='o')
plt.scatter(hog_arr_1[:,2], hog_arr_1[:,4], s=20, c="b", marker='v')
plt.show()






# train_data,test_data,train_label,test_label =sklearn.model_selection.train_test_split(hog_arr,label_arr, random_state=1, train_size=0.6,test_size=0.4)
# classifier=svm.SVC(C=2,kernel='rbf',gamma=10,decision_function_shape='ovr')
# classifier.fit(train_data,train_label.ravel())
# print("训练集：",classifier.score(train_data,train_label))
# print("测试集：",classifier.score(test_data,test_label))
