#include <iostream>
#include <vector>
#include <io.h>
#include "opencv2/core.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/videoio.hpp"
#include <opencv2/ml.hpp>
#include "svm.h"
#include "glcm.h"
#define Malloc(type,n) (type *)malloc((n)*sizeof(type))
using namespace std;
using namespace cv;

void extract_hog(Mat img, float* hog, int cell_size = 8, int bin_size = 9)
{
	int height = img.rows;
	int width = img.cols;

	Mat dst_x, dst_y, gradient_magnitude, gradient_angle;
	Sobel(img, dst_x, CV_64FC1, 1, 0, 5);
	Sobel(img, dst_y, CV_64FC1, 0, 1, 5);

	addWeighted(dst_x, 0.5, dst_y, 0.5, 0, gradient_magnitude);


	phase(dst_x, dst_y, gradient_angle, true);
	gradient_magnitude = abs(gradient_magnitude);

	int x_shape = height / cell_size;
	int y_shape = width / cell_size;
	int z_shape = bin_size;
	float*** cell_gradient_vector = new float** [x_shape];
	for (int n = 0; n < x_shape; n++)
	{
		cell_gradient_vector[n] = new float* [y_shape];
	}//Ҫ�ȶԶ�ά�����趨��С


	for (int i = 0; i < x_shape; i++)
	{
		for (int j = 0; j < y_shape; j++)
		{
			cell_gradient_vector[i][j] = new float[z_shape];
			for (int k = 0; k < z_shape; k++)
			{
				cell_gradient_vector[i][j][k] = 0;
			}

		}//֮����ܶ���ά�����趨��С�������ڴ����
	}

	float** cell_magnitude = new float* [cell_size];
	for (int i = 0; i < cell_size; i++) {
		cell_magnitude[i] = new float[cell_size];
	}
	float** cell_angle = new float* [cell_size];
	for (int i = 0; i < cell_size; i++) {
		cell_angle[i] = new float[cell_size];
	}

	for (int i = 0; i < cell_size; i++)
	{
		for (int j = 0; j < cell_size; j++)
		{
			cell_magnitude[i][j] = 0.0;
			cell_angle[i][j] = 0.0;
		}
	}

	//cell_gradient_vector��ֵ
	for (int i = 0; i < x_shape; i++)
	{
		for (int j = 0; j < y_shape; j++)
		{
			for (int k = 0; k < cell_size; k++) {
				for (int v = 0; v < cell_size; v++) {
					cell_magnitude[k][v] = gradient_magnitude.at<double>(i * cell_size + k, j * cell_size + v);
					cell_angle[k][v] = gradient_angle.at<double>(i * cell_size + k, j * cell_size + v);
				}
			}


			for (int k = 0; k < cell_size; k++)
			{
				for (int v = 0; v < cell_size; v++)
				{
					float gradient_strength = cell_magnitude[k][v];
					int gradient_angle = cell_angle[k][v];
					int min_angle = gradient_angle / 40;
					int max_angle = (min_angle + 1) % 40;
					float mod = gradient_angle % 40;
					cell_gradient_vector[i][j][min_angle] += (gradient_strength * (1 - (mod / 40)));
					cell_gradient_vector[i][j][max_angle] += (gradient_strength * (mod / 40));
				}
			}

		}



	}


	for (int k = 0; k < z_shape; k++)
	{
		for (int i = 0; i < x_shape; i++)
		{
			for (int j = 0; j < y_shape; j++)
			{
				hog[k] += cell_gradient_vector[i][j][k];
			}
		}
	}


}

void extract_glcm(Mat img, float* glcm_fea)
{
	GLCM glcm;
	TextureEValues EValues;
	Mat dstChannel;
	glcm.getOneChannel(img, dstChannel, CHANNEL_B);
	glcm.GrayMagnitude(dstChannel, dstChannel, GRAY_8);
	glcm.CalcuTextureEValue(dstChannel, EValues, 5, GRAY_8);
	cout << "Image's Texture EValues:" << endl;
	cout << "    Contrast: " << EValues.contrast << endl;
	cout << "    Energy: " << EValues.energy << endl;
	cout << "    EntropyData: " << EValues.entropy << endl;
	cout << "    Homogenity: " << EValues.homogenity << endl;
	glcm_fea[0] = EValues.contrast;
	glcm_fea[1] = EValues.energy;
	glcm_fea[2] = EValues.entropy;
	glcm_fea[3] = EValues.homogenity;
}

int trainHOG()
{
	int cell_size = 8, bin_size = 9;
	string dir_path = "../data/AFM/";
	string inPath = "../data/AFM/*.png";
	string output_file = "./1.txt";


	//***********************�����ļ�����*********************
	int file_num = 0;
	intptr_t handle;
	struct _finddata_t fileinfo;
	handle = _findfirst(inPath.c_str(), &fileinfo);
	if (handle == -1)
		return -1;
	do
	{
		file_num++;
	} while (!_findnext(handle, &fileinfo));
	_findclose(handle);
	//*******************************************************

	//***********************�������ݼ�********************
	int* label_arr = new int[file_num];
	float** hog_arr = new float* [file_num];
	for (int i = 0; i < file_num; i++)
	{
		hog_arr[i] = new float[bin_size];
	}
	for (int i = 0; i < file_num; i++)
	{
		for (int j = 0; j < bin_size; j++)
		{
			hog_arr[i][j] = 0.0;
		}
	}

	int count = 0;
	handle = _findfirst(inPath.c_str(), &fileinfo);
	if (handle == -1)
		return -1;

	do
	{
		//�ҵ����ļ����ļ���
		//printf("%s\n", fileinfo.name);
		string s = fileinfo.name;
		int label = 1;
		if (s[0] == 'S')
		{
			label = -1;
		}
		/*if (s[0] == 'C')
		{
			label = 2;
		}*/
		label_arr[count] = label;
		Mat src = imread(dir_path + fileinfo.name);
		Mat img;
		cvtColor(src, img, CV_BGR2GRAY);
		float* hog = new float[bin_size];
		for (int i = 0; i < bin_size; i++)
		{
			hog[i] = 0.0;
		}
		extract_hog(img, hog);

		hog_arr[count++] = hog;

	} while (!_findnext(handle, &fileinfo));

	_findclose(handle);
	//***************************************************


	//******************����SVMģ��**********************
	svm_problem problem;
	problem.l = file_num;
	problem.y = Malloc(double, problem.l);
	problem.x = Malloc(struct svm_node*, problem.l);
	struct svm_node* x_space;
	x_space = Malloc(struct svm_node, 10 * file_num);
	int j = 0;
	for (int l = 0; l < file_num; l++)
	{
		problem.x[l] = &x_space[j];
		for (int d = 0; d < 9; d++)
		{
			x_space[j].index = d + 1;
			x_space[j].value = hog_arr[l][d];
			j++;
		}
		x_space[j++].index = -1;
		problem.y[l] = label_arr[l];
	}


	svm_parameter param{ C_SVC, RBF, 0, 10, 0, 100, 1e-6, 2, 0, nullptr, nullptr, 0.5, 0.1, 1, 1 };

	svm_model * model = svm_train(&problem, &param);

	if (svm_save_model(output_file.c_str(), model)) {
		std::cerr << "Save SVM to [" << output_file << "] FAILED" << std::endl;
	}
	else {
		std::cout << "Save SVM to [" << output_file << "] SUCCEED." << std::endl;
	}

	double* prob = new double[model->nr_class];
	for (int i = 0; i < model->nr_class; i++)
	{
		prob[i] = 1;
	}
	for (int i = 0; i < file_num; i++)
	{
		double a = svm_predict_probability(model, problem.x[i], prob);
		cout << problem.y[i] << " " << endl;
		cout << a << endl;
		//cout << prob[0] << " " << prob[1]  << endl;
	}
	//*************************************************************


}


int trainGLCM()
{
	string dir_path = "../data/AFM/";
	string inPath = "../data/AFM/*.png";
	string output_file = "./1.txt";
	int feaNum = 4;
	//***********************�����ļ�����*********************
	cout << "start calculate file number..."<< endl;
	int file_num = 0;
	intptr_t handle;
	struct _finddata_t fileinfo;
	handle = _findfirst(inPath.c_str(), &fileinfo);
	if (handle == -1)
		return -1;
	do
	{
		file_num++;
	} while (!_findnext(handle, &fileinfo));
	_findclose(handle);
	//*******************************************************

	//***********************�������ݼ�********************
	cout << "start generate data set..." << endl;
	int* label_arr = new int[file_num];
	float** glcm_arr = new float* [file_num];
	for (int i = 0; i < file_num; i++)
	{
		glcm_arr[i] = new float[feaNum];
	}
	for (int i = 0; i < file_num; i++)
	{
		for (int j = 0; j < feaNum; j++)
		{
			glcm_arr[i][j] = 0.0;
		}
	}

	int count = 0;
	handle = _findfirst(inPath.c_str(), &fileinfo);
	if (handle == -1)
		return -1;

	do
	{
		string s = fileinfo.name;
		cout << "start generate file " + s << endl;

		int label = 0;
		if (s[0] == 'X')
		{
			label = 1;
		}
		if (s[0] == 'C')
		{
			label = 2;
		}
		label_arr[count] = label;
		Mat src = imread(dir_path + fileinfo.name);
		Mat img;
		cvtColor(src, img, CV_BGR2GRAY);
		float* glcm_fea = new float[feaNum];
		for (int i = 0; i < feaNum; i++)
		{
			glcm_fea[i] = 0.0;
		}
		extract_glcm(img, glcm_fea);

		glcm_arr[count++] = glcm_fea;

	} while (!_findnext(handle, &fileinfo));

	_findclose(handle);
	//***************************************************

	//******************����SVMģ��**********************
	cout << "start create SVM model..." << endl;
	svm_problem problem;
	problem.l = file_num;
	problem.y = Malloc(double, problem.l);
	problem.x = Malloc(struct svm_node*, problem.l);
	struct svm_node* x_space;
	x_space = Malloc(struct svm_node, (feaNum+1) * file_num);
	int j = 0;
	for (int l = 0; l < file_num; l++)
	{
		problem.x[l] = &x_space[j];
		for (int d = 0; d < feaNum; d++)
		{
			x_space[j].index = d + 1;
			x_space[j].value = glcm_arr[l][d];
			j++;
		}
		x_space[j++].index = -1;
		problem.y[l] = label_arr[l];
	}


	svm_parameter param{ C_SVC, RBF, 0, 10, 0, 100, 1e-6, 2, 0, nullptr, nullptr, 0.5, 0.1, 1, 1 };

	auto model = svm_train(&problem, &param);

	if (svm_save_model(output_file.c_str(), model)) {
		std::cerr << "Save SVM to [" << output_file << "] FAILED" << std::endl;
	}
	else {
		std::cout << "Save SVM to [" << output_file << "] SUCCEED." << std::endl;
	}

	double* prob = new double[2];
	for (int i = 0; i < 2; i++)
	{
		prob[i] = 1;
	}
	for (int i = 0; i < file_num; i++)
	{
		double a = svm_predict_probability(model, problem.x[i], prob);

		cout << a << endl;
	}
	//*************************************************************

}

int trainALL()
{
	int cell_size = 8, bin_size = 9;
	int fea_num = 9 + 4;
	string dir_path = "../data/SEM/";
	string inPath = "../data/SEM/*.tif";
	string output_file = "./sem.model";


	//***********************�����ļ�����*********************
	int file_num = 0;
	intptr_t handle;
	struct _finddata_t fileinfo;
	handle = _findfirst(inPath.c_str(), &fileinfo);
	if (handle == -1)
		return -1;
	do
	{
		file_num++;
	} while (!_findnext(handle, &fileinfo));
	_findclose(handle);
	//*******************************************************

	//***********************�������ݼ�********************
	int* label_arr = new int[file_num];
	float** fea_arr = new float* [file_num];
	for (int i = 0; i < file_num; i++)
	{
		fea_arr[i] = new float[fea_num];
	}
	for (int i = 0; i < file_num; i++)
	{
		for (int j = 0; j < fea_num; j++)
		{
			fea_arr[i][j] = 0.0;
		}
	}

	int count = 0;
	handle = _findfirst(inPath.c_str(), &fileinfo);
	if (handle == -1)
		return -1;

	do
	{
		//�ҵ����ļ����ļ���
		//printf("%s\n", fileinfo.name);
		string s = fileinfo.name;
		cout << "start generate file " + s << endl;
		int label = 0;
		if (s[0] == 'X')
		{
			label = 10;
		}
		if (s[0] == 'S')
		{
			label = 13;
		}
		label_arr[count] = label;
		Mat src = imread(dir_path + fileinfo.name);
		Mat img;
		cvtColor(src, img, CV_BGR2GRAY);
		float* hog = new float[bin_size];
		for (int i = 0; i < bin_size; i++)
		{
			hog[i] = 0.0;
		}
		extract_hog(img, hog);
		float* glcm_fea = new float[4];
		for (int i = 0; i < 4; i++)
		{
			glcm_fea[i] = 0.0;
		}
		extract_glcm(img, glcm_fea);
		//����ƴ��
		int a, b;
		for (a = 0; a < 9; a++)
			fea_arr[count][a] = hog[a];
		for (b = 0; b < 4; b++, a++)
			fea_arr[count][a] = glcm_fea[b];
		for (int xxx = 0; xxx < 13; xxx++)
			cout << fea_arr[count][xxx] << " ";
		cout << endl;
		count++;
	} while (!_findnext(handle, &fileinfo));

	_findclose(handle);
	//***************************************************

	//******************����SVMģ��**********************
	svm_problem problem;
	problem.l = file_num;
	problem.y = Malloc(double, problem.l);
	problem.x = Malloc(struct svm_node*, problem.l);
	struct svm_node* x_space;
	x_space = Malloc(struct svm_node, 14 * file_num);
	int j = 0;
	for (int l = 0; l < file_num; l++)
	{
		problem.x[l] = &x_space[j];
		for (int d = 0; d < 13; d++)
		{
			x_space[j].index = d + 1;
			x_space[j].value = fea_arr[l][d];
			j++;
		}
		x_space[j++].index = -1;
		problem.y[l] = label_arr[l];
	}


	svm_parameter param{ C_SVC, RBF, 0, 10, 0, 100, 1e-6, 2, 0, nullptr, nullptr, 0.5, 0.1, 1, 1 };

	svm_model* model = svm_train(&problem, &param);

	if (svm_save_model(output_file.c_str(), model)) {
		std::cerr << "Save SVM to [" << output_file << "] FAILED" << std::endl;
	}
	else {
		std::cout << "Save SVM to [" << output_file << "] SUCCEED." << std::endl;
	}

	double* prob = new double[model->nr_class];
	for (int i = 0; i < model->nr_class; i++)
	{
		prob[i] = 1;
	}
	for (int i = 0; i < file_num; i++)
	{
		double a = svm_predict_probability(model, problem.x[i], prob);

		cout << a << endl;
		cout << prob[0] << " " << prob[1] << endl;
	}
	//*************************************************************


}

int main() {

	trainALL();
}