import numpy as np
import gurobipy as gp
from gurobipy import GRB
from sklearn import metrics
import random
from PointToPlane import leastSquareMethod as lsm
from PointToPlane import corrFitMethod
from PointToPlane import Utils
from PointToPlane import ransac_v2 as ransac
from PointToPlane import rpca as rpca
import matlab.engine
import warnings
import matplotlib.pyplot as plt
warnings.filterwarnings("ignore")

eng = matlab.engine.start_matlab()
methods = ['LSM', 'OUR METHOD', 'S2R3', 'RANSAC', 'RPCA', 'M-estimator', 'DPCP_PSGM']

all_points = Utils.readxyz('../data/fitting/plane2.txt')
points_num = len(all_points)
X = all_points[:, 0]
Y = all_points[:, 1]
Z = all_points[:, 2]

thd_dist = 0.05
raw_points = all_points.copy()
all_points2 = all_points.copy()
all_points3 = all_points.copy()

#mestimator
lista = all_points[:,0:2].tolist()
lista = matlab.double(lista)
listb = all_points[:,2].tolist()
listb = matlab.double(listb)
w6 = eng.robustfit(lista, listb, 'huber')
w6 = Utils.normc([-w6[1][0], -w6[2][0], 1, w6[0][0]])
if w6[0] < 0:
    w6 = -w6

#dpcp_psgm
temp_points = np.vstack((np.transpose(all_points), np.ones(points_num))) # 4*points_num
X_tilde = Utils.normc(temp_points)
X_tilde = matlab.double(X_tilde.tolist())
beta = 1 / 2
w7 = eng.DPCP_PSGM_optim_J(X_tilde, 1, 1e-9, beta, 500, 1e-6)
w7 = np.array([w7[0][0], w7[1][0], w7[2][0], -w7[3][0]])
if w7[0] < 0:
    w7 = -w7
#rpca
A = rpca.alternating_direction_method_of_multipliers(all_points, lmbda=1)
w5 = lsm.leastSquare(A[0])
w5 = Utils.normc(w5)


# s2r2拟合结果
a3 = 0
b3 = 0
c3 = 0
d3 = 0
w = np.ones(points_num)
epcho = 1
for s in range(epcho):

    m = gp.Model("demo2")
    r_arr = []
    for i in range(3):
        r_arr.append(m.addVar(lb=-1e20, vtype=GRB.CONTINUOUS, name="r" + str(i)))

    ri_arr = [[] for i in range(points_num)]
    for i in range(points_num):
        for j in range(3):
            ri_arr[i].append(m.addVar(lb=-1e20, vtype=GRB.CONTINUOUS, name="ri" + str(i) + str(j)))
    z_arr = {}
    for i in range(points_num):
        z_arr[i] = m.addVar(lb=-1e20, vtype=GRB.CONTINUOUS, name="z" + str(i))

    m.setObjective((gp.quicksum(z_arr[z] for z in z_arr)), GRB.MINIMIZE)

    for i in range(points_num):
        for j in range(3):
            m.addConstr(z_arr[i] >= w[i] * (r_arr[j] - ri_arr[i][j]), name="c0" + str(i) + str(j))
            m.addConstr(z_arr[i] >= w[i] * (ri_arr[i][j] - r_arr[j]), name="c1" + str(i) + str(j))
        m.addConstr((X[i] * ri_arr[i][0] + Y[i] * ri_arr[i][1] + ri_arr[i][2] - Z[i]) <= 0.025, name="c2" + str(i))
        m.addConstr((X[i] * ri_arr[i][0] + Y[i] * ri_arr[i][1] + ri_arr[i][2] - Z[i]) >= -0.025, name="c3" + str(i))

    m.optimize()
    for j in range(points_num):
        for v in m.getVars():
            if v.varName == "z" + str(j):
                w[j] = 1 / (v.x + 0.05)

    if s == epcho - 1:
        for v in m.getVars():
            if v.varName == "r0":
                a3 = -v.x
                print('%s %g' % (v.varName, v.x))
            if v.varName == "r1":
                b3 = -v.x
                print('%s %g' % (v.varName, v.x))
            if v.varName == "r2":
                d3 = v.x
                print('%s %g' % (v.varName, v.x))
            c3 = 1

w3 = Utils.normc([a3, b3, c3, d3])
if w3[0]<0:
    w3 = -w3


# 相关性方法拟合
corr = Utils.Corr3(all_points2)
delete_num = int(0.03 * points_num)
for i in range(8):
    rmIndexArr = Utils.Corr3_delete(all_points2[:, 0], all_points2[:, 1], all_points2[:, 2], delete_num)
    del_points = all_points2[rmIndexArr]
    all_points2 = np.delete(all_points2, rmIndexArr, axis=0)
    corr = Utils.Corr3(all_points2)
w2 = corrFitMethod.Fit(all_points2)
w2 = Utils.normc(w2)

# ransac
w4_arr = []
for i in range(100):
    w4 = ransac.ransac(all_points3, distThd=thd_dist, iterNum=50)
    w4 = Utils.normc(w4)
    w4_arr.append(w4)
w4 = np.mean(w4_arr, axis=0)

print('corr result：a=%.5f b=%.5f c=%.5f d=%.5f' % (w2[0], w2[1], w2[2], w2[3]))
print('s2r2 result：a=%.5f b=%.5f c=%.5f d=%.5f' % (w3[0], w3[1], w3[2], w3[3]))
print('ransac result：a=%.5f b=%.5f c=%.5f d=%.5f' % (w4[0], w4[1], w4[2], w4[3]))
print('rpca result：a=%.5f b=%.5f c=%.5f d=%.5f' % (w5[0], w5[1], w5[2], w5[3]))
print('m-estimator result：a=%.5f b=%.5f c=%.5f d=%.5f' % (w6[0], w6[1], w6[2], w6[3]))
print('dpsp_psgm result：a=%.5f b=%.5f c=%.5f d=%.5f' % (w7[0], w7[1], w7[2], w7[3]))


n2 = np.array([w2[0], w2[1], w2[2]])
n3 = np.array([w3[0], w3[1], w3[2]])
n4 = np.array([w4[0], w4[1], w4[2]])
n5 = np.array([w5[0], w5[1], w5[2]])
n6 = np.array([w6[0], w6[1], w6[2]])
n7 = np.array([w7[0], w7[1], w7[2]])
dist2 = np.abs((np.matmul(n2, raw_points.T)-w2[3])/np.sqrt(np.sum(n2**2)))
dist3 = np.abs((np.matmul(n3, raw_points.T)-w3[3])/np.sqrt(np.sum(n3**2)))
dist4 = np.abs((np.matmul(n4, raw_points.T)-w4[3])/np.sqrt(np.sum(n4**2)))
dist5 = np.abs((np.matmul(n5, raw_points.T)-w5[3])/np.sqrt(np.sum(n5**2)))
dist6 = np.abs((np.matmul(n6, raw_points.T)-w6[3])/np.sqrt(np.sum(n6**2)))
dist7 = np.abs((np.matmul(n7, raw_points.T)-w7[3])/np.sqrt(np.sum(n7**2)))


inlier_rate2 = len(np.where(dist2<thd_dist)[0])/points_num
inlier_rate3 = len(np.where(dist3<thd_dist)[0])/points_num
inlier_rate4 = len(np.where(dist4<thd_dist)[0])/points_num
inlier_rate5 = len(np.where(dist5<thd_dist)[0])/points_num
inlier_rate6 = len(np.where(dist6<thd_dist)[0])/points_num
inlier_rate7 = len(np.where(dist7<thd_dist)[0])/points_num

print('corr method = %.5f', inlier_rate2)
print('s2r3 = %.5f', inlier_rate3)
print('ransac = %.5f', inlier_rate4)
print('rpca = %.5f', inlier_rate5)
print('m-estimator = %.5f', inlier_rate6)
print('dpcp_psgm = %.5f', inlier_rate7)
Utils.showPoints(raw_points[np.where(dist2<thd_dist)[0]])
Utils.showPoints(raw_points[np.where(dist3<thd_dist)[0]])
Utils.showPoints(raw_points[np.where(dist4<thd_dist)[0]])
Utils.showPoints(raw_points[np.where(dist5<thd_dist)[0]])
Utils.showPoints(raw_points[np.where(dist6<thd_dist)[0]])
Utils.showPoints(raw_points[np.where(dist7<thd_dist)[0]])
