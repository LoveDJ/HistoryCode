import numpy as np
import pandas as pd
import time
from PointToPlane import Utils
sTime = time.time()
delete_num = 10
points = Utils.readxyz('../data/fitting/plane1.txt')
N = len(points)

x = points[:, 0]
y = points[:, 1]
z = points[:, 2]
for _ in range(10):
    w_array = np.zeros(N)
    for i in range(N):
        temp_points = np.delete(points, i, axis=0)
        df = pd.DataFrame(temp_points)
        R = df.corr().values
        w_array[i] = np.linalg.det(R)
    indexC = np.argsort(w_array)
    delIndexArr = indexC[0:delete_num]
    N = N - delete_num
    points = np.delete(points, delIndexArr, axis=0)
eTime = time.time()
print('耗时%.5f'%(eTime-sTime))