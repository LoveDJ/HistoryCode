"""

https://blog.csdn.net/qq_27606639/article/details/80912071
https://blog.csdn.net/qq_37616069/article/details/80813059
"""

import numpy as np
import os
import random
import math
from PointToPlane import Utils

def addPNoise():
    noise_factor = 0.5
    mean_factor = 14

    L = math.exp(-noise_factor * mean_factor)
    p = 1
    k = 0
    while p >= L:
        k += 1
        p *= random.random()

    noise = (k-1)/mean_factor - noise_factor
    return noise

def calSNR(image, noise):
    im_var = np.var(image)
    noise_var = np.var(noise)
    snr = 10 * np.log10(im_var/noise_var)
    return snr

for i in range(10):
    ply_path = '../data/scanNet/scene000'+str(i)+'_00_vh_clean_2.labels.ply'
    points = Utils.readMesh(ply_path)
    SNR = 20
    x_var = np.var(points[:, 0])
    sigma = np.sqrt(x_var / np.power(10, 0.1 * SNR))
    np.random.seed(i)
    # add gaussian noise
    # mu = 0
    # np.random.seed(i)
    # noise_x = np.random.normal(mu, sigma, size=len(points))

    # add poisson noise
    # noise_x = np.random.poisson(sigma**2, size=len(points))
    # snr = calSNR(points[:, 0], noise_x)
    # print('snr = %.2f' % (snr))

    # add uniform noise
    # low = -np.sqrt(3) * sigma
    # high = np.sqrt(3) * sigma
    # noise_x = np.random.uniform(low, high, size=len(points))
    # snr = calSNR(points[:, 0], noise_x)
    # print('snr = %.2f' % (snr))

    # add rayleigh noise
    scale = sigma / np.sqrt((4-math.pi)/2)
    noise_x = np.random.rayleigh(scale, size=len(points))
    noise_x = noise_x - np.mean(noise_x)
    print(np.mean(noise_x))

    snr = calSNR(points[:, 0], noise_x)
    print('snr = %.2f' % (snr))



    points[:, 0] = points[:, 0] + noise_x

    Utils.writePoints(points, '../data/scanNet_rayleigh_noise/'+str(i)+'_rayleigh_noise.ply', color=False)


