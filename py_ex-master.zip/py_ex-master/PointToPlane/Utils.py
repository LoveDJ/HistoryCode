'''
describe:utils
author:dingjian
date:2019-09-29
'''
from plyfile import PlyData
import numpy as np
import math
import os
import random
import pandas as pd
import matplotlib as mpl
from matplotlib import cm
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import warnings


def readMesh(plyPath, step=1):
    plydata = PlyData.read(plyPath)
    vertices = plydata['vertex']
    points = np.stack([vertices['x'], vertices['y'], vertices['z']], axis=1)

    newPoints = []
    for i in range(int(len(points) / step)):
        newPoints.append(points[i * step])
    newPoints = np.array(newPoints)
    return newPoints

def readxyz(plypath):
    with open(plypath, 'r') as f:
        lines = f.readlines()
    points = np.zeros((len(lines),3))
    row = 0
    for line in lines:
        line = line.strip().split()
        points[row, :] = line[:]
        row += 1
    return points
# calculate correlation of 3 vectors
def Corr3_old(points):
    pointX = points[:, 0]
    pointY = points[:, 1]
    pointZ = points[:, 2]

    Rxy = np.corrcoef(pointX, pointY)
    Rxz = np.corrcoef(pointX, pointZ)
    Ryz = np.corrcoef(pointY, pointZ)

    Rxy = Rxy[0][1]
    Rxz = Rxz[0][1]
    Ryz = Ryz[0][1]
    if np.isnan(Rxy) or np.isnan(Rxz) or np.isnan(Ryz):
        Rxyz = 1
    else:
        Rxyz = np.sqrt(math.pow(Rxy, 2) + math.pow(Rxz, 2) + math.pow(Ryz, 2) - 2 * Rxy * Rxz * Ryz)
    return Rxyz



def Corr3_vector(pointX, pointY, pointZ):


    Rxy = np.corrcoef(pointX, pointY)
    Rxz = np.corrcoef(pointX, pointZ)
    Ryz = np.corrcoef(pointY, pointZ)

    Rxy = Rxy[0][1]
    Rxz = Rxz[0][1]
    Ryz = Ryz[0][1]

    if np.isnan(Rxy) or np.isnan(Rxz) or np.isnan(Ryz):
        Rxyz = 1
    else:
        Rxyz = np.sqrt(math.pow(Rxy, 2) + math.pow(Rxz, 2) + math.pow(Ryz, 2) - 2 * Rxy * Rxz * Ryz)
    return Rxyz



def Corr3(points):
    df = pd.DataFrame(points)
    R = df.corr().values
    for i in R:
        for j in i:
            if math.isnan(j):
                return 1
    Rxyz = np.sqrt(1 - np.linalg.det(R))


    return Rxyz


def Corr3_delete(pointsX, pointsY, pointsZ, delete_num):

    # mean = 0 len = 1
    pointsX = pointsX - np.mean(pointsX)
    pointsY = pointsY - np.mean(pointsY)
    pointsZ = pointsZ - np.mean(pointsZ)

    x_len = np.sqrt(np.sum(pointsX ** 2))
    y_len = np.sqrt(np.sum(pointsY ** 2))
    z_len = np.sqrt(np.sum(pointsZ ** 2))

    if x_len < 1e-5 or y_len < 1e-5 or z_len < 1e-5:
        return []


    pointsX = pointsX/np.sqrt(np.sum(pointsX**2))
    pointsY = pointsY/np.sqrt(np.sum(pointsY**2))
    pointsZ = pointsZ/np.sqrt(np.sum(pointsZ**2))


    R12 = np.corrcoef(pointsX, pointsY)
    R13 = np.corrcoef(pointsX, pointsZ)
    R23 = np.corrcoef(pointsY, pointsZ)

    R12 = R12[0][1]
    R13 = R13[0][1]
    R23 = R23[0][1]

    X_2 = np.power(pointsX, 2)
    Y_2 = np.power(pointsY, 2)
    Z_2 = np.power(pointsZ, 2)

    XY = pointsX * pointsY
    XZ = pointsX * pointsZ
    YZ = pointsY * pointsZ

    comn = len(pointsX)/(len(pointsX)-1)

    P123 = (R12 - comn * XY) ** 2 / ((1 - comn * X_2) * (1 - comn * Y_2)) + \
           (R13 - comn * XZ) ** 2 / ((1 - comn * X_2) * (1 - comn * Z_2)) + \
           (R23 - comn * YZ) ** 2 / ((1 - comn * Y_2) * (1 - comn * Z_2)) - \
           2 * (R12 - comn * XY) * (R13 - comn * XZ) * (R23 - comn * YZ)/((1 - comn * X_2) * (1 - comn * Y_2) * (1 - comn * Z_2))


    indexC = np.argsort(-P123)
    delIndexArr = indexC[0:delete_num]
    return delIndexArr


# mean = 0 and len = 1
def normalize_vector(v):
    Xmean = np.mean(v)
    v = v - Xmean
    v = v / np.sqrt(np.sum(np.power(v, 2)))


    return v

# len = 1
def normc(v):
    v = v / np.sqrt(np.sum(np.power(v, 2), axis=0))
    return v

def writePoints(points, path, color=False):
    if os.path.exists(path):
        os.remove(path)
        f2 = open(path, 'w')
        f2.close()

    file = open(path, 'a+')

    file.write('ply\n')
    file.write('format ascii 1.0\n')
    file.write('element vertex %d\n' % (len(points)))
    file.write('property float x\n')
    file.write('property float y\n')
    file.write('property float z\n')
    if color:
        file.write('property uchar red\n')
        file.write('property uchar green\n')
        file.write('property uchar blue\n')
    file.write('end_header\n')

    for point in points:
        x = point[0]
        y = point[1]
        z = point[2]
        if color:
            file.write(str(x) + ' ' + str(y) + ' ' + str(z) + ' 255 0 0\n')
        else:
            file.write(str(x) + ' ' + str(y) + ' ' + str(z) + '\n')
    file.close()

# 对一个已经从小到大排序的数组，查找不大于该数的下标

def splitPoints(args, points,coordmax,coordmin):
    x_block_num = args.split_x
    y_block_num = args.split_y
    z_block_num = args.split_z

    nsubvolume_x = (coordmax[0] - coordmin[0]) / x_block_num + 0.001
    nsubvolume_y = (coordmax[1] - coordmin[1]) / y_block_num + 0.001
    nsubvolume_z = (coordmax[2] - coordmin[2]) / z_block_num + 0.001
    sub_sets = [[] for i in range(x_block_num * y_block_num * z_block_num)]
    for point in points:
        diff = point - coordmin
        x = diff[0]
        y = diff[1]
        z = diff[2]
        x_index = int(x // nsubvolume_x)
        y_index = int(y // nsubvolume_y)
        z_index = int(z // nsubvolume_z)
        index = x_index * y_block_num * z_block_num + y_index * z_block_num + z_index
        sub_sets[index].append(point)

    return sub_sets

def visPoints(point_sets):

    if os.path.exists('./allPoints.ply'):
        os.remove('./allPoints.ply')
        f2 = open('./allPoints.ply', 'w')
        f2.close()

    file = open('./allPoints.ply', 'a+')

    file.write('ply\n')
    file.write('format ascii 1.0\n')
    file.write('element vertex pointsLen\n')
    file.write('property float x\n')
    file.write('property float y\n')
    file.write('property float z\n')
    file.write('property uchar red\n')
    file.write('property uchar green\n')
    file.write('property uchar blue\n')
    file.write('end_header\n')

    pointsLen = 0
    for points in point_sets:
        pointsLen = pointsLen + len(points)

        r = random.randint(0, 255)
        g = random.randint(0, 255)
        b = random.randint(0, 255)

        for point in points:
            x = point[0]
            y = point[1]
            z = point[2]
            file.write('%f %f %f %d %d %d\n' % (x, y, z, r, g, b))
    file.flush()

    file.close()

    # rewrite points length
    file = open('./allPoints.ply', 'r')
    content = file.read()
    content = content.replace('pointsLen', str(pointsLen))
    file.close()

    file = open('./allPoints.ply', 'w')

    file.write(content)
    file.close()


def showPoints(allPoints, args=None, spase_step=1, plane_paras=[],title=''):
    color_arr = ['g', 'b', 'y', 'k']
    fig = plt.figure()
    ax = fig.gca(projection='3d')
    if len(plane_paras) > 0:
        for i, plane_para in enumerate(plane_paras):
            normals = plane_para[0:3]
            normals = np.transpose(normals)
            d = plane_para[3]
            dists = np.abs(np.matmul(allPoints, normals) - d)
            inpointsInd = np.where(dists < args.distThd)[0]
            delPoints = allPoints[inpointsInd]
            color = color_arr[i % 4]
            ax.scatter(delPoints[::spase_step, 0], delPoints[::spase_step, 1], delPoints[::spase_step, 2], c=color,
                       marker='.', linewidths=0.5)
            allPoints = np.delete(allPoints, inpointsInd, axis=0)

    ax.scatter(allPoints[::spase_step, 0], allPoints[::spase_step, 1], allPoints[::spase_step, 2], c='r',
               marker='.', linewidths=0.1)
    plt.title(title)
    plt.show()


warnings.filterwarnings('error')



