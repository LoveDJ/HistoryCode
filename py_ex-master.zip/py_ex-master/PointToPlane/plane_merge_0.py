import numpy as np

patch_arr = []
with open(r'E:\download\rapterData\empire\primitives_it11.bonmin.csv') as file_object:
    for line in file_object:
        arr = line.strip().split(',')
        arr[0:6] = list(map(float, arr[0:6]))
        arr[6:-1] = list(map(int, arr[6:-1]))
        patch_arr.append(arr)

del_idx = []
for i,patch in enumerate(patch_arr):
    p_normal = patch[3:6]
    p_center = patch[0:3]
    p_d = np.dot(p_normal, p_center)
    for j, patch2 in enumerate(patch_arr):
        if i >= j:
            continue
        p2_normal = patch2[3:6]
        p2_center = patch2[0:3]
        p2_d = np.dot(p2_normal, p2_center)
        dot_num = np.dot(p_normal, p2_normal)
        if dot_num > 1:
            dot_num = 1
        if dot_num < -1:
            dot_num = -1
        angle = np.arccos(dot_num)*180/np.pi
        dist_diff = np.abs(p_d - p2_d)
        if angle < 5 and dist_diff <0.05:
            del_idx.append(j)

del_idx = list(set(del_idx))
print(del_idx)
patch_arr = np.array(patch_arr)
patch_arr = np.delete(patch_arr, del_idx, axis=0)
'''
point_arr = []
with open(r'E:\download\rapterData\empire\points_primitives_it10.csv') as file_object:
    for line in file_object:
        arr = line.strip().split(',')
        try:
            point_arr.append(list(map(int, arr)))
        except Exception:
            pass
plane_num_arr = np.zeros(len(patch_arr))
for point in point_arr:
    plane_id = point[1]
    for p,patch in enumerate(patch_arr):
        if patch[6] == plane_id:
            plane_num_arr[p] += 1

plane_sort_index = np.argsort(-plane_num_arr)
print(np.sum(plane_num_arr))
print(plane_sort_index) # 其他方法的平面从大到小排序
'''