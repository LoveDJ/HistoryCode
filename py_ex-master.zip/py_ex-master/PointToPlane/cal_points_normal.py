"""
计算点云的法向量
"""

import numpy as np
from PointToPlane import corrFitMethod
from PointToPlane import Utils
def calPointsNormal(allPoints):
    knum = 10
    points_normal_arr = np.zeros((len(allPoints), 3))
    coormax = np.max(allPoints, axis=0)
    coormin = np.min(allPoints, axis=0)
    x_block_num = 40
    y_block_num = 40
    z_block_num = 40
    nsubvolume_x = (coormax[0] - coormin[0]) / x_block_num + 0.001
    nsubvolume_y = (coormax[1] - coormin[1]) / y_block_num + 0.001
    nsubvolume_z = (coormax[2] - coormin[2]) / z_block_num + 0.001
    sub_sets = [[] for i in range(x_block_num * y_block_num * z_block_num)]
    sub_sets_idx = [[] for i in range(x_block_num * y_block_num * z_block_num)]
    for i,point in enumerate(allPoints):
        diff = point - coormin
        x = diff[0]
        y = diff[1]
        z = diff[2]
        x_index = int(x // nsubvolume_x)
        y_index = int(y // nsubvolume_y)
        z_index = int(z // nsubvolume_z)
        index = x_index * y_block_num * z_block_num + y_index * z_block_num + z_index
        sub_sets[index].append(point)
        sub_sets_idx[index].append(i)

    for i,sub_points in enumerate(sub_sets):
        extend_points = sub_points.copy()
        # 将相邻的点云块中的点合并
        x_index = i // (y_block_num*z_block_num)
        y_index = (i - x_index*y_block_num*z_block_num)//(z_block_num)
        z_index = i - x_index*y_block_num*z_block_num - y_index*z_block_num
        for r in range(3):
            for s in range(3):
                for t in range(3):
                    if r != 1 and s != 1 and t != 1:
                        near_index_x = x_index + r - 1
                        near_index_y = y_index + s - 1
                        near_index_z = z_index + t - 1
                        # 判断不能越界
                        if near_index_x>0 and near_index_y>0 and near_index_z>0\
                                and near_index_x < x_block_num-1 and near_index_y < y_block_num-1\
                                and near_index_z<z_block_num-1:
                            extend_points.extend(sub_sets[near_index_x*y_block_num*z_block_num +\
                                                            near_index_y*z_block_num+near_index_z])
        if len(extend_points) < 3:
            continue
        for j,point in enumerate(sub_points):
            x = point[0]
            y = point[1]
            z = point[2]
            p_idx = sub_sets_idx[i][j]
            dist_arr = np.zeros(len(extend_points))
            for k,point2 in enumerate(extend_points): # 计算与其他点的欧式距离
                x2 = point2[0]
                y2 = point2[1]
                z2 = point2[2]
                dist = (x2-x)**2 + (y2-y)**2 + (z2-z)**2
                dist_arr[k] = dist
            idx_all = np.argsort(dist_arr)
            idx_k = idx_all[0:knum]
            sub_points = np.array(sub_points)
            extend_points = np.array(extend_points)
            near_points = extend_points[idx_k]
            a, b, c, d = corrFitMethod.Fit(near_points)
            print(a**2 + b**2 +c**2)
            if a*x+b*y+c*z < 0:
                a = -a
                b = -b
                c = -c
            points_normal_arr[p_idx] = np.array([a, b, c])

    return points_normal_arr
'''
plyPath = r'../data/indoor.ply'
allPoints = Utils.readMesh(plyPath)
calPointsNormal(allPoints)
'''


