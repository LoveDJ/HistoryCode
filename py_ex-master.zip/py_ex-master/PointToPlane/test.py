from scipy.io import loadmat
import numpy as np
from PointToPlane import leastSquareMethod as lsm
from PointToPlane import corrFitMethod as corr
from PointToPlane import Utils
import matplotlib as mpl
from matplotlib import cm
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


path = r'G:\Noisy-DPCP-master\roadplane_demo\data\09_29_071\29_071_0328_data.mat'

m = loadmat(path)
inliers = m['inliers']
outliers = m['outliers']
inliers = inliers[0:3]
outliers = outliers[0:3]
inliers = np.transpose(inliers)
outliers = np.transpose(outliers)


all_points = np.concatenate((inliers, outliers), axis=0)
all_points_raw = all_points.copy()
inpoints_num = inliers.shape[0]

fig = plt.figure()
ax = fig.gca(projection='3d')
spase_step = 20
ax.scatter(inliers[::spase_step, 0], inliers[::spase_step, 1], inliers[::spase_step, 2], c='r', marker='.',
           linewidths=0.1)
ax.scatter(outliers[::spase_step, 0], outliers[::spase_step, 1], outliers[::spase_step, 2], c='b', marker='.',
           linewidths=0.1)
ax.grid(False)
plt.show()

a, b, c, d = lsm.leastSquare(all_points)
rm_n = len(outliers)//10
while (len(all_points) > inpoints_num):
    rmIndexArr = Utils.Corr3_delete(all_points[:, 0], all_points[:, 1], all_points[:, 2], rm_n)
    del_points = all_points[rmIndexArr]
    all_points = np.delete(all_points, rmIndexArr, axis=0)

    # fig = plt.figure()
    # ax = fig.gca(projection='3d')
    # spase_step = 20
    # ax.scatter(del_points[::spase_step, 0], del_points[::spase_step, 1], del_points[::spase_step, 2], c='r', marker='.',
    #            linewidths=0.1)
    # ax.scatter(all_points[::spase_step, 0], all_points[::spase_step, 1], all_points[::spase_step, 2], c='b', marker='.',
    #            linewidths=0.1)
    # plt.show()

a2, b2, c2, d2 = corr.Fit(all_points)

# a2 = 0.009048009793912
# b2 = -0.008965558368211
# c2 = -0.515653563951260
# d2 = -0.856702488770915

print('corr result：a=%.5f b=%.5f c=%.5f d=%.5f' % (a2, b2, c2, d2))

fig = plt.figure()
ax = fig.gca(projection='3d')
# ax.scatter(pointsX2, pointsY2, pointsZ2, c='r', marker='.', linewidths=0.1)
# ax.scatter(del_points_x, del_points_y, del_points_z, c='b', marker='.', linewidths=0.1)
spase_step = 20

ax.scatter(all_points_raw[::spase_step,0], all_points_raw[::spase_step,1], all_points_raw[::spase_step,2], c='r', marker='.', linewidths=0.1)

kedu_range_min = np.min(all_points_raw, axis=0)
kedu_range_max = np.max(all_points_raw, axis=0)
Y = np.arange(kedu_range_min[1], kedu_range_max[1], 0.05)
Z = np.arange(kedu_range_min[2], kedu_range_max[2], 0.05)
Y, Z = np.meshgrid(Y, Z)
X = (-b2 * Y - c2 * Z + d2) / a2
surf = ax.plot_surface(X, Y, Z, cmap=cm.Blues, linewidth=0, antialiased=False, alpha=0.8)

plt.show()