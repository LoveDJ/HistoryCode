import argparse
import numpy as np
from PointToPlane import ransac_v2 as ransac
from PointToPlane import Utils
import time
import os

parser = argparse.ArgumentParser(description='PointToPlane')
parser.add_argument('--distThd', dest='distThd',
                        help='default distance to judge whether a point is on plane',
                        default=0.05, type=float)
parser.add_argument('--step', dest='step',
                        help='step of sparsing points',
                        default=1, type=int)
parser.add_argument('--pNum', dest='pNum',
                        help='the number of planes to extract',
                        default=5, type=int)
parser.add_argument('--iterNum', dest='iterNum',
                            help='step of sparsing points',
                            default=5000, type=int)
args = parser.parse_args()
rate_arr = np.array([])
dist_arr = np.array([])
time_arr = np.array([])
dir_path = '../data/scanNet'
files = os.listdir(dir_path)
# files = sorted(files)

for data_file in files:
    if data_file.endswith('ply'):
        print(data_file)
        args.pointsPath = os.path.join(dir_path, data_file)
        # N =  math.log(0.01) / math.log(1 - 0.045**3)
        plyPath = args.pointsPath
        allPoints = Utils.readMesh(plyPath, step=args.step)
        startTime = time.time()
        allPointsCopy = allPoints.copy()
        allDist = 0
        allNum = 0
        for k in range(args.pNum):
            if len(allPointsCopy)==0:
                break
            a, b, c, d = ransac.ransac(allPointsCopy, distThd=args.distThd, iterNum=args.iterNum)
            normal = [a, b, c]
            dist = np.abs(np.matmul(allPointsCopy, normal) - d)
            inpointsInd = np.where(dist < args.distThd)[0]
            # print('the %d th  plane: inpoints number = %d'%(k, len(inpointsInd)))
            inPointsNum = len(inpointsInd)
            allDist += np.sum(dist[inpointsInd])
            allNum += len(inpointsInd)
            allPointsCopy = np.delete(allPointsCopy, inpointsInd, axis=0)
        endTime = time.time()
        inner_points_rate = (len(allPoints)-len(allPointsCopy))/len(allPoints)
        mean_distance = allDist/allNum
        cost_time = endTime - startTime
        rate_arr = np.append(rate_arr, inner_points_rate)
        dist_arr = np.append(dist_arr, mean_distance)
        time_arr = np.append(time_arr, cost_time)
        print('inner_points_rate = %.5f' % (inner_points_rate))
        print('mean_distance = %.5f '%(mean_distance))
        print('cost_time = %.3f'%(cost_time))
print(rate_arr)
print(dist_arr)
print(time_arr)
rate_mean = np.mean(rate_arr)
dist_mean = np.mean(dist_arr)
time_mean = np.mean(time_arr)
print('rate_mean = %.5f'%(rate_mean))
print('dist_mean = %.5f'%(dist_mean))
print('time_mean = %.5f'%(time_mean))