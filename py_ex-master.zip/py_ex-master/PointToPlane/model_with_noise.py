'''

describe: generate one house model without noise

'''

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
from PointToPlane import Utils
from PointToPlane import leastSquareMethod as lsm

# config figure
fig = plt.figure()
ax = fig.gca(projection='3d')
mu = 0
sigma = 5
unit = 50
sub_unit = unit//2
# create plane points
x = np.linspace(-100, 100, unit)
y = np.linspace(-100, 100, unit)
z = np.linspace(-100, 100, unit)
x_init, y_init = np.meshgrid(x, y)

x0 = x_init.reshape((unit**2, 1))
y0 = y_init.reshape((unit**2, 1))
# z = -100
x1 = x0
y1 = y0
z1 = np.ones((unit**2, 1))*(-100)

np.random.seed(0)
x1_noise = np.random.randint(-100, 100, size=100)
x1_noise = x1_noise.reshape((100,1))
np.random.seed(1)
y1_noise = np.random.randint(-100, 100, size=100)
y1_noise = y1_noise.reshape((100,1))

D1 = np.random.normal(mu, sigma, 100)
D1 = D1.reshape((100, 1))
z1_noise = (D1 - 100)


# y = -100
x2 = x0
y2 = np.ones((unit**2, 1))*(-100)
z2 = y0

np.random.seed(2)
x2_noise = np.random.randint(-100, 100, size=100)
x2_noise = x2_noise.reshape((100,1))
np.random.seed(3)
z2_noise = np.random.randint(-100, 100, size=100)
z2_noise = z2_noise.reshape((100,1))

D2 = np.random.normal(mu, sigma, 100)
D2 = D2.reshape((100, 1))
y2_noise = (D2 - 100)

# y3 = 100
x3 = x0
y3 = np.ones((unit**2, 1))*(100)
z3 = y0

np.random.seed(4)
x3_noise = np.random.randint(-100, 100, size=100)
x3_noise = x3_noise.reshape((100,1))
np.random.seed(5)
z3_noise = np.random.randint(-100, 100, size=100)
z3_noise = z3_noise.reshape((100,1))

D3 = np.random.normal(mu, sigma, 100)
D3 = D3.reshape((100, 1))
y3_noise = (D3 + 100)

# x = -100
x4 = np.ones((unit**2, 1))*(-100)
y4 = x0
z4 = y0

np.random.seed(6)
y4_noise = np.random.randint(-100, 100, size=100)
y4_noise = y4_noise.reshape((100,1))
np.random.seed(7)
z4_noise = np.random.randint(-100, 100, size=100)
z4_noise = z4_noise.reshape((100,1))

D4 = np.random.normal(mu, sigma, 100)
D4 = D4.reshape((100, 1))
x4_noise = (D4 - 100)

# x = 100
x5 = np.ones((unit**2, 1))*(100)
y5 = x0
z5 = y0

np.random.seed(8)
y5_noise = np.random.randint(-100, 100, size=100)
y5_noise = y5_noise.reshape((100,1))
np.random.seed(9)
z5_noise = np.random.randint(-100, 100, size=100)
z5_noise = z5_noise.reshape((100,1))

D5 = np.random.normal(mu, sigma, 100)
D5 = D5.reshape((100, 1))
x5_noise = (D5 + 100)

x = np.linspace(0, 100, sub_unit)
y = np.linspace(-100, 0, sub_unit)
z = np.linspace(-100, 100, sub_unit)

x_init, z_init = np.meshgrid(x, z)
x_init = x_init.reshape((sub_unit**2, 1))
z_init = z_init.reshape((sub_unit**2, 1))

# y6 = 0
x6 = x_init
y6 = np.zeros((sub_unit**2, 1))
z6 = z_init

np.random.seed(10)
x6_noise = np.random.randint(0, 100, size=50)
x6_noise = x6_noise.reshape((50,1))
np.random.seed(11)
z6_noise = np.random.randint(-100, 100, size=50)
z6_noise = z6_noise.reshape((50,1))

D6 = np.random.normal(mu, sigma, 50)
D6 = D6.reshape((50, 1))
y6_noise = D6

# x = 0
y_init, z_init = np.meshgrid(y, z)
y_init = y_init.reshape((sub_unit**2, 1))
z_init = z_init.reshape((sub_unit**2, 1))
x7 = np.zeros((sub_unit**2, 1))
y7 = y_init
z7 = z_init

np.random.seed(10)
y7_noise = np.random.randint(-100, 0, size=50)
y7_noise = y7_noise.reshape((50,1))
np.random.seed(11)
z7_noise = np.random.randint(-100, 100, size=50)
z7_noise = z7_noise.reshape((50,1))

D7 = np.random.normal(mu, sigma, 50)
D7 = D7.reshape((50, 1))
x7_noise = D7

x_all = np.concatenate((x1, x2, x3, x4, x5, x6, x7, x1_noise, x2_noise,
                        x3_noise, x4_noise, x5_noise, x6_noise, x7_noise), axis=0)
y_all = np.concatenate((y1, y2, y3, y4, y5, y6, y7, y1_noise, y2_noise,
                        y3_noise, y4_noise, y5_noise, y6_noise, y7_noise), axis=0)
z_all = np.concatenate((z1, z2, z3, z4, z5, z6, z7, z1_noise, z2_noise,
                        z3_noise, z4_noise, z5_noise, z6_noise, z7_noise), axis=0)


# show plane before points being deleted
ax.scatter(x_all, y_all, z_all, c='r', marker='.', linewidths=0.5)
ax.legend()
plt.show()

