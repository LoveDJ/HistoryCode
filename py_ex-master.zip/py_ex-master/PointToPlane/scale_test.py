import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
def wgn(x, snr):
    snr = 10**(snr/10.0)
    xpower = np.sum(x**2)/len(x)
    npower = xpower / snr
    return np.random.randn(len(x)) * np.sqrt(npower)


print('start...')
inpoints_num = 100
outpoints_num = 160
x = np.random.rand(inpoints_num)*10
y = -2 * x + 3

# x = np.append(x, 99999999)
# y = np.append(y, -2 * 99999999 + 3)

x = np.append(x, 99999999+100000)
y = np.append(y, -2 * (99999999+100000)+ 3+100000)

'''
SNR = 25

noise_x = wgn(x, SNR)
x = x + noise_x
noise_y = wgn(y, SNR)
y = y + noise_y

# 显示内点
plt.subplot(2, 3, 1)
plt.scatter(x, y, c='', marker='o', edgecolors='b', s=4)
plt.ylim((-25,25))
plt.ylabel('y', fontdict={'family':'Times New Roman'}, fontsize=14)
plt.tick_params(labelsize=8)

outlier_x = np.random.rand(outpoints_num)*10
outlier_y = np.random.rand(outpoints_num)*50 - 25
x = np.append(x, outlier_x)
y = np.append(y, outlier_y)

'''
# 显示初始点集
plt.subplot(2, 3, 1)
plt.scatter(x, y, c='', marker='o', edgecolors='b', s=4)

plt.show()


outliersX = []
outliersY = []
it = 0
for v in range(160):
    rxy_arr = []
    for i in range(len(x)):
        rxy = np.abs(np.corrcoef(np.delete(x, i), np.delete(y, i))[0][1])
        rxy_arr.append(rxy)
    
    indexC = np.argsort(-np.array(rxy_arr))
    delIndexArr = indexC[0:1]
    outliersX.append(x[delIndexArr])
    outliersY.append(y[delIndexArr])
    x = np.delete(x, delIndexArr)
    y = np.delete(y, delIndexArr)
    if (v+1)%40 == 0:
        it += 1
        plt.subplot(2, 3, 2+it)
        plt.scatter(x, y, c='', marker='o', edgecolors='b', s=4)
        plt.scatter(outliersX, outliersY, c='', marker='o', alpha=0.8, edgecolors='r', s=4)
        if it >= 2:
            plt.xlabel('x', fontdict={'family':'Times New Roman'}, fontsize=14)
        if it == 2:
            plt.ylabel('y', fontdict={'family':'Times New Roman'}, fontsize=14)
    plt.tick_params(labelsize=8)

plt.show()
print('end...')
