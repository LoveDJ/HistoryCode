import numpy as np
from PointToPlane import Utils
import time
sTime = time.time()
delete_num = 10
points = Utils.readxyz('../data/fitting/plane1.txt')
N = len(points)

x = points[:,0]
y = points[:,1]
z = points[:,2]

seX = np.sum(x)
seY = np.sum(y)
seZ = np.sum(z)

ssX = np.sum(x**2)
ssY = np.sum(y**2)
ssZ = np.sum(z**2)

ipXY = np.sum(x*y)
ipXZ = np.sum(x*z)
ipYZ = np.sum(y*z)

for _ in range(10):
    w_array = np.zeros(N)
    for i in range(N):
        tseX = seX - x[i]
        tseY = seY - y[i]
        tseZ = seZ - z[i]

        tssX = ssX - x[i]**2
        tssY = ssY - y[i]**2
        tssZ = ssZ - z[i]**2

        tipXY = ipXY - x[i]*y[i]
        tipXZ = ipXZ - x[i]*z[i]
        tipYZ = ipYZ - y[i]*z[i]

        sXX = N*tssX - tseX**2
        sYY = N*tssY - tseY**2
        sZZ = N*tssZ - tseZ**2
        sXY = N*tipXY - tseX*tseY
        sXZ = N*tipXZ - tseX*tseZ
        sYZ = N*tipYZ - tseY*tseZ

        tX = N*tssX - tseX**2
        tY = N*tssY - tseY**2
        tZ = N*tssZ - tseZ**2

        corArr = np.array([[sXX, sXY, sXZ], [sXY, sYY, sYZ], [sXZ, sYZ, sZZ]])

        w_array[i] = np.linalg.det(corArr)/(tX*tY*tZ)

    indexC = np.argsort(w_array)
    delIndexArr = indexC[0:delete_num]
    del_points = points[delIndexArr]
    dx = del_points[:,0]
    dy = del_points[:,1]
    dz = del_points[:,2]
    seX = seX - np.sum(dx)
    seY = seY - np.sum(dy)
    seZ = seZ - np.sum(dz)
    ssX = ssX - np.sum(dx**2)
    ssY = ssY - np.sum(dy**2)
    ssZ = ssZ - np.sum(dz**2)
    ipXY = ipXY - np.sum(dx*dy)
    ipXZ = ipXZ - np.sum(dx*dz)
    ipYZ = ipYZ - np.sum(dy*dz)
    N = N - delete_num
    x = np.delete(x, delIndexArr)
    y = np.delete(y, delIndexArr)
    z = np.delete(z, delIndexArr)
eTime = time.time()
print('耗时%.5f'%(eTime-sTime))