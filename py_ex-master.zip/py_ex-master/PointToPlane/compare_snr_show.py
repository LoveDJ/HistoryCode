import numpy as np
import matplotlib.pyplot as plt

snr_arr = np.load("snr_arr.npy")
rmse_arr_all2 = np.load("rmse_arr_all2.npy")
rmse_err_all2 = np.load("rmse_err_all2.npy")
methods = np.load("methods.npy")

fig = plt.figure()
ax = fig.gca()
plt.xlabel("Inlier Noise SNR")
plt.ylabel("RMSE")
for i in range(6):

    plt.errorbar(snr_arr, rmse_arr_all2[:,i+1], yerr=rmse_err_all2[:,i+1], label=methods[i+1], linewidth=2)

plt.legend(loc=(1/75, 0.06/2))
plt.gca().invert_xaxis()
plt.grid(axis='y',linestyle='-.')
ax.set_ylim(bottom=0.)
plt.show()
