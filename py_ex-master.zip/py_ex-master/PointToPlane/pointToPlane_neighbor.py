'''
points to plane
author: ding jian
date:2019-09-26
email:jeanding001@163.com

'''


import time
import numpy as np
import argparse
import matplotlib as mpl
from matplotlib import cm
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from PointToPlane import corrFitMethod
from PointToPlane import Utils



def plane_fitting(args, rawPoints):


    allPoints = rawPoints.copy()
    coordmax = np.max(allPoints, axis=0)
    coordmin = np.min(allPoints, axis=0)
    planeParas = []
    # 对点云不断分块，直到每个点云块中的点的个数小于args.numThd
    for i in range(100):

        # 对点云分块
        args.split_x = i+1
        args.split_y = i+1
        args.split_z = i+1
        if len(allPoints) == 0:
            break
        pointSets = Utils.splitPoints(args, allPoints,coordmax, coordmin)

        # 显示分割后的点云块
        # color_arr = ['r', 'g', 'b', 'y', 'k']
        # fig = plt.figure()
        # ax = fig.gca(projection='3d')
        # for i, points in enumerate(pointSets):
        #     points = np.array(points)
        #     if len(points) > 0:
        #         color = color_arr[i % 5]
        #         ax.scatter(points[:, 0], points[:, 1], points[:, 2], c=color, marker='.', linewidths=0.5)
        # plt.title('split')
        # ax.legend()
        # plt.show()

        # 点云块足够小 停止分块
        is_more_points = False
        for points in pointSets:
            if len(points) > args.numThd:
                is_more_points = True
                break
        if not is_more_points:
            break

        # 提取块中平面
        for i, points in enumerate(pointSets):
            if len(points) < 3:
                continue
            points = np.array(points)
            pointCorr = Utils.Corr3(points)
            kedu_range_min = np.min(points, axis=0)
            kedu_range_max = np.max(points, axis=0)
            zrota_degree = 220
            yrota_degree = 1
            if pointCorr < args.corrThd or len(points) < args.numThd+1:
                continue
            # 显示删除外点前点云块
            if pointCorr <0.954456 and pointCorr > 0.954453:
                fig = plt.figure()
                ax = fig.gca(projection='3d')
                spase_step = 1
                ax.scatter(points[::spase_step, 0], points[::spase_step, 1], points[::spase_step, 2], c='r', marker='.',
                           linewidths=0.1)
                ax.view_init(elev=yrota_degree, azim=zrota_degree)
                # ax.view_init(azim=zrota_degree)
                ax.grid(False)
                plt.xlim((kedu_range_min[0], kedu_range_max[0]))
                plt.ylim((kedu_range_min[1], kedu_range_max[1]))
                ax.set_zlim3d(kedu_range_min[2], kedu_range_max[2])
                # plt.title('未进行删除的点', fontproperties="SimHei")
                plt.show()
            print(pointCorr)
            # 删除外点
            pointCorr_after = pointCorr

            if pointCorr <0.954456 and pointCorr > 0.954453:
                delete_num = int(0.01 * len(points))
            else:
                delete_num = int(0.07 * len(points))
            for i in range(8):

                pointsX = points[:, 0]
                pointsY = points[:, 1]
                pointsZ = points[:, 2]

                if pointCorr <0.954456 and pointCorr > 0.954453:

                    a2, b2, c2, d2 = corrFitMethod.Fit(points)
                    dist = np.abs(a2 * pointsX + b2 * pointsY + c2 * pointsZ - d2)

                    indexC = np.argsort(-dist)
                    rmIndexArr = indexC[0:delete_num]

                    del_points_x = pointsX[rmIndexArr]
                    del_points_y = pointsY[rmIndexArr]
                    del_points_z = pointsZ[rmIndexArr]
                    pointsX2 = np.delete(pointsX, rmIndexArr, axis=0)
                    pointsY2 = np.delete(pointsY, rmIndexArr, axis=0)
                    pointsZ2 = np.delete(pointsZ, rmIndexArr, axis=0)

                    fig = plt.figure()
                    ax = fig.gca(projection='3d')
                    # ax.scatter(pointsX2, pointsY2, pointsZ2, c='r', marker='.', linewidths=0.1)
                    # ax.scatter(del_points_x, del_points_y, del_points_z, c='b', marker='.', linewidths=0.1)
                    ax.scatter(pointsX, pointsY, pointsZ, c='r', marker='.', linewidths=0.1)


                    Y = np.arange(kedu_range_min[1], kedu_range_max[1], 0.05)
                    Z = np.arange(kedu_range_min[2], kedu_range_max[2], 0.05)
                    Y, Z = np.meshgrid(Y, Z)
                    X = (-b2 * Y - c2 * Z + d2) / a2
                    surf = ax.plot_surface(X, Y, Z, cmap=cm.Blues, linewidth=0, antialiased=False, alpha=0.8)
                    ax.view_init(elev=yrota_degree, azim=zrota_degree)
                    # ax.view_init(azim=zrota_degree)
                    ax.grid(False)
                    plt.xlim((kedu_range_min[0], kedu_range_max[0]))
                    plt.ylim((kedu_range_min[1], kedu_range_max[1]))
                    ax.set_zlim3d(kedu_range_min[2], kedu_range_max[2])
                    plt.show()
                else:
                    rmIndexArr = Utils.Corr3_delete(pointsX, pointsY, pointsZ, delete_num)
                    delPoints = points[rmIndexArr]
                points = np.delete(points, rmIndexArr, axis=0)



                pointCorr_after = Utils.Corr3(points)
                # if pointCorr_after > args.corrThd2:
                #     break
            if pointCorr <0.954456 and pointCorr > 0.954453:
                # 显示删除噪声后的点云
                fig = plt.figure()
                ax = fig.gca(projection='3d')
                spase_step = 1
                ax.scatter(points[::spase_step, 0], points[::spase_step, 1], points[::spase_step, 2], c='r', marker='.',
                           linewidths=0.1)
                ax.view_init(elev=yrota_degree, azim=zrota_degree)
                # ax.view_init(azim=zrota_degree)
                ax.grid(False)
                plt.xlim((kedu_range_min[0], kedu_range_max[0]))
                plt.ylim((kedu_range_min[1], kedu_range_max[1]))
                ax.set_zlim3d(kedu_range_min[2], kedu_range_max[2])
                # plt.title('删除后的点'+str(pointCorr_after), fontproperties="SimHei")
                plt.show()
            # 删除后仍构不成平面，继续下一个块
            if pointCorr_after < args.corrThd2:
                continue

            # 拟合出平面
            a, b, c, d = corrFitMethod.Fit(points)
            if a != None:
                planeParas.append([a, b, c, d])

            # 删除平面上的点
            normals = np.array([a, b, c])
            normals = np.transpose(normals)
            dists = np.abs(np.matmul(allPoints, normals) - d)
            inpointsInd = np.where(dists < args.distThd)[0]
            delPoints = allPoints[inpointsInd]
            allPoints = np.delete(allPoints, inpointsInd, axis=0)

            # 显示拟合出来的平面----整个点云
            # fig = plt.figure()
            # ax = fig.gca(projection='3d')
            # spase_step = 5
            # ax.scatter(allPoints[::spase_step, 0], allPoints[::spase_step, 1], allPoints[::spase_step, 2], c='r', marker='.', linewidths=0.1)
            # ax.scatter(delPoints[::spase_step, 0], delPoints[::spase_step, 1], delPoints[::spase_step, 2], c='b', marker='.', linewidths=0.1)
            #
            # plt.title(len(planeParas)-1)
            # plt.show()

    print('剩余点个数：%d'%(len(allPoints)))
    print('内点率：%.5f' % ((len(rawPoints)-len(allPoints))/len(rawPoints)))
    print('平面个数%d'%(len(planeParas)))
    # 显示剩下的点
    fig = plt.figure()
    ax = fig.gca(projection='3d')
    spase_step = 1
    ax.scatter(allPoints[::spase_step, 0], allPoints[::spase_step, 1], allPoints[::spase_step, 2], c='r',
               marker='.', linewidths=0.1)
    plt.show()

    # print('剩余点数：%d'%(len(allPoints)))
    planeParas = np.array(planeParas) # 第一次抽取出来的平面参数
    # print('合并前平面数量：%d'%(len(planeParas)))


    # 合并平面
    plane_merged_index = [] # 已经合并过的平面参数
    results = [] # 最终拟合出来的平面参数结果
    # 每个平面和其他平面比较
    for i in range(len(planeParas)):

        # 已经被合并过的平面不再计算
        if i in plane_merged_index:
            continue

        # print('第%d个平面开始执行合并' % (i))
        # print('已经合并过的平面为：')
        # print(plane_merged_index)

        plane_merged_index.append(i) # 将当前平面记录为已合并

        # 获取相似平面 得到一个相似平面数组
        init_plane_para = planeParas[i]
        normal_a = init_plane_para[0:3]
        offset_a = init_plane_para[3]

        same_plane_index = []
        same_plane_paras = []
        this_merge_index = []
        # 与其他平面比较
        for j in range(len(planeParas)):
            if j == i:  # 不与自身比较
                continue
            normal_b = planeParas[j, 0:3]
            offset_b = planeParas[j, 3]
            angle = np.arccos(np.dot(normal_a, normal_b)/np.sqrt(np.sum(normal_a**2)*np.sum(normal_b**2)))*180/np.pi
            if angle > 90:
                angle = 180 - angle
            offset = np.abs(offset_a - offset_b)
            if angle < args.angleThd and offset < args.offsetThd:
                    same_plane_index.append(j)
                    same_plane_paras.append(planeParas[j])

        # print('相似的平面共有%d个:'%(len(same_plane_index)))
        # print(same_plane_index)


        # 显示所有候选合并平面
        if len(same_plane_paras)>0:
            all_same_plane_paras = np.vstack((same_plane_paras, init_plane_para))
        else:
            all_same_plane_paras = np.expand_dims(init_plane_para,axis=0)

        title = str(same_plane_index)
        # Utils.showPoints(rawPoints,args,spase_step=5,plane_paras=all_same_plane_paras,title=title)

        # 每次和最小角度平面合并
        same_plane_paras = np.array(same_plane_paras)
        for k in range(len(same_plane_paras)):

            # 找到与第一个平面夹角最小的平面
            min_angle = 180
            min_angle_para = None
            min_angle_index = None
            for l in range(len(same_plane_paras)):

                if same_plane_index[l] in this_merge_index: # 从相似平面剩余的平面中找最小角度平面
                    continue

                first_plane_normal = init_plane_para[0:3]
                other_plane_normal = same_plane_paras[l, 0:3]
                angle = np.arccos(np.dot(first_plane_normal, other_plane_normal)
                                  / np.sqrt(np.sum(first_plane_normal ** 2) * np.sum(other_plane_normal ** 2))) * 180 / np.pi
                if angle > 90:
                    angle = 180 - angle
                if angle < min_angle:
                    min_angle = angle
                    min_angle_para = same_plane_paras[l,]
                    min_angle_index = same_plane_index[l]
            # print('与第%d个相似平面合并，平面夹角最小的平面是：%d, 夹角为：%.5f'%(k,min_angle_index,min_angle))

            # 尝试与夹角最小的平面进行合并
            # 获取两个平面上的点
            mergePoints = rawPoints.copy()

            first_plane_normal_t = np.transpose(init_plane_para[0:3])
            first_plane_offset = init_plane_para[3]

            first_dist = np.abs(np.matmul(mergePoints, first_plane_normal_t) - first_plane_offset)
            first_inpointsInd = np.where(first_dist < args.distThd)[0]
            two_plane_points = mergePoints[first_inpointsInd]  # 两个平面上的点
            mergePoints = np.delete(mergePoints, first_inpointsInd, axis=0)

            second_plane_normal = min_angle_para[0:3]
            second_plane_normal_t = np.transpose(second_plane_normal)
            second_plane_offet = min_angle_para[3]

            second_dist = np.abs(np.matmul(mergePoints, second_plane_normal_t) - second_plane_offet)
            second_inpointsInd = np.where(second_dist < args.distThd)[0]
            secondPoints = mergePoints[second_inpointsInd]
            two_plane_points = np.append(two_plane_points, secondPoints,axis=0)# 将第二个平面上的点加入到集合中
            two_plane_points_show = two_plane_points.copy()
            two_points_corr_before = Utils.Corr3(two_plane_points)

            two_plane_paras = np.vstack((init_plane_para, min_angle_para))

            # 显示要合并的两个平面
            # Utils.showPoints(rawPoints,args,spase_step=5,plane_paras=two_plane_paras)


            # 删除噪声点
            pointCorr_after = two_points_corr_before
            delete_num = int(0.03 * len(two_plane_points))
            for v in range(5):

                pointsX = two_plane_points[:, 0]
                pointsY = two_plane_points[:, 1]
                pointsZ = two_plane_points[:, 2]

                rmIndexArr = Utils.Corr3_delete(pointsX, pointsY, pointsZ, delete_num)
                two_plane_points = np.delete(two_plane_points, rmIndexArr, axis=0)
                pointCorr_after = Utils.Corr3(two_plane_points)
                if pointCorr_after > args.corrThd2:
                    break

            # 显示合并的平面上的点
            # fig = plt.figure()
            # ax = fig.gca(projection='3d')
            # spase_step = 1
            # ax.scatter(two_plane_points[::spase_step, 0], two_plane_points[::spase_step, 1],
            #            two_plane_points[::spase_step, 2], c='r',
            #            marker='.', linewidths=0.1)
            # plt.title(str(pointCorr_after))
            # plt.show()


            # 与角度最小的平面拟合效果不好，将合并后的结果输出，不与其他平面合并
            if pointCorr_after < args.corrThd2:
                # print('相关系数不满足，没有进行合并操作，该平面不再进行合并')
                break
            # print('相关系数满足，执行合并操作')
            # 与角度最小的平面拟合效果好，更新第一个平面参数，并记录合并的平面索引，再与剩下的平面继续合并
            a, b, c, d = corrFitMethod.Fit(two_plane_points)

            if a != None:
                init_plane_para = np.array([a,b,c,d]) # 更新第一个平面参数


            # 比较合并前后平面上点个数的变化
            points_before_num = len(first_inpointsInd)+len(second_inpointsInd)
            normal_merge = init_plane_para[0:3]
            normal_merge_t = np.transpose(normal_merge)
            offset_merge = init_plane_para[3]
            merge_dist = np.abs(np.matmul(rawPoints, normal_merge_t) - offset_merge)
            merge_inpointsInd = np.where(merge_dist < args.distThd)[0]
            # print('合并前后点数的变化：%d'%(points_before_num-len(merge_inpointsInd)))


            # 显示合并前平面上的点
            title = '合并前平面上的点%d + %d = %d'%(len(first_inpointsInd),len(second_inpointsInd),points_before_num)
            # Utils.showPoints(two_plane_points_show, args,spase_step=1,plane_paras=two_plane_paras,title=title)

            # 显示删除外点后的点
            # Utils.showPoints(two_plane_points, args, spase_step=1, plane_paras=two_plane_paras)



            # 显示合并后平面上的点
            merge_points = rawPoints[merge_inpointsInd]
            # fig = plt.figure()
            # ax = fig.gca(projection='3d')
            # spase_step = 1
            # ax.scatter(merge_points[::spase_step, 0], merge_points[::spase_step, 1], merge_points[::spase_step, 2],
            #            c='r',
            #            marker='.', linewidths=0.1)
            # plt.title('合并后平面上的点%d'%(len(merge_inpointsInd)))
            # plt.show()


            if min_angle_index not in this_merge_index:
                this_merge_index.append(min_angle_index)
                # print('记录相似平面中已经合并过的平面为:')
                # print(this_merge_index)

            if min_angle_index not in plane_merged_index:
                plane_merged_index.append(min_angle_index)
                # print('记录合并过的平面%d,已经合并的平面为：'%(min_angle_index))
                # print(plane_merged_index)


        left_plane_index = [x for x in same_plane_index if x not in this_merge_index]
        left_plane_paras = []
        if len(left_plane_index)>0:
            for index in left_plane_index:
                left_plane_paras.append(planeParas[index])
            left_plane_paras = np.array(left_plane_paras)
            left_plane_paras = np.vstack((left_plane_paras,init_plane_para))
        else:
            left_plane_paras = np.expand_dims(init_plane_para,axis=0)

        # 显示合并后的平面
        # title = str(left_plane_index)
        # Utils.showPoints(rawPoints, args, spase_step=5, plane_paras=left_plane_paras,title=title)
        #
        # Utils.showPoints(rawPoints, args, spase_step=5, plane_paras=np.expand_dims(init_plane_para,axis=0), title=title)
        results.append(init_plane_para)




    print('合并后平面数量：%d'%(len(results)))
    results = np.array(results)
    all_points_2 = rawPoints.copy()
    for plane_para in results:
        normals = plane_para[0:3]
        normals = np.transpose(normals)
        d = plane_para[3]
        dists = np.abs(np.matmul(all_points_2, normals) - d)
        inpointsInd = np.where(dists < args.distThd)[0]
        all_points_2 = np.delete(all_points_2, inpointsInd, axis=0)
    print('合并平面操作后剩余点的个数%d'%(len(all_points_2)))
    # 显示删除剩下的点
    # fig = plt.figure()
    # ax = fig.gca(projection='3d')
    # spase_step = 5
    # ax.scatter(all_points_2[::spase_step, 0], all_points_2[::spase_step, 1], all_points_2[::spase_step, 2], c='r',
    #            marker='.', linewidths=0.1)
    # plt.show()

    print('共合并了%d个平面，合并前后点数变化%d'%((len(planeParas)-len(results)), (len(all_points_2)-len(allPoints))))

    #可视化最后的平面
    # for plane_para in results:
    #     plane_para = np.expand_dims(plane_para,axis=0)
    #     Utils.showPoints(rawPoints,args,spase_step=5, plane_paras=plane_para)
    #     print(len(rawPoints))

    endTime = time.time()
    # print('耗时%.5f'%(endTime-sTime))
    return results

parser = argparse.ArgumentParser(description='PointToPlane')
parser.add_argument('--distThd', dest='distThd',
                        help='default distance to judge whether a point is on plane',
                        default=0.1, type=float)
parser.add_argument('--corrThd', dest='corrThd',
                        help='default plane delete corr threshold is 0.9',
                        default=0.9, type=float)
parser.add_argument('--corrThd2', dest='corrThd2',
                        help='default plane fitting corr threshold is 0.997',
                        default=0.997, type=float)
parser.add_argument('--numThd', dest='numThd',
                        help='default plane corr threshold is 30',
                        default=50, type=int)
parser.add_argument('--angleThd', dest='angleThd',
                        help='default angleThd',
                        default=15, type=float)
parser.add_argument('--offsetThd', dest='offsetThd',
                        help='default offsetThd',
                        default=0.5, type=float)
parser.add_argument('--inPointsPer', dest='inPointsPer',
                        help='',
                        default=0.005, type=float)
parser.add_argument('--pointsPath', dest='pointsPath',
                        help='the number of planes to extract',
                        default='../data/indoor.ply', type=str)


args = parser.parse_args()
# args.pointsPath = r'E:\download\rapterData\empire\cloudRGBNormal_reProj_noUnass.ply'
args.pointsPath = r'../data/indoor.ply'
# 1.读取点云
print('start reading points mesh...')
plyPath = args.pointsPath
rawPoints = Utils.readMesh(plyPath)
print('finish reading points mesh...the all points length = %d'%(len(rawPoints)))
# Utils.showPoints(rawPoints,args,spase_step=5)
coordmax = np.max(rawPoints, axis=0)
coordmin = np.min(rawPoints, axis=0)
data_range = np.min(coordmax-coordmin)

# args.distThd = data_range * 0.01
# args.offsetThd = data_range * 0.06
args.distThd = 0.1
args.offsetThd = 0.5


# 2.对点云进行拟合
planeParas = plane_fitting(args, rawPoints)
planeParas = np.array(planeParas)


allPointsCopy = rawPoints.copy()
results = []
points_num_arr = np.array([])

for k in range(len(planeParas)):

    normals = planeParas[:, 0:3]
    normals = np.transpose(normals)
    ds = planeParas[:,3]
    ds = np.transpose(ds)

    dists = np.abs(np.matmul(allPointsCopy, normals) - ds)

    inDistNum = np.sum(np.where(dists<args.distThd, 1, 0),axis=0)
    maxPlaneInd = np.argmax(inDistNum)

    maxDists = dists[:, maxPlaneInd]
    maxInpointsInd = np.where(maxDists<args.distThd)[0]
    points_num_arr = np.append(points_num_arr, np.max(inDistNum))

    results.append(planeParas[maxPlaneInd])
    planeParas = np.delete(planeParas, maxPlaneInd, axis=0)
    allPointsCopy = np.delete(allPointsCopy, maxInpointsInd, axis=0)

results = np.array(results)
index = len(results)-1
while index > 0:
    points_num = points_num_arr[index]
    if points_num < len(rawPoints)*args.inPointsPer:
        results = results[0:index,]
        points_num_arr = np.delete(points_num_arr, index)
        index -= 1
    else:
        break
print('过滤掉小平面后，平面个数%d'%(len(results)))
print('过滤掉小平面后，剩余点数：%d'%(len(rawPoints)-np.sum(points_num_arr)))


# 可视化最后的平面
# for plane_para in results:
#     plane_para = np.expand_dims(plane_para, axis=0)
#     Utils.showPoints(rawPoints,args,spase_step=5,plane_paras=plane_para)

# 可视化剩余的点
# Utils.showPoints(allPointsCopy, args,spase_step=1)

