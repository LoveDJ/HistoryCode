import numpy as np
import matplotlib.pyplot as plt

out_rate_arr = np.load("out_rate_arr.npy")
methods = np.load("methods.npy")
rmse_arr_all = np.load("rmse_arr_all.npy")
rmse_err_all = np.load("rmse_err_all.npy")


fig = plt.figure()
ax = fig.gca()
plt.xlabel("Outlier Percentage")
plt.ylabel("RMSE")
for i in range(6):

    plt.errorbar(out_rate_arr, rmse_arr_all[:,i+1], yerr=rmse_err_all[:,i+1], label=methods[i+1], linewidth=2)

plt.legend(loc='upper left')
plt.grid(axis='y',linestyle='-.')
ax.set_ylim(bottom=0.)
ax.set_ylim(top=2.0)
plt.show()