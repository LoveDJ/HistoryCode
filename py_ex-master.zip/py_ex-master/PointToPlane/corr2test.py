import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

N = 400
x = np.random.rand(N)*2
y = np.random.rand(N)

plt.plot(x, y, '.')
plt.show()

while len(x)>N*0.1:
    max_corr = np.abs(np.corrcoef(x, y)[0][1])
    max_index = -1
    for i in range(len(x)):
        rxy = np.abs(np.corrcoef(np.delete(x, i), np.delete(y,i))[0][1])
        if rxy > max_corr:
            max_index = i
    x = np.delete(x, max_index)
    y = np.delete(y, max_index)


plt.plot(x, y, '.')
plt.show()
print('123')