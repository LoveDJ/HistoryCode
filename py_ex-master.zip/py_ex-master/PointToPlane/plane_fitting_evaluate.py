import argparse
import numpy as np
import os
from PointToPlane import pointToPlane_neighbor
parser = argparse.ArgumentParser(description='PointToPlane')
parser.add_argument('--distThd', dest='distThd',
                        help='default distance to judge whether a point is on plane',
                        default=0.05, type=float)
parser.add_argument('--corrThd', dest='corrThd',
                        help='default plane corr threshold is 0.99',
                        default=0.95, type=float)
parser.add_argument('--step', dest='step',
                        help='step of sparsing points',
                        default=1, type=int)
parser.add_argument('--pNum', dest='pNum',
                        help='the number of planes to extract',
                        default=10, type=int)
parser.add_argument('--pointsPath', dest='pointsPath',
                        help='the number of planes to extract',
                        default='../data/outdoor.ply', type=str)
parser.add_argument('--method', dest='method',
                        help='lsm ransac lsm_corr',
                        default='lsm_corr', type=str)
parser.add_argument('--add_noise', dest='add_noise',
                            help='signal noise ratio',
                        default=False, type=bool)
parser.add_argument('--noise_type', dest='noise_type',
                            help='gaussian poisson uniform rayleigh',
                        default='rayleigh', type=str)
parser.add_argument('--snr', dest='snr',
                            help='signal noise ratio',
                        default=20, type=int)


parser.add_argument('--split_x', dest='split_x',
                        help='split block number in x axis',
                        default=40, type=int)
parser.add_argument('--split_y', dest='split_y',
                        help='split block number in x axis',
                        default=40, type=int)
parser.add_argument('--split_z', dest='split_z',
                        help='split block number in x axis',
                        default=20, type=int)
args = parser.parse_args()
plane_mse_mean_arr = []
rate_arr = np.array([])
dist_arr = np.array([])
time_arr = np.array([])
rate_noise_arr = np.array([])
plane_mse_arr = np.array([])
dir_path = '../data/scanNet'
datas = os.listdir(dir_path)
datas = sorted(datas)

for i, file_name in enumerate(datas):
    if i > 9:
        break
    data_file = os.path.join(dir_path, file_name)

    if data_file.endswith('ply'):
        print(data_file)
        args.pointsPath = data_file
        args.add_noise = False
        rate, dist, time, planes = pointToPlane_neighbor.plane_fitting(args)
        rate_arr = np.append(rate_arr, rate)
        dist_arr = np.append(dist_arr, dist)
        time_arr = np.append(time_arr, time)

        # noise evaluate
        args.add_noise = True
        args.seed = i
        rate_noise, dist_noise, time_noise, planes_noise = pointToPlane_neighbor.plane_fitting(args)
        plane_mse = np.sum(np.power((planes - planes_noise), 2)) / len(planes_noise)
        rate_noise_arr = np.append(rate_noise_arr, rate_noise)
        plane_mse_arr = np.append(plane_mse_arr, plane_mse)
        print('plane_mse = %.5f'%(plane_mse))



print(rate_arr)
print(dist_arr)
print(time_arr)
print(plane_mse_arr)
rate_mean = np.mean(rate_arr)
dist_mean = np.mean(dist_arr)
time_mean = np.mean(time_arr)
rate_noise_mean = np.mean(rate_noise_arr)
plane_mse_mean = np.mean(plane_mse_arr)
print('rate_mean = %.5f'%(rate_mean))
print('dist_mean = %.5f'%(dist_mean))
print('time_mean = %.5f'%(time_mean))
print('rate_noise_mean = %.5f'%(rate_noise_mean))
print('plane_mse_mean = %.5f'%(plane_mse_mean))
plane_mse_mean_arr.append(plane_mse_mean)


