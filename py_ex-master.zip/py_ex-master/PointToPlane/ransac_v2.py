'''

use ransac to fit plane
author:dingjian
date:2019-08-14
email:jeanding001@163.com

'''
import matplotlib as mpl
from matplotlib import cm
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import random
import numpy as np
# ax+by+cz=d
def ransac(points, distThd=0.005, iterNum=50):
    maxInpointNum = 0
    maxA = None
    maxB = None
    maxC = None
    maxD = None
    # print('points length = %d , iterNum = %d , start iterate....'%(len(points), iterNum))
    for i in range(iterNum):
        # init plane by three points
        rs = random.sample(range(0, len(points)), 3)
        point_1 = points[rs[0]]
        point_2 = points[rs[1]]
        point_3 = points[rs[2]]

        plane_normal = np.cross((point_2 - point_1), (point_3 - point_1))
        if np.sum(plane_normal) == 0:
            continue
        plane_normal = plane_normal/np.sqrt(np.sum(plane_normal**2))
        d = np.dot(point_1, plane_normal)

        plane_normal = np.reshape(plane_normal, (3, 1))
        distanceArr = np.abs(np.matmul(points, plane_normal) - d)
        distanceArr = distanceArr[np.where(distanceArr<distThd)]
        inpointsLen = len(distanceArr)


        # choose the maximum inner points plane
        if inpointsLen > maxInpointNum:
            maxInpointNum = inpointsLen
            maxA = plane_normal[0][0]
            maxB = plane_normal[1][0]
            maxC = plane_normal[2][0]
            maxD = d
            continue

    if maxA <0:
        maxA = -maxA
        maxB = -maxB
        maxC = -maxC
        maxD = -maxD
    return maxA, maxB, maxC, maxD

'''
#points = np.array([[0,0,1],[0,1,-2],[1, 0, -1],[1,1,-4], [0,0,0.5]])
points = np.array([[1,1,2],[1,0,2],[1, 0, 1.5],[1, -1, 1.5],[0.99, -1, 1.5]])

a,b,c,d = ransac(points)

# show planes fitted by points
fig = plt.figure()
ax = fig.gca(projection='3d')
ax.scatter(points[:, 0], points[:, 1], points[:, 2], c='r', marker='.', linewidths=5)

ax.legend()
plt.show()

# show planes fitted by points
fig = plt.figure()
ax = fig.gca(projection='3d')
ax.scatter(points[:, 0], points[:, 1], points[:, 2], c='r', marker='.', linewidths=5)
X = np.arange(-1, 2, 0.25)
Y = np.arange(-1, 2, 0.25)
X, Y = np.meshgrid(X, Y)
Z = -(a / c) * X - (b / c) * Y + d / c

surf = ax.plot_surface(X, Y, Z, cmap=cm.Blues, linewidth=0, antialiased=False)
ax.legend()
plt.show()
'''


