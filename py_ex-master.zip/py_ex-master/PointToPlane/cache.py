# show points
color_arr = ['r','g','b','y','k']
fig = plt.figure()
ax = fig.gca(projection='3d')
for i,points in enumerate(pointSets):
    if len(points)>0:
        color = color_arr[i % 5]
        ax.scatter(points[:, 0], points[:, 1], points[:, 2], c=color, marker='.', linewidths=0.5)
plt.title('split')
ax.legend()
plt.show()


#show planes fitted by points
fig = plt.figure()
ax = fig.gca(projection='3d')
ax.scatter(points[:, 0], points[:, 1], points[:, 2], c='r', marker='.', linewidths=2.5)
coordmax = np.max(points, axis=0)
coordmin = np.min(points, axis=0)
Y = np.arange(coordmin[1], coordmax[1], 0.05)
Z = np.arange(coordmin[2], coordmax[2], 0.05)
Y,Z = np.meshgrid(Y,Z)
X = -(b / a) * Y - (c / a) * Z + d / a
surf = ax.plot_surface(X, Y, Z, cmap=cm.Blues, linewidth=0, antialiased=False)
plt.show()


showPoints = rawPoints.copy()
color_arr = [ 'g', 'b', 'y', 'k']
spase_step = 5
fig = plt.figure()
ax = fig.gca(projection='3d')
same_plane_paras = np.array([[-0.12389077,  0.42796602,  0.89526318,  5.15136718],[-0.936962,   -0.31970485,  0.14103552, -8.29127106]])
for i, plane_para in enumerate(same_plane_paras):
    normals = plane_para[0:3]
    normals = np.transpose(normals)
    d = plane_para[3]
    dists = np.abs(np.matmul(showPoints, normals) - d)
    inpointsInd = np.where(dists < args.distThd)[0]
    delPoints = showPoints[inpointsInd]
    color = color_arr[i % 4]
    ax.scatter(delPoints[::spase_step, 0], delPoints[::spase_step, 1], delPoints[::spase_step, 2], c=color, marker='.', linewidths=0.5)
    print('allPoints len=%d' % (len(showPoints)))
    showPoints = np.delete(showPoints, inpointsInd, axis=0)
    print('allPoints len=%d' % (len(showPoints)))

ax.scatter(showPoints[::spase_step, 0], showPoints[::spase_step, 1], showPoints[::spase_step, 2], c='r',
           marker='.', linewidths=0.1)
plt.show()

rawPointsX = rawPoints[:, 0]
rawPointsY = rawPoints[:, 1]
rawPointsZ = rawPoints[:, 2]
rawPointsX = rawPointsX - np.mean(rawPointsX)
rawPointsY = rawPointsY - np.mean(rawPointsY)
rawPointsZ = rawPointsZ - np.mean(rawPointsZ)

rawPointsX = np.expand_dims(rawPointsX, axis=1)
rawPointsY = np.expand_dims(rawPointsY, axis=1)
rawPointsZ = np.expand_dims(rawPointsZ, axis=1)

rawPoints = np.concatenate((rawPointsX,rawPointsY,rawPointsZ), axis=1)


# debug
    if m.status == GRB.Status.INFEASIBLE:
            print('Optimization was stopped with status %d' % m.status)
            # do IIS, find infeasible constraints
            m.computeIIS()
            for c in m.getConstrs():
                if c.IISConstr:
                    print('%s' % c.constrName)