'''

describe: generate one plane with gaussian noise

'''

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
from PointToPlane import Utils
from PointToPlane import leastSquareMethod as lsm


def reverseIndex(indexArr):

    n = -2
    while n > -len(indexArr)-1:
        newIndexArr = indexArr[n:]
        flag = newIndexArr[0]
        i = 1
        while i < len(newIndexArr):
            if newIndexArr[i] >= flag:
                newIndexArr[i] += 1
            i += 1
        indexArr[n:] = newIndexArr
        n -= 1
    return indexArr

# define a plane n=(3, 4, 5) d = 0.6
n_one = np.sqrt(3**2 + 4**2 + 5**2)
a_one = 3/n_one
b_one = 4/n_one
c_one = 5/n_one
d_one = 0.6
print('plane parameter a1 = %.5f, b1 = %.5f, c1 = %.5f, d1 = %.5f'%(a_one, b_one, c_one, d_one))


# define another plane n = (-4, 3, 5) d = 0.6
n_two = np.sqrt(4**2 + 3**2 + 5**2)
a_two = -4/n_two
b_two = 3/n_two
c_two = 5/n_two
d_two = 0.6
print('plane parameter a1 = %.5f, b1 = %.5f, c1 = %.5f, d1 = %.5f'%(a_two, b_two, c_two, d_two))

# config figure
fig = plt.figure()
ax = fig.gca(projection='3d')

# create plane points
x_one = np.linspace(-100, 100, 100)
y_one = np.linspace(-100, 100, 100)
x_one, y_one = np.meshgrid(x_one, y_one)
z_one = (d_one - a_one*x_one - b_one*y_one)/c_one
z_two = (d_two - a_two*x_one - b_two*y_one)/c_two

x_one = x_one.reshape((10000, 1))
y_one = y_one.reshape((10000, 1))
z_one = z_one.reshape((10000, 1))
z_two = z_two.reshape((10000, 1))

# create gaussian noise
mu = 0
sigma = 30

np.random.seed(0)
x_one_noise = np.random.randint(-100, 100, size=100)
x_one_noise = x_one_noise.reshape((100,1))
np.random.seed(1)
y_one_noise = np.random.randint(-100, 100, size=100)
y_one_noise = y_one_noise.reshape((100,1))

D_one = np.random.normal(mu, sigma, 100)
D_one = D_one.reshape((100, 1))
z_one_noise = (D_one - a_one*x_one_noise - b_one*y_one_noise + d_one)/c_one

np.random.seed(0)
x_two_noise = np.random.randint(-100, 100, size=100)
x_two_noise = x_two_noise.reshape((100,1))
np.random.seed(1)
y_two_noise = np.random.randint(-100, 100, size=100)
y_two_noise = y_two_noise.reshape((100,1))

D_two = np.random.normal(mu, sigma, 100)
D_two = D_two.reshape((100, 1))
z_two_noise = (D_two - a_two*x_two_noise - b_two*y_two_noise + d_two)/c_two

# add gaussian noise
x = np.concatenate((x_one, x_one, x_one_noise, x_two_noise), axis=0)
y = np.concatenate((y_one, y_one, y_one_noise, y_two_noise), axis=0)
z = np.concatenate((z_one, z_two, z_one_noise, z_two_noise), axis=0)


points = np.concatenate((x, y, z), axis = 1)
# build three vectors to calculate correlation
pointX = points[:,0]
pointY = points[:,1]
pointZ = points[:,2]



# mean = 0
Xmean = np.mean(pointX)
Ymean = np.mean(pointY)
Zmean = np.mean(pointZ)

pointX = pointX - Xmean
pointY = pointY - Ymean
pointZ = pointZ - Zmean

# length = 1
pointX = pointX / np.sqrt(np.sum(np.power(pointX, 2)))
pointY = pointY / np.sqrt(np.sum(np.power(pointY, 2)))
pointZ = pointZ / np.sqrt(np.sum(np.power(pointZ, 2)))


maxIndexArr = []

while True:
    r1 = Utils.Corr3_vector(pointX, pointY, pointZ)

    delIndex = Utils.Corr3_sub(pointX, pointY, pointZ)
    maxIndexArr.append(delIndex)

    delPointX = pointX[delIndex]
    delPointY = pointY[delIndex]
    delPointZ = pointZ[delIndex]

    pointX = np.delete(pointX, delIndex)
    pointY = np.delete(pointY, delIndex)
    pointZ = np.delete(pointZ, delIndex)

    r2 = Utils.Corr3_vector(pointX, pointY, pointZ)

    print('corr before delete = %.5f'%(r1))
    print('corr after delete = %.5f' % (r2))

    Xmean = -delPointX / len(pointX)
    Ymean = -delPointY / len(pointY)
    Zmean = -delPointZ / len(pointZ)

    Xm = np.sqrt((1 - delPointX ** 2))
    Ym = np.sqrt((1 - delPointY ** 2))
    Zm = np.sqrt((1 - delPointZ ** 2))

    pointX = (pointX + Xmean) / Xm
    pointY = (pointY + Ymean) / Ym
    pointZ = (pointZ + Zmean) / Zm

    r3 = Utils.Corr3_vector(pointX, pointY, pointZ)

    if r3 > 0.98:
        break

# show results after delete
ax.scatter(pointX, pointY, pointZ, c='r', marker='o')
ax.legend()

plt.show()

'''
pointX = np.expand_dims(pointX, axis=1)
pointY = np.expand_dims(pointY, axis=1)
pointZ = np.expand_dims(pointZ, axis=1)
resultPoints = np.concatenate((pointX, pointY, pointZ), axis=1)

at, bt, ct = lsm.leastSquare(resultPoints)
print('plane parameter a = %.5f, b = %.5f, c = %.5f'%(at, bt, ct))

print(len(maxIndexArr))
print(maxIndexArr)
maxIndexArr = reverseIndex(maxIndexArr)
print(np.sort(maxIndexArr))
points = np.delete(points, maxIndexArr, axis=0)
ar, br, cr = lsm.leastSquare(points)
print('plane parameter a = %.5f, b = %.5f, c = %.5f'%(ar*0.6, br*0.6, cr*0.6))
ax.scatter(points[:,0], points[:,1], points[:,2], c='r', marker='o')
ax.legend()

plt.show()
'''
