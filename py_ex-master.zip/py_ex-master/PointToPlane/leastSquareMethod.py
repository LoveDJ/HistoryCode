'''
describe: least square method to fit plane
date: 2019-10-10
author: dingjian
lsm reference blog: https://blog.csdn.net/konglingshneg/article/details/82585868
'''
import matplotlib as mpl
from matplotlib import cm
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

# ax+by+cz=d
def leastSquare(points):
    # read points mesh or use util.readMesh()

    x_vector = points[:, 0]
    y_vector = points[:, 1]
    z_vector = points[:, 2]

    A11 = np.sum(x_vector * x_vector)
    A12 = np.sum(x_vector * y_vector)
    A13 = np.sum(x_vector)

    A21 = A12
    A22 = np.sum(y_vector * y_vector)
    A23 = np.sum(y_vector)

    A31 = A13
    A32 = A23
    A33 = len(points)

    B1 = np.sum(x_vector * z_vector)
    B2 = np.sum(y_vector * z_vector)
    B3 = np.sum(z_vector)

    D = np.linalg.det(np.array([[A11, A12, A13],
                                [A21, A22, A23],
                                [A31, A32, A33]]))
    D1 = np.linalg.det(np.array([[B1, A12, A13],
                                [B2, A22, A23],
                                [B3, A32, A33]]))
    D2 = np.linalg.det(np.array([[A11, B1, A13],
                                [A21, B2, A23],
                                [A31, B3, A33]]))
    D3 = np.linalg.det(np.array([[A11, A12, B1],
                                [A21, A22, B2],
                                [A31, A32, B3]]))
    a = D1/D
    b = D2/D
    c = D3/D
    print(a)
    print(b)

    ct = 1 / c
    at = -a * ct
    bt = -b * ct

    m = np.sqrt(ct**2 + at**2 + bt**2)
    at = at / m
    bt = bt / m
    ct = ct / m
    dt = 1 / m

    if at < 0:
        at = -at
        bt = -bt
        ct = -ct
        dt = -dt
    return at, bt, ct, dt

'''test
points = np.array([[0,0,1],[0,1,-2],[1, 0, -1],[1,1,-4], [0,0,0.5]])

a,b,c,d = leastSquare(points)
# show planes fitted by points
fig = plt.figure()
ax = fig.gca(projection='3d')
ax.scatter(points[:, 0], points[:, 1], points[:, 2], c='r', marker='.', linewidths=0.5)
X = np.arange(0, 1, 0.25)
Y = np.arange(0, 1, 0.25)
X, Y = np.meshgrid(X, Y)
Z = -(a / c) * X - (b / c) * Y + d / c

surf = ax.plot_surface(X, Y, Z, cmap=cm.Blues, linewidth=0, antialiased=False)
ax.legend()
plt.show()
'''