import unittest
import numpy as np
from PointToPlane import corrFitMethod


class utilsTestCase(unittest.TestCase):

    def test_Fit(self):
        # x+y+z = 1
        # a = np.array([[1,1,-1],[2,2,-3],[3,3,-5]])
        # a_paras = corrFitMethod.Fit(a)
        # print(a_paras)

        b = np.array([[1,1,0],[2,1,-1],[3,1,-2]])
        b_paras = corrFitMethod.Fit(b)
        print(b_paras)

