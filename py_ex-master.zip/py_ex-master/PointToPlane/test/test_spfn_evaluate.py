import unittest
import numpy as np
import argparse
from PointToPlane import spfn_evaluate as spfn
parser = argparse.ArgumentParser(description='PointToPlane')
parser.add_argument('--distThd', dest='distThd',
                            help='default distance to judge whether a point is on plane',
                            default=0.05, type=float)
parser.add_argument('--pNum', dest='pNum',
                            help='the number of planes to extract',
                            default=10, type=int)
args = parser.parse_args()
class utilsTestCase(unittest.TestCase):

    def test_get_paras_and_rate(self):

        all_points = np.array([[0, 1, np.sqrt(3)-1], [1, 0, np.sqrt(3)-1], [1, 1, np.sqrt(3)-2]])
        all_plane_paras = np.array([[np.sqrt(3)/3, np.sqrt(3)/3, np.sqrt(3)/3, 1]])
        plane_paras_results, inner_rate = spfn.get_paras_and_rate(all_plane_paras, all_points, args)
        self.assertEqual(inner_rate, 1.0)
        self.assertEqual(len(all_plane_paras), 1)
        self.assertEqual(all_plane_paras.shape[0], 1)
        self.assertEqual(all_plane_paras.shape[1], 4)
