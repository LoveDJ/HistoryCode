import unittest
from PointToPlane import Utils

class utilsTestCase(unittest.TestCase):

    def test_read_mesh(self):
        points_path = '../../data/test/scene0000_00_vh_clean_2.labels.ply'
        points = Utils.readMesh(points_path)
        self.assertEqual(len(points), 81369)

    def test_read_mesh_step(self):
        points_path = '../../data/test/scene0000_00_vh_clean_2.labels.ply'
        points = Utils.readMesh(points_path, step=10)
        self.assertEqual(len(points), 8136)