import cv2 as cv
import numpy as np
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from PointToPlane import Utils

spase_step = 100

img = cv.imread('../data/HW3.png', cv.IMREAD_GRAYSCALE)
cv.imshow('win', img)
cv.waitKey(0)

img1D = np.reshape(img, -1)
z = img1D
x = []
for i in range(img.shape[0]):
    for j in range(img.shape[1]):
        x.append(i+1)
x = np.array(x)

y = []
for i in range(img.shape[0]):
    for j in range(img.shape[1]):
        y.append(j+1)
y = np.array(y)

fig = plt.figure()
ax = fig.gca(projection='3d')
ax.scatter(x[::spase_step], y[::spase_step], z[::spase_step], s=2)
plt.show()
print(len(x))

sX = x[::spase_step]
xY = y[::spase_step]
sZ = z[::spase_step]

delNum = 1
delCount = int(len(sX)*0.2)
delPointX = []
delPointY = []
delPointZ = []
for i in range(delCount):
    print('delCount:%d  now:%d'%(delCount, i))
    delIndexArr = Utils.Corr3_delete(sX, xY, sZ, delNum)
    delPointX.append(sX[delIndexArr])
    delPointY.append(xY[delIndexArr])
    delPointZ.append(sZ[delIndexArr])
    sX = np.delete(sX, delIndexArr)
    xY = np.delete(xY, delIndexArr)
    sZ = np.delete(sZ, delIndexArr)
    fig = plt.figure()
    ax = fig.gca(projection='3d')
    ax.scatter(sX, xY, sZ, marker='.',c='xkcd:red', linewidths=0.1)
    ax.scatter(delPointX, delPointY, delPointZ, c='b', marker='.', linewidths=0.1)
    plt.show()

print('123')