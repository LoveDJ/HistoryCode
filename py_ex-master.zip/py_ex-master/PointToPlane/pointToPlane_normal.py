'''
points to plane
author: ding jian
date:2019-08-06
email:jeanding001@163.com

'''

from plyfile import PlyData
import numpy as np
import math
import os
import time
import argparse
from PointToPlane import Utils


parser = argparse.ArgumentParser(description='PointToPlane')
parser.add_argument('--threshold', dest='threshold',
                        help='default threshold is 0.99',
                        default=0.99, type=float)
parser.add_argument('--step', dest='step',
                        help='step of sparsing points',
                        default=1, type=int)
args = parser.parse_args()


plyPath = '../data/indoor.ply'
points = Utils.readMesh(plyPath,step=args.step)

# build three vectors to calulate correlation
pointX = points[:,0]
pointY = points[:,1]
pointZ = points[:,2]
# mean = 0
Xmean = np.mean(pointX)
Ymean = np.mean(pointY)
Zmean = np.mean(pointZ)

pointX = pointX - Xmean
pointY = pointY - Ymean
pointZ = pointZ - Zmean

# length = 1
pointX = pointX / np.sqrt(np.sum(np.power(pointX, 2)))
pointY = pointY / np.sqrt(np.sum(np.power(pointY, 2)))
pointZ = pointZ / np.sqrt(np.sum(np.power(pointZ, 2)))

delPointsX = []
delPointsY = []
delPointsZ = []


while True:
    r1 = Utils.Corr3_vector(pointX, pointY, pointZ)

    delIndex = Utils.Corr3_sub(pointX, pointY, pointZ)
    delPointX = pointX[delIndex]
    delPointY = pointY[delIndex]
    delPointZ = pointZ[delIndex]

    delPointsX.append(pointX[delIndex])
    delPointsY.append(pointY[delIndex])
    delPointsZ.append(pointZ[delIndex])

    pointX = np.delete(pointX, delIndex)
    pointY = np.delete(pointY, delIndex)
    pointZ = np.delete(pointZ, delIndex)

    # print('corr before delete = %.5f'%(r1))
    # print('corr after delete = %.5f' % (r2))

    Xmean = -delPointX / len(pointX)
    Ymean = -delPointY / len(pointY)
    Zmean = -delPointZ / len(pointZ)

    Xm = np.sqrt((1 - delPointX ** 2))
    Ym = np.sqrt((1 - delPointY ** 2))
    Zm = np.sqrt((1 - delPointZ ** 2))

    pointX = (pointX + Xmean) / Xm
    pointY = (pointY + Ymean) / Ym
    pointZ = (pointZ + Zmean) / Zm

    r3 = Utils.Corr3_vector(pointX, pointY, pointZ)
    # print('corr after delete = %.5f'%(r3))

    if r3 > 0.9:
        break


delPointsX = np.expand_dims(delPointsX, axis=1)
delPointsY = np.expand_dims(delPointsY, axis=1)
delPointsZ = np.expand_dims(delPointsZ, axis=1)

delPoints = np.concatenate((delPointsX, delPointsY, delPointsZ), axis=1)

pointX = np.expand_dims(pointX, axis=1)
pointY = np.expand_dims(pointY, axis=1)
pointZ = np.expand_dims(pointZ, axis=1)

newPoints = np.concatenate((pointX, pointY, pointZ), axis=1)


total_num = len(newPoints)
print('len(delPoints) = %d len(newPoints) = %d'%(len(delPoints), len(newPoints)))
if os.path.exists('./point_red_n'+str(args.threshold)+'.ply'):
    os.remove('./point_red_n'+str(args.threshold)+'.ply')
    f2 = open('./point_red_n'+str(args.threshold)+'.ply', 'w')
    f2.close()

file = open('./point_red_n'+str(args.threshold)+'.ply','a+')

file.write('ply\n')
file.write('format ascii 1.0\n')
file.write('element vertex %d\n'%(total_num))
file.write('property float x\n')
file.write('property float y\n')
file.write('property float z\n')
file.write('property uchar red\n')
file.write('property uchar green\n')
file.write('property uchar blue\n')
file.write('end_header\n')


# for point in delPoints:
#     xw = point[0]
#     yw = point[1]
#     zw = point[2]
#     file.write(str(xw) + ' ' + str(yw) + ' ' + str(zw) +' 255 0 0\n')

for newPoint in newPoints:
    new_xw = newPoint[0]
    new_yw = newPoint[1]
    new_zw = newPoint[2]
    file.write(str(new_xw) + ' ' + str(new_yw) + ' ' + str(new_zw) + ' 0 255 0\n')


file.close()
#
# if os.path.exists('./point2.ply'):
#     os.remove('./point2.ply')
#     f2 = open('./point2.ply', 'w')
#     f2.close()
#
# file = open('./point2.ply','a+')
#
# file.write('ply\n')
# file.write('format ascii 1.0\n')
# file.write('element vertex 959860\n')
# file.write('property float x\n')
# file.write('property float y\n')
# file.write('property float z\n')
# file.write('property uchar red\n')
# file.write('property uchar green\n')
# file.write('property uchar blue\n')
# file.write('end_header\n')
#
#
#
#         file.write(str(xw) + ' ' + str(yw) + ' ' + str(zw) + ' 0 255 0\n')
#
# file.close()