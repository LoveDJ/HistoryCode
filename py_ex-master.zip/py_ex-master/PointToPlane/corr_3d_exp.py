import numpy as np
from PointToPlane import Utils
import matplotlib.pyplot as plt

points = Utils.readxyz('../data/fitting/nonplane1.txt')
delNum = int(len(points)*0.06)
delCount = 8

# 显示原始数据点
# fig = plt.figure()
# ax = fig.gca(projection='3d')
# ax.scatter(points[:, 0], points[:, 1], points[:, 2], marker='.',c='b')
# plt.show()

colors = ['xkcd:blue', 'xkcd:yellow', 'xkcd:green', 'xkcd:purple', 'xkcd:orange', 'xkcd:lilac', 'xkcd:cyan', 'xkcd:black']
delPointXArr = []
delPointYArr = []
delPointZArr = []
for i in range(delCount):
    delIndexArr = Utils.Corr3_delete(points[:, 0], points[:, 1], points[:, 2], delNum)
    delPointXArr.append(points[:,0][delIndexArr])
    delPointYArr.append(points[:,1][delIndexArr])
    delPointZArr.append(points[:,2][delIndexArr])
    points = np.delete(points, delIndexArr, axis=0)
fig = plt.figure()
ax = fig.gca(projection='3d')
ax.scatter(points[:, 0], points[:, 1], points[:, 2], marker='.',c='xkcd:red', linewidths=0.1)
for v in range(len(delPointXArr)):
    ax.scatter(delPointXArr[v], delPointYArr[v], delPointZArr[v], c=colors[v], marker='.', linewidths=0.1)
ax.grid(False)
ax.set_xticks([])#不显示x坐标轴
ax.set_yticks([])#不显示y坐标轴
ax.set_zticks([])#不显示z坐标轴
plt.axis('off')#关闭所有坐标轴
plt.show()
