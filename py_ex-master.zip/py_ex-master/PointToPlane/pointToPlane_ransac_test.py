'''

use ransac to fit plane
author:dingjian
date:2019-08-14
email:jeanding001@163.com

'''

from plyfile import PlyData
import numpy as np
import math
import os
import time
import random
import argparse
from sympy import *



def readMesh(plyPath, step = 1):

    plydata = PlyData.read(plyPath)
    vertices = plydata['vertex']
    points = np.stack([vertices['x'], vertices['y'], vertices['z']], axis=1)

    newPoints = []
    for i in range(int(len(points)/step)):
        newPoints.append(points[i*step])
    newPoints = np.array(newPoints)
    return newPoints


parser = argparse.ArgumentParser(description='PointToPlane')
parser.add_argument('--distThd', dest='distThd',
                        help='default distance threshold is 0.05',
                        default=0.05, type=float)
parser.add_argument('--proThd', dest='pro_thd',
                        help='default proportion threshold is 0.3',
                        default=0.3, type=float)
parser.add_argument('--step', dest='step',
                        help='step of sparsing points',
                        default=1, type=int)

parser.add_argument('--iterNum', dest='iterNum',
                        help='step of sparsing points',
                        default=1000, type=int)

args = parser.parse_args()


plyPath = './data/indoor.ply'
points = readMesh(plyPath,step=args.step)


a = 0.1
b = -0.13
c = 18.47

if os.path.exists('./point_red_r'+str(args.distThd)+'.ply'):
    os.remove('./point_red_r'+str(args.distThd)+'.ply')
    f2 = open('./point_red_r'+str(args.distThd)+'.ply', 'w')
    f2.close()

file = open('./point_red_r'+str(args.distThd)+'.ply','a+')

file.write('ply\n')
file.write('format ascii 1.0\n')
file.write('element vertex %d\n'%(len(points)))
file.write('property float x\n')
file.write('property float y\n')
file.write('property float z\n')
file.write('property uchar red\n')
file.write('property uchar green\n')
file.write('property uchar blue\n')
file.write('end_header\n')


for point in points:
    x = point[0]
    y = point[1]
    z = point[2]
    comn = np.sqrt(np.square(a) + np.square(b) + np.square(c))
    d = np.abs(a * x + b * y + c * z - 1) / comn

    if d < args.distThd:
        file.write(str(x) + ' ' + str(y) + ' ' + str(z) + ' 0 255 0\n')
    else:
        file.write(str(x) + ' ' + str(y) + ' ' + str(z) + ' 255 0 0\n')