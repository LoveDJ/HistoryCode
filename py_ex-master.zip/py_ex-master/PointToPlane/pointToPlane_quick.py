'''
points to plane
author: ding jian
date:2019-08-06
email:jeanding001@163.com

'''

from plyfile import PlyData
import numpy as np
import math
import os
import time
import argparse
from random import shuffle

parser = argparse.ArgumentParser(description='PointToPlane')
parser.add_argument('--threshold', dest='threshold',
                        help='default threshold is 0.99',
                        default=0.99, type=float)
parser.add_argument('--is_random', dest='is_random',
                        help='random all points',
                        default=True, type=bool)
parser.add_argument('--step', dest='step',
                        help='step of sparsing points',
                        default=1, type=int)
args = parser.parse_args()

if os.path.exists('./log.txt'):
    os.remove('./log.txt')
    newLog = open('./log.txt', 'w')
    newLog.close()

log = open('./log.txt','a+')



def readMesh(plyPath, step = 1):

    plydata = PlyData.read(plyPath)
    vertices = plydata['vertex']
    points = np.stack([vertices['x'], vertices['y'], vertices['z']], axis=1)
    #faces = np.array(plydata['face']['vertex_indices'])

    newPoints = []
    for i in range(int(len(points)/step)):
        newPoints.append(points[i*step])
    if args.is_random:
        shuffle(newPoints)
    newPoints = np.array(newPoints)
    return newPoints

# calculate correlation of 3 vectors
def Corr3(pointX, pointY, pointZ):


    Rxy = np.corrcoef(pointX, pointY)
    Rxz = np.corrcoef(pointX, pointZ)
    Ryz = np.corrcoef(pointY, pointZ)

    Rxy = Rxy[0][1]
    Rxz = Rxz[0][1]
    Ryz = Ryz[0][1]

    Rxyz = np.sqrt(math.pow(Rxy, 2)+math.pow(Rxz, 2)+math.pow(Ryz, 2)-2*Rxy*Rxz*Ryz)
    return Rxyz

plyPath = './data/indoor.ply'
points = readMesh(plyPath, step=args.step)
print(points.shape)
# build three vectors to calulate correlation
pointX = points[:,0]
pointY = points[:,1]
pointZ = points[:,2]

delPointsX = []
delPointsY = []
delPointsZ = []

while True:
    initRxyz = Corr3(pointX, pointY, pointZ)
    start = time.time()
    i = 0
    while i < len(pointX):
        newPointX = np.delete(pointX, i)
        newPointY = np.delete(pointY, i)
        newPointZ = np.delete(pointZ, i)
        newRxyz = Corr3(newPointX, newPointY, newPointZ)
        if newRxyz > initRxyz:
            delPointsX.append(pointX[i])
            delPointsY.append(pointY[i])
            delPointsZ.append(pointZ[i])

            pointX = np.delete(pointX, i)
            pointY = np.delete(pointY, i)
            pointZ = np.delete(pointZ, i)
            break
        i = i+1
    end = time.time()
    print('one iteration consume time = %.2f'%(end-start))
    #log.write('max Rxyz = '+str(initRxyz)+'\n')
    print('init Rxyz = %f\n'%(initRxyz))

    #log.write('pointX length = ' + str(len(pointX))+'\n')
    print('pointX length = %d\n'%(len(pointX)))
    if initRxyz>args.threshold:
        break

log.close()

delPointsX = np.expand_dims(delPointsX, axis=1)
delPointY = np.expand_dims(delPointsY, axis=1)
delPointsZ = np.expand_dims(delPointsZ, axis=1)

delPoints = np.concatenate((delPointsX, delPointY, delPointsZ), axis=1)

pointX = np.expand_dims(pointX, axis=1)
pointY = np.expand_dims(pointY, axis=1)
pointZ = np.expand_dims(pointZ, axis=1)

newPoints = np.concatenate((pointX, pointY, pointZ), axis=1)


total_num = len(delPoints)+len(newPoints)

if os.path.exists('./point_red_quick'+str(args.threshold)+'.ply'):
    os.remove('./point_red_quick'+str(args.threshold)+'.ply')
    f2 = open('./point_red_quick'+str(args.threshold)+'.ply', 'w')
    f2.close()

file = open('./point_red_quick'+str(args.threshold)+'.ply','a+')

file.write('ply\n')
file.write('format ascii 1.0\n')
file.write('element vertex %d\n'%(total_num))
file.write('property float x\n')
file.write('property float y\n')
file.write('property float z\n')
file.write('property uchar red\n')
file.write('property uchar green\n')
file.write('property uchar blue\n')
file.write('end_header\n')


for point in delPoints:
    xw = point[0]
    yw = point[1]
    zw = point[2]
    file.write(str(xw) + ' ' + str(yw) + ' ' + str(zw) +' 255 0 0\n')

for newPoint in newPoints:
    new_xw = newPoint[0]
    new_yw = newPoint[1]
    new_zw = newPoint[2]
    file.write(str(new_xw) + ' ' + str(new_yw) + ' ' + str(new_zw) + ' 0 255 0\n')


file.close()
