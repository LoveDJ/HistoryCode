import numpy as np
from PointToPlane import Utils

paras = [[0.000586911, -0.00309031, 0.999995, 0.0503245],
         [-0.330815, 0.940661, 0.075619, -0.535218],
         [0.943765, 0.328048, 0.0411399, 2.00548],
         [-0.35269, 0.934147, -0.0545858, 5.59261],
         [-0.336699, 0.941578, -0.00807878, 6.22019],
         [0.93575, 0.352636, 0.00433392, 8.77787],
         [0.953459, 0.301088, -0.0161916, 6.46339],
         [0.938914, -0.338578, 0.0616864, -0.964838],
         [-0.156213, 0.40794, 0.899546, 4.89172],
         [0.93616, 0.351571, -0.00152262, 8.67207]]

points = Utils.readMesh('/home/dj/code/python/py_ex/data/scanNet/scene0000_00_vh_clean_2.labels.ply')
allPointsCopy = points.copy()
allDist = 0
allNum = 0
paras = np.array(paras)
for i in range(10):
    if len(paras) == 0:
        break
    normals = paras[:, 0:3]
    normals = np.transpose(normals)
    ds = paras[:, 3]
    ds = np.transpose(ds)
    dists = np.abs(np.matmul(allPointsCopy, normals) - ds)

    inDistNum = np.sum(np.where(dists < 0.05, 1, 0), axis=0)

    maxPlaneInd = np.argmax(inDistNum)
    maxDists = dists[:, maxPlaneInd]
    maxInpointsInd = np.where(maxDists < 0.05)[0]

    allDist += np.sum(maxDists[maxInpointsInd])
    allNum += np.max(inDistNum)
    print('inDistNum = %d' % (np.max(inDistNum)))
    planeParas = np.delete(paras, maxPlaneInd, axis=0)
    allPointsCopy = np.delete(allPointsCopy, maxInpointsInd, axis=0)

inner_points_rate = (len(points)-len(allPointsCopy))/len(points)
mean_distance = allDist/allNum
print('inner_points_rate = %.5f' % (inner_points_rate))
print('mean_distance = %.5f '%(mean_distance))