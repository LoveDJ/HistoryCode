import os
import numpy as np

dir_path = '/home/dj/code/python/py_ex/results/eransac'
files = os.listdir(dir_path)
files = sorted(files)

rate = []
for i, file_name in enumerate(files):
    file_path = os.path.join(dir_path, file_name)
    file = open(file_path)

    numberArr = [int(number) for number in file.readlines()]

    numberArr = sorted(numberArr, reverse=True)

    allPointsLen = numberArr[0]
    inPointsLen = sum(numberArr[1:11])
    print(inPointsLen/allPointsLen)
    rate.append(inPointsLen/allPointsLen)

mean_rate = sum(rate)/10
print('mean_rate = %.5f'%(mean_rate))