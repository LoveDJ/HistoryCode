import numpy as np
import gurobipy as gp
from gurobipy import GRB
from sklearn import metrics
import random
from PointToPlane import leastSquareMethod as lsm
from PointToPlane import corrFitMethod
from PointToPlane import Utils
from PointToPlane import ransac_v2 as ransac
from PointToPlane import rpca as rpca
import matlab.engine
import warnings
warnings.filterwarnings("ignore")

eng = matlab.engine.start_matlab()


mean_rmse = np.zeros(7)
mean_angle = np.zeros(7)
mean_acc = np.zeros(7)
mean_f1 = np.zeros(7)
gt_a = 3
gt_b = 4
gt_c = 5
gt_d = 6

inpoints_num = 1000
out_rate = 0.5
outpoints_num = int(np.ceil(out_rate * inpoints_num / (1 - out_rate)))
SNR = 30
for t in range(1000):
    # 3x + 4y + 5z = 6
    #***************************生成数据***************************


    points_x = np.zeros(inpoints_num)
    points_y = np.zeros(inpoints_num)
    points_z = np.zeros(inpoints_num)
    for i in range(inpoints_num):
        num_x = random.randint(-50, 50)
        num_y = random.randint(-50, 50)
        points_x[i] = num_x
        points_y[i] = num_y
        points_z[i] = (gt_d - gt_a * num_x - gt_b * num_y) / gt_c

    # 对平面上的点添加噪声
    x_var = np.var(points_x)
    sigma = np.sqrt(x_var / np.power(10, 0.1 * SNR))
    noise_x = np.random.normal(loc=0, scale=sigma, size=inpoints_num)

    y_var = np.var(points_y)
    sigma = np.sqrt(y_var / np.power(10, 0.1 * SNR))
    noise_y = np.random.normal(loc=0, scale=sigma, size=inpoints_num)

    z_var = np.var(points_z)
    sigma = np.sqrt(z_var / np.power(10, 0.1 * SNR))
    noise_z = np.random.normal(loc=0, scale=sigma, size=inpoints_num)

    # add noise
    points_x = points_x + noise_x
    points_y = points_y + noise_y
    points_z = points_z + noise_z



    thd_dist = np.max((gt_a*points_x+gt_b*points_y+gt_c*points_z-gt_d)/np.sqrt(gt_a**2+gt_b**2+gt_c**2))

    outlier_x = np.random.randint(-50, 50, size=outpoints_num)
    outlier_y = np.random.randint(-50, 50, size=outpoints_num)
    outlier_z = np.random.randint(-50, 50, size=outpoints_num)

    X = np.append(points_x, outlier_x)
    Y = np.append(points_y, outlier_y)
    Z = np.append(points_z, outlier_z)
    all_points = np.transpose(np.vstack((X, Y, Z)))

    raw_points = all_points.copy()
    all_points2 = all_points.copy()
    all_points3 = all_points.copy()



    #mestimator
    lista = all_points[:,0:2].tolist()
    lista = matlab.double(lista)
    listb = all_points[:,2].tolist()
    listb = matlab.double(listb)
    w6 = eng.robustfit(lista, listb, 'huber')
    w6 = Utils.normc([-w6[1][0], -w6[2][0], 1, w6[0][0]])
    if w6[0] < 0:
        w6 = -w6



    #dpcp_psgm
    inliers = np.vstack((points_x, points_y, points_z, np.ones(inpoints_num))) # 4*100
    outliers = np.vstack((outlier_x,outlier_y,outlier_z,np.ones(outpoints_num))) # 4*out_numbers
    inliers = Utils.normc(inliers) # 4*100
    outliers = Utils.normc(outliers) # 4*out_numbers
    X_tilde = np.hstack((inliers, outliers))

    X_tilde = matlab.double(X_tilde.tolist())
    beta = 1 / 2
    w7 = eng.DPCP_PSGM_optim_J(X_tilde, 1, 1e-9, beta, 500, 1e-6)
    w7 = np.array([w7[0][0], w7[1][0], w7[2][0], -w7[3][0]])
    if w7[0] < 0:
        w7 = -w7
    #rpca
    A = rpca.alternating_direction_method_of_multipliers(all_points, lmbda=1)
    w5 = lsm.leastSquare(A[0])
    w5 = Utils.normc(w5)


    # s2r2拟合结果
    a3 = 0
    b3 = 0
    c3 = 0
    d3 = 0
    w = np.ones(inpoints_num + outpoints_num)
    epcho = 1
    for s in range(epcho):

        m = gp.Model("demo2")
        r_arr = []
        for i in range(3):
            r_arr.append(m.addVar(lb=-1e20, vtype=GRB.CONTINUOUS, name="r" + str(i)))

        ri_arr = [[] for i in range(inpoints_num + outpoints_num)]
        for i in range(inpoints_num + outpoints_num):
            for j in range(3):
                ri_arr[i].append(m.addVar(lb=-1e20, vtype=GRB.CONTINUOUS, name="ri" + str(i) + str(j)))
        z_arr = {}
        for i in range(inpoints_num + outpoints_num):
            z_arr[i] = m.addVar(lb=-1e20, vtype=GRB.CONTINUOUS, name="z" + str(i))

        m.setObjective((gp.quicksum(z_arr[z] for z in z_arr)), GRB.MINIMIZE)

        for i in range(inpoints_num + outpoints_num):
            for j in range(3):
                m.addConstr(z_arr[i] >= w[i] * (r_arr[j] - ri_arr[i][j]), name="c0" + str(i) + str(j))
                m.addConstr(z_arr[i] >= w[i] * (ri_arr[i][j] - r_arr[j]), name="c1" + str(i) + str(j))
            m.addConstr((X[i] * ri_arr[i][0] + Y[i] * ri_arr[i][1] + ri_arr[i][2] - Z[i]) <= 0.005, name="c2" + str(i))
            m.addConstr((X[i] * ri_arr[i][0] + Y[i] * ri_arr[i][1] + ri_arr[i][2] - Z[i]) >= -0.005, name="c3" + str(i))

        m.optimize()
        for j in range(inpoints_num + outpoints_num):
            for v in m.getVars():
                if v.varName == "z" + str(j):
                    w[j] = 1 / (v.x + 0.01)

        if s == epcho - 1:
            for v in m.getVars():
                if v.varName == "r0":
                    a3 = -v.x * 5
                    print('%s %g' % (v.varName, v.x))
                if v.varName == "r1":
                    b3 = -v.x * 5
                    print('%s %g' % (v.varName, v.x))
                if v.varName == "r2":
                    d3 = v.x * 5
                    print('%s %g' % (v.varName, v.x))
                c3 = 5

    w3 = Utils.normc([a3, b3, c3, d3])
    if w3[0]<0:
        w3 = -w3



    # 最小二乘法拟合结果
    while (len(all_points) > inpoints_num):
        a, b, c, d = lsm.leastSquare(all_points)
        normal = np.array([a, b, c])
        dist = np.abs(np.matmul(all_points, normal) - d)
        maxPlaneId = np.argsort(dist)
        all_points = np.delete(all_points, maxPlaneId[-int(np.ceil(outpoints_num/10)):], axis=0)
    w1 = lsm.leastSquare(all_points)
    w1 = Utils.normc(w1)

    # 相关性方法拟合
    while (len(all_points2) > inpoints_num):
        rmIndexArr = Utils.Corr3_delete(all_points2[:, 0], all_points2[:, 1], all_points2[:, 2], int(np.ceil(outpoints_num/10)))
        del_points = all_points2[rmIndexArr]
        all_points2 = np.delete(all_points2, rmIndexArr, axis=0)

    w2 = corrFitMethod.Fit(all_points2)
    w2 = Utils.normc(w2)

    # ransac
    w4 = ransac.ransac(all_points3, distThd=thd_dist, iterNum=500)
    w4 = Utils.normc(w4)

    print('lsm result：a=%.5f b=%.5f c=%.5f d=%.5f' % (w1[0], w1[1], w1[2], w1[3]))
    print('corr result：a=%.5f b=%.5f c=%.5f d=%.5f' % (w2[0], w2[1], w2[2], w2[3]))
    print('s2r2 result：a=%.5f b=%.5f c=%.5f d=%.5f' % (w3[0], w3[1], w3[2], w3[3]))
    print('ransac result：a=%.5f b=%.5f c=%.5f d=%.5f' % (w4[0], w4[1], w4[2], w4[3]))
    print('rpca result：a=%.5f b=%.5f c=%.5f d=%.5f' % (w5[0], w5[1], w5[2], w5[3]))
    print('m-estimator result：a=%.5f b=%.5f c=%.5f d=%.5f' % (w6[0], w6[1], w6[2], w6[3]))
    print('dpsp_psgm result：a=%.5f b=%.5f c=%.5f d=%.5f' % (w7[0], w7[1], w7[2], w7[3]))

    # rmse
    gt_w = Utils.normc([gt_a, gt_b, gt_c, gt_d])
    rmse = np.zeros(7)
    rmse[0] = np.sqrt((w1[0]-gt_w[0])**2+(w1[1]-gt_w[1])**2+(w1[2]-gt_w[2])**2+(w1[3]-gt_w[3])**2)
    rmse[1] = np.sqrt((w2[0]-gt_w[0])**2+(w2[1]-gt_w[1])**2+(w2[2]-gt_w[2])**2+(w2[3]-gt_w[3])**2)
    rmse[2] = np.sqrt((w3[0]-gt_w[0])**2+(w3[1]-gt_w[1])**2+(w3[2]-gt_w[2])**2+(w3[3]-gt_w[3])**2)
    rmse[3] = np.sqrt((w4[0]-gt_w[0])**2+(w4[1]-gt_w[1])**2+(w4[2]-gt_w[2])**2+(w4[3]-gt_w[3])**2)
    rmse[4] = np.sqrt((w5[0]-gt_w[0])**2+(w5[1]-gt_w[1])**2+(w5[2]-gt_w[2])**2+(w5[3]-gt_w[3])**2)
    rmse[5] = np.sqrt((w6[0]-gt_w[0])**2+(w6[1]-gt_w[1])**2+(w6[2]-gt_w[2])**2+(w6[3]-gt_w[3])**2)
    rmse[6] = np.sqrt((w7[0]-gt_w[0])**2+(w7[1]-gt_w[1])**2+(w7[2]-gt_w[2])**2+(w7[3]-gt_w[3])**2)
    mean_rmse += rmse

    # angle deviation
    n1 = np.array([w1[0], w1[1], w1[2]])
    n2 = np.array([w2[0], w2[1], w2[2]])
    n3 = np.array([w3[0], w3[1], w3[2]])
    n4 = np.array([w4[0], w4[1], w4[2]])
    n5 = np.array([w5[0], w5[1], w5[2]])
    n6 = np.array([w6[0], w6[1], w6[2]])
    n7 = np.array([w7[0], w7[1], w7[2]])

    w_t = np.array([gt_w[0], gt_w[1], gt_w[2]])
    angle = np.zeros(7)
    angle[0] = np.arccos(np.matmul(n1, w_t)/ np.sqrt(np.sum(n1 ** 2) * np.sum(w_t ** 2))) * 180 / np.pi
    angle[1] = np.arccos(np.matmul(n2, w_t) / np.sqrt(np.sum(n2 ** 2) * np.sum(w_t ** 2))) * 180 / np.pi
    angle[2] = np.arccos(np.matmul(n3, w_t) / np.sqrt(np.sum(n3 ** 2) * np.sum(w_t ** 2))) * 180 / np.pi
    angle[3] = np.arccos(np.matmul(n4, w_t) / np.sqrt(np.sum(n4 ** 2) * np.sum(w_t ** 2))) * 180 / np.pi
    angle[4] = np.arccos(np.matmul(n5, w_t) / np.sqrt(np.sum(n5 ** 2) * np.sum(w_t ** 2))) * 180 / np.pi
    angle[5] = np.arccos(np.matmul(n6, w_t) / np.sqrt(np.sum(n6 ** 2) * np.sum(w_t ** 2))) * 180 / np.pi
    angle[6] = np.arccos(np.matmul(n7, w_t) / np.sqrt(np.sum(n7 ** 2) * np.sum(w_t ** 2))) * 180 / np.pi
    angle = np.where(angle>90, 180-angle, angle)
    mean_angle += angle

    #
    dist_g = (np.matmul(w_t, raw_points.T) - gt_w[3]) / np.sqrt(np.sum(w_t ** 2))
    dist1 = (np.matmul(n1, raw_points.T)-w1[3])/np.sqrt(np.sum(n1**2))
    dist2 = (np.matmul(n2, raw_points.T)-w2[3])/np.sqrt(np.sum(n2**2))
    dist3 = (np.matmul(n3, raw_points.T)-w3[3])/np.sqrt(np.sum(n3**2))
    dist4 = (np.matmul(n4, raw_points.T)-w4[3])/np.sqrt(np.sum(n4**2))
    dist5 = (np.matmul(n5, raw_points.T)-w5[3])/np.sqrt(np.sum(n5**2))
    dist6 = (np.matmul(n6, raw_points.T)-w6[3])/np.sqrt(np.sum(n6**2))
    dist7 = (np.matmul(n7, raw_points.T)-w7[3])/np.sqrt(np.sum(n7**2))
    label_gt = np.where(dist_g < thd_dist, 1, 0)
    label1 = np.where(dist1<thd_dist, 1, 0)
    label2 = np.where(dist2<thd_dist, 1, 0)
    label3 = np.where(dist3<thd_dist, 1, 0)
    label4 = np.where(dist4<thd_dist, 1, 0)
    label5 = np.where(dist5<thd_dist, 1, 0)
    label6 = np.where(dist6<thd_dist, 1, 0)
    label7 = np.where(dist7<thd_dist, 1, 0)

    acc = np.zeros(7)
    acc[0] = metrics.accuracy_score(label_gt, label1)
    acc[1] = metrics.accuracy_score(label_gt, label2)
    acc[2] = metrics.accuracy_score(label_gt, label3)
    acc[3] = metrics.accuracy_score(label_gt, label4)
    acc[4] = metrics.accuracy_score(label_gt, label5)
    acc[5] = metrics.accuracy_score(label_gt, label6)
    acc[6] = metrics.accuracy_score(label_gt, label7)
    mean_acc += acc

    f1_arr = np.zeros(7)
    f1_arr[0] = metrics.f1_score(label_gt, label1)
    f1_arr[1] = metrics.f1_score(label_gt, label2)
    f1_arr[2] = metrics.f1_score(label_gt, label3)
    f1_arr[3] = metrics.f1_score(label_gt, label4)
    f1_arr[4] = metrics.f1_score(label_gt, label5)
    f1_arr[5] = metrics.f1_score(label_gt, label6)
    f1_arr[6] = metrics.f1_score(label_gt, label7)
    mean_f1 += f1_arr


mean_rmse = mean_rmse/100
mean_angle = mean_angle/100
mean_acc = mean_acc/100
mean_f1 = mean_f1/100
print(mean_rmse)
print(mean_angle)
print(mean_acc)
print(mean_f1)