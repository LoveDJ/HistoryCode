import numpy as np

def getPatchArr(path):
    patch_arr = []
    with open(path) as file_object:
        for line in file_object:
            arr = line.strip().split(',')
            arr[0:6] = list(map(float, arr[0:6]))
            arr[6:-1] = list(map(int, arr[6:-1]))
            patch_arr.append(arr)
    return patch_arr

def getPointArr(path):
    point_arr = []
    with open(path) as file_object:
        for line in file_object:
            arr = line.strip().split(',')
            try:
                point_arr.append(list(map(int, arr)))
            except Exception:
                pass
    return point_arr

def compareWithGt(gt_patch_arr, gt_point_arr, patch_arr, point_arr):
    error_arr = []
    for i in range(len(gt_point_arr)):
        patch_id = point_arr[i][1]
        gt_patch_id = gt_point_arr[i][1]
        normal = []
        gt_normal = []
        for j in range(len(patch_arr)):
            if patch_id == patch_arr[j][6]:
                normal = patch_arr[j][3:6]
                break
        for j in range(len(gt_patch_arr)):
            if gt_patch_id == gt_patch_arr[j][6]:
                gt_normal = gt_patch_arr[j][3:6]
                break
        if len(normal) == 0 or len(gt_normal) == 0:  # only consider points in the plane
            continue
        normal = np.array(normal)
        gt_normal = np.array(gt_normal)
        angle = np.arccos(np.sum(np.dot(normal, gt_normal)) / np.sqrt(
            np.sum(normal ** 2) * np.sum(gt_normal ** 2))) * 180 / np.pi
        if angle > 90:
            angle = 180 - angle
        error_arr.append(angle)

    error_arr = np.array(error_arr)
    mean_error = np.mean(error_arr)
    std_error = np.std(error_arr)
    return mean_error, std_error

gt_patch_path = '/home/dingjian/data/rapterData/lHouse/patches.csv'
gt_point_pri_path = '/home/dingjian/data/rapterData/lHouse/points_primitives.csv'
rap_patch_path = '/home/dingjian/data/rapterData/lHouse/primitives_it20.bonmin.csv'
rap_point_pri_path = '/home/dingjian/data/rapterData/lHouse/points_primitives_it19.csv'
globfit_patch_path = '/home/dingjian/data/rapterData/lHouse/primitives.globfit.csv'
globfit_point_path = '/home/dingjian/data/rapterData/lHouse/points_primitives.globfit.csv'

gt_patch_arr = getPatchArr(gt_patch_path)
gt_point_arr = getPointArr(gt_point_pri_path)
rap_patch_arr = getPatchArr(rap_patch_path)
rap_point_arr = getPointArr(rap_point_pri_path)
mean_error, std_error = compareWithGt(gt_patch_arr, gt_point_arr, rap_patch_arr, rap_point_arr)
print('mean_error = %.5f'%(mean_error))
print('std_error = %.5f'%(std_error))

globfit_patch_arr = getPatchArr(globfit_patch_path)
globfit_point_arr = getPointArr(globfit_point_path)
mean_globfit, std_globfit = compareWithGt(gt_patch_arr, gt_point_arr, globfit_patch_arr, globfit_point_arr)
print('mean_error = %.5f'%(mean_globfit))
print('std_error = %.5f'%(std_globfit))
