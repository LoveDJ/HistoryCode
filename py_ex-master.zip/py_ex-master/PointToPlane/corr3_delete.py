'''

delete low corr point by vector method

'''
import numpy as np
from PointToPlane import Utils

points = Utils.readMesh('../data/indoor.ply', step=1)
pointX = points[:, 0]
pointY = points[:, 1]
pointZ = points[:, 2]


# mean = 0
Xmean = np.mean(pointX)
Ymean = np.mean(pointY)
Zmean = np.mean(pointZ)

pointX = pointX - Xmean
pointY = pointY - Ymean
pointZ = pointZ - Zmean

# length = 1
pointX = pointX / np.sqrt(np.sum(np.power(pointX, 2)))
pointY = pointY / np.sqrt(np.sum(np.power(pointY, 2)))
pointZ = pointZ / np.sqrt(np.sum(np.power(pointZ, 2)))

while True:
    r1 = Utils.Corr3_vector(pointX, pointY, pointZ)

    delIndex = Utils.Corr3_sub(pointX, pointY, pointZ)
    delPointX = pointX[delIndex]
    delPointY = pointY[delIndex]
    delPointZ = pointZ[delIndex]

    pointX = np.delete(pointX, delIndex)
    pointY = np.delete(pointY, delIndex)
    pointZ = np.delete(pointZ, delIndex)

    r2 = Utils.Corr3_vector(pointX, pointY, pointZ)

    print('corr before delete = %.5f'%(r1))
    print('corr after delete = %.5f' % (r2))

    Xmean = -delPointX / len(pointX)
    Ymean = -delPointY / len(pointY)
    Zmean = -delPointZ / len(pointZ)

    Xm = np.sqrt((1 - delPointX ** 2))
    Ym = np.sqrt((1 - delPointY ** 2))
    Zm = np.sqrt((1 - delPointZ ** 2))

    pointX = (pointX + Xmean) / Xm
    pointY = (pointY + Ymean) / Ym
    pointZ = (pointZ + Zmean) / Zm

    r3 = Utils.Corr3_vector(pointX, pointY, pointZ)
    print('nomalize the vector corr3 = %.5f'%(r3))

    if r3 > 0.99:
        break

'''
while True:
    maxRxyz = Utils.Corr3_vector(pointX, pointY, pointZ)
    maxIndex = -1
    i = 0
    while i < len(pointX):
        newPointX = np.delete(pointX, i)
        newPointY = np.delete(pointY, i)
        newPointZ = np.delete(pointZ, i)
        newRxyz = Utils.Corr3_vector(newPointX, newPointY, newPointZ)
        if newRxyz > maxRxyz:

            maxRxyz = newRxyz
            maxIndex = i

        i = i+1
    maxIndexArr.append(maxIndex)
    print('maxIndex = %d'%(maxIndex))
    # calculate the distance between delpoints and the plane
    delPointX = pointX[maxIndex]
    delPointY = pointY[maxIndex]
    delPointZ = pointZ[maxIndex]

    first = np.array([delPointX, delPointY, delPointZ])
    second = np.array([a, b, c])

    distance = np.abs(np.dot(first, second)-d)
    print('the distance between delpoints and the plane is %.5f'%(distance))

    pointX = np.delete(pointX, maxIndex)
    pointY = np.delete(pointY, maxIndex)
    pointZ = np.delete(pointZ, maxIndex)


    print('maxRxyz = %f\n'%(maxRxyz))

    if maxRxyz>0.9999:
        break

'''