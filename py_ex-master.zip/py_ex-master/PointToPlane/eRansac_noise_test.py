import os
import numpy as np
import re

max_plane_num = 10

dir_path = r'E:\data\scanNet_effi_noise_results_bak'
files = os.listdir(dir_path)
files = sorted(files)

rate = np.array([])
rate_noise = np.array([])
plane_mse_arr = np.array([])
all_paras = np.empty(shape=[0, 4], dtype=float)
all_paras_noise = np.empty(shape=[0, 4], dtype=float)
all_pointslen = 0
for i, file_name in enumerate(files):
    # if file_name.endswith('noise.txt'):
    if len(file_name)<6:
        print(file_name)
        file_path = os.path.join(dir_path, file_name)
        file = open(file_path)
        all_txt = file.readlines()
        number_arr = all_txt[1::2]
        para_arr = all_txt[2::2]
        for para_str in para_arr:
            one_paras = re.findall(r"\d+\.?\d*", para_str)
            one_paras = [float(one_para) for one_para in one_paras]
            one_paras = np.expand_dims(one_paras, axis=0)
            all_paras = np.append(all_paras, one_paras, axis=0)
        number_arr = [int(number) for number in number_arr]
        index_arr = np.argsort(np.array(number_arr))
        index_arr = index_arr[::-1]
        all_paras = all_paras[index_arr[0:max_plane_num]]
        numberArr = sorted(number_arr, reverse=True)
        allPointsLen = int(all_txt[0])
        all_pointslen += allPointsLen
        inPointsLen = sum(numberArr[0:max_plane_num])

        rate = np.append(rate, inPointsLen/allPointsLen)
    if file_name.endswith('uniform_noise.txt'):
        print(file_name)
        file_path = os.path.join(dir_path, file_name)
        file = open(file_path)

        all_txt = file.readlines()
        number_arr = all_txt[1::2]
        para_arr = all_txt[2::2]
        for para_str in para_arr:
            one_paras = re.findall(r"\d+\.?\d*", para_str)
            one_paras = [float(one_para) for one_para in one_paras]
            one_paras = np.expand_dims(one_paras, axis=0)
            all_paras_noise = np.append(all_paras_noise, one_paras, axis=0)
        number_arr = [int(number) for number in number_arr]
        index_arr = np.argsort(np.array(number_arr))
        index_arr = index_arr[::-1]
        all_paras_noise = all_paras_noise[index_arr[0:max_plane_num]]
        numberArr = sorted(number_arr, reverse=True)
        allPointsLen = int(all_txt[0])
        inPointsLen = sum(numberArr[0:max_plane_num])
        
        rate_noise = np.append(rate_noise, inPointsLen/allPointsLen)

        plane_mse = np.sum(np.power(all_paras_noise-all_paras, 2))/max_plane_num
        plane_mse_arr = np.append(plane_mse_arr, plane_mse)
        all_paras = np.empty(shape=[0, 4], dtype=float)
        all_paras_noise = np.empty(shape=[0, 4], dtype=float)
mean_rate = np.mean(rate)
mean_rate_noise = np.mean(rate_noise)
mean_plane_mse = np.mean(plane_mse_arr)
print('mean_rate = %.5f'%(mean_rate))
print('mean_rate_noise = %.5f'%(mean_rate_noise))
print('plane_mse = %.5f'%(mean_plane_mse))

