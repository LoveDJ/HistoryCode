import h5py
import numpy as np
from PointToPlane import Utils
import argparse

def pase_args():
    parser = argparse.ArgumentParser(description='PointToPlane')
    parser.add_argument('--distThd', dest='distThd',
                            help='default distance to judge whether a point is on plane',
                            default=0.05, type=float)
    parser.add_argument('--step', dest='step',
                            help='step of sparsing points',
                            default=1, type=int)
    parser.add_argument('--pNum', dest='pNum',
                            help='the number of planes to extract',
                            default=10, type=int)
    parser.add_argument('--pointsPath', dest='pointsPath',
                            help='the number of planes to extract',
                            default='../data/outdoor.ply', type=str)
    parser.add_argument('--add_noise', dest='add_noise',
                                help='signal noise ratio',
                            default=False, type=bool)
    parser.add_argument('--noise_type', dest='noise_type',
                                help='gaussian poisson uniform rayleigh',
                            default='rayleigh', type=str)
    parser.add_argument('--snr', dest='snr',
                                help='signal noise ratio',
                            default=20, type=int)

    args = parser.parse_args()
    return args

def get_paras_and_rate(all_plane_paras, all_points, args):

    # evaluate plane
    allPointsCopy = all_points.copy()
    plane_paras_results = np.empty(shape=[0, 4], dtype=float)
    allDist = 0
    allNum = 0

    for k in range(args.pNum):
        if len(all_plane_paras) == 0:
            break
        normals = all_plane_paras[:, 0:3]
        normals = np.transpose(normals)
        ds = all_plane_paras[:, 3]
        ds = np.transpose(ds)

        dists = np.abs(np.matmul(allPointsCopy, normals) - ds)

        inDistNum = np.sum(np.where(dists < args.distThd, 1, 0), axis=0)

        maxPlaneInd = np.argmax(inDistNum)
        maxDists = dists[:, maxPlaneInd]
        maxInpointsInd = np.where(maxDists < args.distThd)[0]

        allDist += np.sum(maxDists[maxInpointsInd])
        allNum += np.max(inDistNum)
        # print('inDistNum = %d'%(np.max(inDistNum)))
        one_para = np.expand_dims(all_plane_paras[maxPlaneInd], axis=0)
        plane_paras_results = np.append(plane_paras_results, one_para, axis=0)
        all_plane_paras = np.delete(all_plane_paras, maxPlaneInd, axis=0)
        allPointsCopy = np.delete(allPointsCopy, maxInpointsInd, axis=0)

    inner_rate = (len(all_points) - len(allPointsCopy)) / len(all_points)
    mean_distance = allDist / allNum

    return plane_paras_results, inner_rate

def get_h5_paras(h5path):
    with h5py.File(h5path, 'r') as f:
        instance_per_point = f['instance_per_point'][:]
        type_per_point = f['type_per_point'][:]
        index = np.argwhere(type_per_point == 2)
        type2_point = instance_per_point[index]
        type2_point = np.squeeze(type2_point)
        index = np.argmax(type2_point, axis=1)
        instance = np.argsort(-np.bincount(index))
        a = f['parameters']
        plane_para = a['plane_n'][:]
        plane_dist = a['plane_c'][:]
        plane_dist = np.expand_dims(plane_dist, axis=1)
        planeParas = np.concatenate((plane_para, plane_dist), axis=1)
    return planeParas

def evaluate():
    args = pase_args()
    h5_dir = r'E:/data/spfn_results/'
    TEST_NUMBER = 10
    rate_arr = np.array([])
    plane_mse_arr = np.array([])
    for i in range(TEST_NUMBER):
        all_plane_paras = get_h5_paras(h5_dir+str(i)+'.h5')
        all_plane_paras_gauss_noise = get_h5_paras(h5_dir + str(i) + '_noise.h5')

        points_path = 'E:/data/scanNet_no_noise/'+str(i)+'.ply'
        gau_noise_points_path = 'E:/data/scanNet_gaussian_noise/'+str(i)+'_noise.ply'
        all_points = Utils.readxyz(points_path)
        all_noise_points = Utils.readxyz(gau_noise_points_path)
        plane_paras, inner_rate = get_paras_and_rate(all_plane_paras, all_points, args)
        plane_paras_noise, inner_rate_noise = get_paras_and_rate(all_plane_paras_gauss_noise, all_noise_points, args)

        rate_arr = np.append(rate_arr, inner_rate)

        plane_mse = np.sum(np.power((plane_paras - plane_paras_noise), 2)) / len(plane_paras)
        plane_mse_arr = np.append(plane_mse_arr, plane_mse)


    rate_mean = np.mean(rate_arr)
    mse_mean = np.mean(plane_mse_arr)
    print('rate_mean = %.5f'%(rate_mean))
    print('mse_mean = %.5f'%(mse_mean))
evaluate()