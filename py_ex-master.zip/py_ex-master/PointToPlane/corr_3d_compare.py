import numpy as np
from PointToPlane import Utils
import matplotlib.pyplot as plt
from PointToPlane import ransac_v2 as ransac
from PointToPlane import corrFitMethod
from PointToPlane import rpca as rpca
from PointToPlane import leastSquareMethod as lsm
import matlab.engine
import warnings
warnings.filterwarnings("ignore")

distThd = 0.035
points = Utils.readxyz('../data/fitting/plane1.txt')
pointsNum = len(points)

outRateArr1 = []
outRateArr2 = []
outRateArr3 = []
outRateArr4 = []
outRateArr5 = []

for i in range(100):

    print('第%d次试验...'%i)

    # 相关性方法
    delNum = 10
    delCount = 80
    points1 = points.copy()
    for i in range(delCount):
        delIndexArr = Utils.Corr3_delete(points1[:, 0], points1[:, 1], points1[:, 2], delNum)
        np.savetxt('truth.txt',delIndexArr)
        points1 = np.delete(points1, delIndexArr, axis=0)

    w1 = corrFitMethod.Fit(points1)
    w1 = Utils.normc(w1)
    d1 = np.abs(np.matmul(points, w1[0:3]) - w1[3])
    inpoints = d1[d1<distThd]
    outlierRate1 = len(inpoints)/pointsNum
    outRateArr1.append(outlierRate1)

    # RANSAC方法
    points2 = points.copy()
    w2 = ransac.ransac(points2, distThd=distThd, iterNum=500)
    w2 = Utils.normc(w2)
    d2 = np.abs(np.matmul(points, w2[0:3]) - w2[3])
    inpoints = d2[d2<distThd]
    outlierRate2 = len(inpoints)/pointsNum
    outRateArr2.append(outlierRate2)

    # m-estimators
    eng = matlab.engine.start_matlab()
    points3 = points.copy()
    lista = points3[:,0:2].tolist()
    lista = matlab.double(lista)
    listb = points3[:,2].tolist()
    listb = matlab.double(listb)
    w3 = eng.robustfit(lista, listb, 'huber')
    w3 = Utils.normc([-w3[1][0], -w3[2][0], 1, w3[0][0]])
    if w3[0] < 0:
        w3 = -w3
    d3 = np.abs(np.matmul(points, w3[0:3]) - w3[3])
    inpoints = d3[d3<distThd]
    outlierRate3 = len(inpoints)/pointsNum
    outRateArr3.append(outlierRate3)

    # rpca
    points4 = points.copy()
    A = rpca.alternating_direction_method_of_multipliers(points4, lmbda=1)
    w4 = lsm.leastSquare(A[0])
    w4 = Utils.normc(w4)
    d4 = np.abs(np.matmul(points, w4[0:3]) - w4[3])
    inpoints = d4[d4<distThd]
    outlierRate4 = len(inpoints)/pointsNum
    outRateArr4.append(outlierRate4)

    #dpcp_psgm
    points5 = points.copy()
    inliers = np.vstack((points5[:,0], points5[:,1], points5[:,2], np.ones(len(points5)))) # 4*100
    inliers = Utils.normc(inliers) # 4*100
    X_tilde = inliers

    X_tilde = matlab.double(X_tilde.tolist())
    beta = 1 / 2
    w5 = eng.DPCP_PSGM_optim_J(X_tilde, 1, 1e-9, beta, 500, 1e-6)
    w5 = np.array([w5[0][0], w5[1][0], w5[2][0], -w5[3][0]])
    if w5[0] < 0:
        w5 = -w5
    d5 = np.abs(np.matmul(points, w5[0:3]) - w5[3])
    inpoints = d5[d5<distThd]
    outlierRate5 = len(inpoints)/pointsNum
    outRateArr5.append(outlierRate5)

outRateMean1 = np.mean(outRateArr1)
outRateMean2 = np.mean(outRateArr2)
outRateMean3 = np.mean(outRateArr3)
outRateMean4 = np.mean(outRateArr4)
outRateMean5 = np.mean(outRateArr5)

print('相关性方法的内点率为%.5f'%(outRateMean1))
print('RANSAC方法的内点率为%.5f'%(outRateMean2))
print('m-estimator方法的内点率为%.5f'%(outRateMean3))
print('rpca方法的内点率为%.5f'%(outRateMean4))
print('dpcp_psgm方法的内点率为%.5f'%(outRateMean5))