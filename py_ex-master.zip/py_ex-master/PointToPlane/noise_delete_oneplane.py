'''

describe: generate one plane with gaussian noise

'''

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
from PointToPlane import Utils
from PointToPlane import leastSquareMethod as lsm


def reverseIndex(indexArr):

    n = -2
    while n > -len(indexArr)-1:
        newIndexArr = indexArr[n:]
        flag = newIndexArr[0]
        i = 1
        while i < len(newIndexArr):
            if newIndexArr[i] >= flag:
                newIndexArr[i] += 1
            i += 1
        indexArr[n:] = newIndexArr
        n -= 1
    return indexArr

# define a plane n=(3, 4, 5) d = 0.6
n = np.sqrt(3**2 + 4**2 + 5**2)
a = 3/n
b = 4/n
c = 5/n
d = 0.6
print('plane parameter a = %.5f, b = %.5f, c = %.5f, d = %.5f'%(a, b, c, d))
# config figure
fig = plt.figure()
ax = fig.gca(projection='3d')

# create plane points
x = np.linspace(-100, 100, 100)
y = np.linspace(-100, 100, 100)
x, y = np.meshgrid(x, y)
z = (d - a*x - b*y)/c

x = x.reshape((10000, 1))
y = y.reshape((10000, 1))
z = z.reshape((10000, 1))


# create gaussian noise
np.random.seed(0)
xNoise = np.random.randint(-100, 100, size=100)
xNoise = xNoise.reshape((100,1))
np.random.seed(1)
yNoise = np.random.randint(-100, 100, size=100)
yNoise = yNoise.reshape((100,1))
mu = 0
sigma = 30
D = np.random.normal(mu, sigma, 100)
D = D.reshape((100, 1))
zNoise = (D - a*xNoise - b*yNoise + d)/c

# add gaussian noise
x = np.concatenate((x, xNoise), axis=0)
y = np.concatenate((y, yNoise), axis=0)
z = np.concatenate((z, zNoise), axis=0)


points = np.concatenate((x, y, z), axis = 1)
# build three vectors to calculate correlation
pointX = points[:,0]
pointY = points[:,1]
pointZ = points[:,2]


# mean = 0
Xmean = np.mean(pointX)
Ymean = np.mean(pointY)
Zmean = np.mean(pointZ)

pointX = pointX - Xmean
pointY = pointY - Ymean
pointZ = pointZ - Zmean

# length = 1
pointX = pointX / np.sqrt(np.sum(np.power(pointX, 2)))
pointY = pointY / np.sqrt(np.sum(np.power(pointY, 2)))
pointZ = pointZ / np.sqrt(np.sum(np.power(pointZ, 2)))

# show plane before points being deleted
'''
ax.scatter(pointX, pointY, pointZ, c='r', marker='o')
ax.legend()

plt.show()
'''
maxIndexArr = []

# use slow deleting method

while True:
    r1 = Utils.Corr3_vector(pointX, pointY, pointZ)

    delIndex = Utils.Corr3_sub(pointX, pointY, pointZ)
    maxIndexArr.append(delIndex)

    delPointX = pointX[delIndex]
    delPointY = pointY[delIndex]
    delPointZ = pointZ[delIndex]

    pointX = np.delete(pointX, delIndex)
    pointY = np.delete(pointY, delIndex)
    pointZ = np.delete(pointZ, delIndex)

    r2 = Utils.Corr3_vector(pointX, pointY, pointZ)

    print('corr before delete = %.5f'%(r1))
    print('corr after delete = %.5f' % (r2))

    Xmean = -delPointX / len(pointX)
    Ymean = -delPointY / len(pointY)
    Zmean = -delPointZ / len(pointZ)

    Xm = np.sqrt((1 - delPointX ** 2))
    Ym = np.sqrt((1 - delPointY ** 2))
    Zm = np.sqrt((1 - delPointZ ** 2))

    pointX = (pointX + Xmean) / Xm
    pointY = (pointY + Ymean) / Ym
    pointZ = (pointZ + Zmean) / Zm

    r3 = Utils.Corr3_vector(pointX, pointY, pointZ)
    print('corr after delete = %.5f'%(r3))

    if r3 > 0.999999999999999:
        break

pointX = np.expand_dims(pointX, axis=1)
pointY = np.expand_dims(pointY, axis=1)
pointZ = np.expand_dims(pointZ, axis=1)
resultPoints = np.concatenate((pointX, pointY, pointZ), axis=1)

at, bt, ct = lsm.leastSquare(resultPoints)
print('plane parameter a = %.5f, b = %.5f, c = %.5f'%(at, bt, ct))

print(len(maxIndexArr))
print(maxIndexArr)
maxIndexArr = reverseIndex(maxIndexArr)
print(np.sort(maxIndexArr))
points = np.delete(points, maxIndexArr, axis=0)
ar, br, cr = lsm.leastSquare(points)
print('plane parameter a = %.5f, b = %.5f, c = %.5f'%(ar*0.6, br*0.6, cr*0.6))


ax.scatter(points[:,0], points[:,1], points[:,2], c='r', marker='o')
ax.legend()

plt.show()


