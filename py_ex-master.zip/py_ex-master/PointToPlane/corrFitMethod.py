'''
describe: least square method to fit plane
date: 2019-10-10
author: dingjian
lsm reference blog: https://blog.csdn.net/konglingshneg/article/details/82585868
'''
import matplotlib as mpl
from matplotlib import cm
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import random
from PointToPlane import Utils
from PointToPlane import ransac_v2 as ransac

# ax+by+cz=d
def Fit(points):
    # read points mesh or use util.readMesh()

    x_vector = points[:, 0]
    y_vector = points[:, 1]
    z_vector = points[:, 2]


    Xmean = np.mean(x_vector)
    x_vector = x_vector - Xmean
    Xlen = np.sqrt(np.sum(np.power(x_vector, 2)))

    Ymean = np.mean(y_vector)
    y_vector = y_vector - Ymean
    Ylen = np.sqrt(np.sum(np.power(y_vector, 2)))

    Zmean = np.mean(z_vector)
    z_vector = z_vector - Zmean
    Zlen = np.sqrt(np.sum(np.power(z_vector, 2)))

    # # 如果平面垂直于坐标轴
    if Xlen < 1e-5 or Ylen < 1e-5 or Zlen < 1e-5:
        point_1 = points[0]
        plane_normal = np.array([0, 0, 0])
        for i in range(len(x_vector)):
            rs = random.sample(range(0, len(x_vector)), 3)
            point_1 = points[rs[0]]
            point_2 = points[rs[1]]
            point_3 = points[rs[2]]

            plane_normal = np.cross((point_2 - point_1), (point_3 - point_1))
            if np.sum(plane_normal) != 0:
                break
        plane_normal = plane_normal / np.sqrt(np.sum(plane_normal ** 2))
        d = np.dot(point_1, plane_normal)
        a = plane_normal[0]
        b = plane_normal[1]
        c = plane_normal[2]
        if a <0:
            a = -a
            b = -b
            c = -c
            d = -d
        return a, b, c, d

    x_vector = x_vector / Xlen
    y_vector = y_vector / Ylen
    z_vector = z_vector / Zlen

    R12 = np.corrcoef(x_vector, y_vector)
    R13 = np.corrcoef(x_vector, z_vector)
    R23 = np.corrcoef(y_vector, z_vector)

    R12 = R12[0][1]
    R13 = R13[0][1]
    R23 = R23[0][1]


    a_2 = Ylen * Zlen*(R12*R23-R13)
    b_2 = Xlen*Zlen*(R12*R13-R23)
    c_2 = Xlen*Ylen*(1-R12**2)
    d_2 = a_2 * Xmean + b_2*Ymean + c_2*Zmean

    m = np.sqrt(a_2 ** 2 + b_2 ** 2 + c_2 ** 2)
    at_2 = a_2 / m
    bt_2 = b_2 / m
    ct_2 = c_2 / m
    dt_2 = d_2 / m
    if at_2 <0:
        at_2 = -at_2
        bt_2 = -bt_2
        ct_2 = -ct_2
        dt_2 = -dt_2
    return at_2, bt_2, ct_2, dt_2

'''
#points = np.array([[0,0,1],[0,1,-2],[1, 0, -1],[1,1,-4], [0,0,0.5]])
points = np.array([[1,-1,1],[2,-1,0],[3, 3, -5]])

a,b,c,d = Fit(points)
normal = np.array([a, b,c])
print(a,b,c,d)
dist = np.sum(np.matmul(points,normal)-d)


# show planes fitted by points
fig = plt.figure()
ax = fig.gca(projection='3d')
ax.scatter(points[:, 0], points[:, 1], points[:, 2], c='r', marker='.', linewidths=5)
X = np.arange(-1, 2, 0.25)
Y = np.arange(-1, 2, 0.25)
X, Y = np.meshgrid(X, Y)
Z = -(a / c) * X - (b / c) * Y + d / c

ax.legend()
plt.show()

# show planes fitted by points
fig = plt.figure()
ax = fig.gca(projection='3d')
ax.scatter(points[:, 0], points[:, 1], points[:, 2], c='r', marker='.', linewidths=5)
X = np.arange(-1, 2, 0.25)
Y = np.arange(-1, 2, 0.25)
X, Y = np.meshgrid(X, Y)
Z = -(a / c) * X - (b / c) * Y + d / c

surf = ax.plot_surface(X, Y, Z, cmap=cm.Blues, linewidth=0, antialiased=False)
ax.legend()
plt.show()



'''
# points = Utils.readxyz('../data/fitting/plane3.txt')
# a,b,c,d = Fit(points)
# normal = np.array([a, b,c])
# dist1 = np.sum(np.abs(np.matmul(points,normal)-d))
#
#
# points = Utils.readxyz('../data/fitting/plane4.txt')
# a,b,c,d = ransac.ransac(points)
# normal = np.array([a, b,c])
# dist2 = np.sum(np.abs(np.matmul(points,normal)-d))
# print('123')
