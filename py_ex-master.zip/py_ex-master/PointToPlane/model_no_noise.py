'''

describe: generate one house model without noise

'''

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
from PointToPlane import Utils
from PointToPlane import leastSquareMethod as lsm

# config figure
fig = plt.figure()
ax = fig.gca(projection='3d')

# define a plane n=(0, 4, 5) d = 1
a1 = 0
b1 = 0
c1 = 1
d1 = 1
print('plane parameter a = %.5f, b = %.5f, c = %.5f, d = %.5f'%(a1, b1, c1, d1))

unit = 50
sub_unit = unit//2
# create plane points
x = np.linspace(-100, 100, unit)
y = np.linspace(-100, 100, unit)
z = np.linspace(-100, 100, unit)
x_init, y_init = np.meshgrid(x, y)

x0 = x_init.reshape((unit**2, 1))
y0 = y_init.reshape((unit**2, 1))

x1 = x0
y1 = y0
z1 = np.ones((unit**2, 1))*(-100)

x2 = x0
y2 = np.ones((unit**2, 1))*(-100)
z2 = y0

x3 = x0
y3 = np.ones((unit**2, 1))*(100)
z3 = y0

x4 = np.ones((unit**2, 1))*(-100)
y4 = x0
z4 = y0

x5 = np.ones((unit**2, 1))*(100)
y5 = x0
z5 = y0

x = np.linspace(0, 100, sub_unit)
y = np.linspace(-100, 0, sub_unit)
z = np.linspace(-100, 100, sub_unit)

x_init, z_init = np.meshgrid(x, z)
x_init = x_init.reshape((sub_unit**2, 1))
z_init = z_init.reshape((sub_unit**2, 1))
x6 = x_init
y6 = np.zeros((sub_unit**2, 1))
z6 = z_init


y_init, z_init = np.meshgrid(y, z)
y_init = y_init.reshape((sub_unit**2, 1))
z_init = z_init.reshape((sub_unit**2, 1))
x7 = np.zeros((sub_unit**2, 1))
y7 = y_init
z7 = z_init

x_all = np.concatenate((x1, x2, x3, x4, x5, x6, x7), axis=0)
y_all = np.concatenate((y1, y2, y3, y4, y5, y6, y7), axis=0)
z_all = np.concatenate((z1, z2, z3, z4, z5, z6, z7), axis=0)


# show plane before points being deleted
'''
ax.scatter(x_all, y_all, z_all, c='r', marker='.', linewidths=0.5)
ax.legend()

plt.show()
'''
maxIndexArr = []

# use slow deleting method

while True:
    r1 = Utils.Corr3_vector(pointX, pointY, pointZ)

    delIndex = Utils.Corr3_sub(pointX, pointY, pointZ)
    maxIndexArr.append(delIndex)

    delPointX = pointX[delIndex]
    delPointY = pointY[delIndex]
    delPointZ = pointZ[delIndex]

    pointX = np.delete(pointX, delIndex)
    pointY = np.delete(pointY, delIndex)
    pointZ = np.delete(pointZ, delIndex)

    r2 = Utils.Corr3_vector(pointX, pointY, pointZ)

    print('corr before delete = %.5f'%(r1))
    print('corr after delete = %.5f' % (r2))

    Xmean = -delPointX / len(pointX)
    Ymean = -delPointY / len(pointY)
    Zmean = -delPointZ / len(pointZ)

    Xm = np.sqrt((1 - delPointX ** 2))
    Ym = np.sqrt((1 - delPointY ** 2))
    Zm = np.sqrt((1 - delPointZ ** 2))

    pointX = (pointX + Xmean) / Xm
    pointY = (pointY + Ymean) / Ym
    pointZ = (pointZ + Zmean) / Zm

    r3 = Utils.Corr3_vector(pointX, pointY, pointZ)
    print('corr after delete = %.5f'%(r3))

    if r3 > 0.999999999999999:
        break

pointX = np.expand_dims(pointX, axis=1)
pointY = np.expand_dims(pointY, axis=1)
pointZ = np.expand_dims(pointZ, axis=1)
resultPoints = np.concatenate((pointX, pointY, pointZ), axis=1)

at, bt, ct = lsm.leastSquare(resultPoints)
print('plane parameter a = %.5f, b = %.5f, c = %.5f'%(at, bt, ct))

print(len(maxIndexArr))
print(maxIndexArr)
maxIndexArr = reverseIndex(maxIndexArr)
print(np.sort(maxIndexArr))
points = np.delete(points, maxIndexArr, axis=0)
ar, br, cr = lsm.leastSquare(points)
print('plane parameter a = %.5f, b = %.5f, c = %.5f'%(ar*0.6, br*0.6, cr*0.6))


ax.scatter(points[:,0], points[:,1], points[:,2], c='r', marker='o')
ax.legend()

plt.show()

