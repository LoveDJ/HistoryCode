import cv2 as cv
import numpy as np
from matplotlib import pyplot as plt

img = cv.imread('../data/HW2.png', cv.IMREAD_GRAYSCALE)
cv.imshow('win', img)
cv.waitKey(0)
sparseStep = 200
img1D = np.reshape(img, -1)
x = np.arange(len(img1D))
y = img1D
plt.scatter(x[::sparseStep], y[::sparseStep], s=2)
plt.show()

sX = x[::sparseStep]
sX = sX + np.random.randn(len(sX))

sY = y[::sparseStep]
sY = sY + np.random.randn(len(sY))

outliersX = []
outliersY = []
delNum = 1
delCount = int(len(sX)*0.2)
for v in range(delCount):
    print('delCount:%d  now:%d'%(delCount, v))
    rxy_arr = []
    for i in range(len(sX)):
        rxy = np.abs(np.corrcoef(np.delete(sX, i), np.delete(sY, i))[0][1])
        rxy_arr.append(rxy)

    indexC = np.argsort(-np.array(rxy_arr))
    delIndexArr = indexC[0:delNum]
    outliersX.append(sX[delIndexArr])
    outliersY.append(sY[delIndexArr])
    sX = np.delete(sX, delIndexArr)
    sY = np.delete(sY, delIndexArr)
plt.scatter(sX, sY, s=2)
plt.scatter(outliersX, outliersY, c='r',s=2)
plt.show()

print('123')