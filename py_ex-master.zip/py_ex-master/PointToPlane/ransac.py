'''

use ransac to fit plane
author:dingjian
date:2019-08-14
email:jeanding001@163.com

'''

import argparse
import random
import time

import numpy as np
from sympy import *

from PointToPlane import Utils


def ransac(points, distThd=0.05, proThd=0.3, iterNum=1000):
    maxInpointNum = 0
    maxA = 0
    maxB = 0
    maxC = 0
    print('points length = %d , iterNum = %d , start iterate....'%(len(points), iterNum))
    for i in range(iterNum):
        oneSTime = time.time()
        #print('iter number = %d'%(i))
        newInpointNum = 0
        # init plane by three points

        point_1 = points[random.randint(0, len(points) - 1)]
        point_2 = points[random.randint(0, len(points) - 1)]
        point_3 = points[random.randint(0, len(points) - 1)]

        a = Symbol('a')
        b = Symbol('b')
        c = Symbol('c')
        result = solve([point_1[0] * a + point_1[1] * b + point_1[2] * c - 1,
                        point_2[0] * a + point_2[1] * b + point_2[2] * c - 1,
                        point_3[0] * a + point_3[1] * b + point_3[2] * c - 1, ], [a, b, c])

        # print('point_1 coor: x:%.2f y:%.2f z:%.2f' % (point_1[0], point_1[1], point_1[2]))
        # print('point_2 coor: x:%.2f y:%.2f z:%.2f' % (point_2[0], point_2[1], point_2[2]))
        # print('point_3 coor: x:%.2f y:%.2f z:%.2f' % (point_3[0], point_3[1], point_3[2]))
        try:
            a = float(result[a])
            b = float(result[b])
            c = float(result[c])
        except Exception:
            continue
        comn = np.sqrt(np.square(a) + np.square(b) + np.square(c))
        for point in points:
            d = np.abs(a * point[0] + b * point[1] + c * point[2] - 1) / comn

            if d < distThd:
                newInpointNum = newInpointNum + 1

        if newInpointNum > maxInpointNum:
            maxInpointNum = newInpointNum
            maxA = a
            maxB = b
            maxC = c
            continue
        if i == iterNum - 1:
            print('iter number = %d' % (i))
            print('maxInpointNum = %d , maxA = %.2f maxB = %.2f maxC = %.2f' % (maxInpointNum, maxA, maxB, maxC))
        oneETime = time.time()
        # print('one iteration time = %d'%(oneETime - oneSTime))
    return maxA, maxB, maxC

parser = argparse.ArgumentParser(description='PointToPlane')
parser.add_argument('--distThd', dest='distThd',
                            help='default distance threshold is 0.05',
                            default=0.05, type=float)
parser.add_argument('--proThd', dest='pro_thd',
                            help='default proportion threshold is 0.3',
                            default=0.3, type=float)
parser.add_argument('--step', dest='step',
                            help='step of sparsing points',
                            default=10, type=int)

parser.add_argument('--iterNum', dest='iterNum',
                            help='step of sparsing points',
                            default=1000, type=int)

args = parser.parse_args()


# N =  math.log(0.01) / math.log(1 - 0.045**3)
plyPath = '../data/indoor.ply'
points = Utils.readMesh(plyPath,step=args.step)
sTime = time.time()
ransac(points, distThd=args.distThd, iterNum=args.iterNum)
eTime = time.time()
print('all time is %d'%(eTime-sTime))

