import requests
import pprint
import csv

results = []
with open('cityidloc-20180625.csv','r',encoding='UTF-8') as citylocfile, \
        open('city.csv','r',encoding='GBK') as cityfile, open('./1.csv','w',encoding='GBK') as resultfile:
    cityreader = csv.reader(cityfile)
    citylocreader = csv.reader(citylocfile)
    cityarr = [row[0] for row in cityreader]
    citylocarr = [row for row in citylocreader]

    for cityname in cityarr:
        for i in range(len(citylocarr)):
            if cityname in citylocarr[i][2] or cityname in citylocarr[i][3]:
                longitude = citylocarr[i][5]
                latitude = citylocarr[i][4]

                url = 'https://api.caiyunapp.com/v2/TAkhjf8d1nlSlspN/%s,%s/daily.json?dailysteps=1' % (
                longitude, latitude)
                response = requests.get(url)
                data = response.json()
                # 温度
                temperature_min = data['result']['daily']['temperature'][0]['min']
                temperature_max = data['result']['daily']['temperature'][0]['max']
                temperature_avg = data['result']['daily']['temperature'][0]['avg']
                # 湿度
                humidity_min = data['result']['daily']['humidity'][0]['min']
                humidity_max = data['result']['daily']['humidity'][0]['max']
                humidity_avg = data['result']['daily']['humidity'][0]['avg']
                # 天气
                skycon = data['result']['daily']['skycon'][0]['value']
                skycon_08h_20h = data['result']['daily']['skycon_08h_20h'][0]['value']

                line = cityname+','+str(skycon_08h_20h) + ',' + str(temperature_max) + ',' + str(temperature_min) + ',' + str(
                    humidity_avg) + '\n'
                resultfile.write(line)
                break

            if i== len(citylocarr)-1:
                line = cityname+','+'error,error,error,error\n'
                resultfile.write(line)





