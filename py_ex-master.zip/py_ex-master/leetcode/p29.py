class Solution(object):
    def spiralOrder(self, matrix):
        """
        :type matrix: List[List[int]]
        :rtype: List[int]
        """
        result = []
        if len(matrix) == 0:
            return result
        i = 0
        j = 0
        end = len(matrix[0])-1
        end2 = len(matrix) -1
        sta = 0
        sta2 = 0
        while sta <= end and sta2 <= end2:
            while j < end:
                result.append(matrix[i][j])
                j += 1
            while i < end2:
                result.append(matrix[i][j])
                i += 1
            if j == sta or i == sta2:
                result.append(matrix[i][j])
            while j > sta and i > sta2:
                result.append(matrix[i][j])
                j -= 1
            while i > sta2 and j < end:
                result.append(matrix[i][j])
                i -= 1
            end -= 1
            end2 -= 1
            sta += 1
            sta2 += 1
            i += 1
            j += 1
        return result


matrix = [[1],[2],[3]]
so = Solution()
re = so.spiralOrder(matrix)
print(re)