class Solution(object):
    def addBinary(self, a, b):
        """
        :type a: str
        :type b: str
        :rtype: str
        """
        i = len(a) - 1
        a_10 = 0
        a_up = len(a) - 1
        while i >= 0:
            a_10 += int(a[i]) * 2 ** (a_up - i)
            i -= 1

        j = len(b) - 1
        b_10 = 0
        b_up = len(b) - 1
        while j >= 0:
            b_10 += int(b[j]) * 2 ** (b_up - j)
            j -= 1

        c = a_10 + b_10

        c_2 = []
        while c != 0:
            c_2.append(c % 2)
            c = c // 2

        result = ""
        i = len(c_2) - 1
        while i >= 0:
            result += str(c_2[i])
            i -= 1

        return result

so = Solution()
so.addBinary("1010", "1011")