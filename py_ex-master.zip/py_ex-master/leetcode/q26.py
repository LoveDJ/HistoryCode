class Solution(object):
    def removeDuplicates(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        i = 0
        j = 0
        while i < len(nums):
            if i == 0:
                i += 1
                j += 1
            else:
                if nums[i] == nums[i-1]:
                    i += 1
                else:
                    nums[j] = nums[i]
                    i += 1
                    j += 1
        return j