class Solution(object):
    def longestCommonPrefix(self, strs):
        """
        :type strs: List[str]
        :rtype: str
        """
        cs = ""
        if len(strs) == 0:
            return cs
        min_len = len(strs[0])
        for i in range(len(strs)):
            if len(strs[i]) < min_len:
                min_len = len(strs[i])

        for i in range(min_len):
            s = strs[0][i]
            for j in range(len(strs)):
                if strs[j][i] != s:
                    return cs
            cs += s
        return cs