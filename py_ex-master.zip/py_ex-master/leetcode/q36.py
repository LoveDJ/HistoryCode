class Solution(object):
    def permute(self, nums):
        """
        :type nums: List[int]
        :rtype: List[List[int]]
        """
        if nums is None: return []
        if len(nums) == 1: return [nums]
        result = []
        for i in range(len(nums)):
            nums2 = nums.copy()
            nums2.pop(i)
            temp = self.permute(nums2)
            for temList in temp:
                temList.insert(0, nums[i])
            result += temp

        return result

sol = Solution()
nums = [1,2,3]
sol.permute(nums)