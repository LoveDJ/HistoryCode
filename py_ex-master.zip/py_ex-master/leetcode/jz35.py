"""
# Definition for a Node."""
class Node:
    def __init__(self, x, next=None, random=None):
        self.val = int(x)
        self.next = next
        self.random = random


class Solution(object):
    def copyRandomList(self, head):
        """
        :type head: Node
        :rtype: Node
        """
        if head is None: return []
        head2 = Node(head.val)
        node2pre = head2
        node = head.next
        table = {head: head2}
        while node:
            node2cur = Node(node.val)
            table[node] = node2cur
            node2pre.next = node2cur
            node2pre = node2cur
            node = node.next

        node = head
        node2 = head2
        while node:
            if node.random is not None:
                node2.random = table[node.random]
            node = node.next
            node2 = node2.next
        return head2

numList = [[7,None],[13,0],[11,4],[10,2],[1,0]]
head = Node(0)
tmpNode = head
nodeArr = []
for i in range(len(numList)):
    node = Node(numList[i][0])
    nodeArr.append(node)
    tmpNode.next = node
    tmpNode = tmpNode.next

for i in range(len(numList)):
    index = numList[i][1]
    if index:
        nodeArr[i].random = nodeArr[index]
# print list
head = head.next
tmpNode = head
while tmpNode:
    print(tmpNode.val)
    tmpNode = tmpNode.next

sol = Solution()
head2 = sol.copyRandomList(head)
tmpNode = head2
while tmpNode:
    print(tmpNode.val)
    tmpNode = tmpNode.next
