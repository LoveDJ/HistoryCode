class Solution(object):
    def reverse(self, x):
        """
        :type x: int
        :rtype: int
        """
        x2 = x
        if x < 0:
            x2 = -x
        x2 = str(x2)

        x2 = x2[::-1]
        x3 = x2
        for i in range(len(x2)):
            if len(x2)==1:
                break
            if x2[i]=='0':
                x3 = x3[1:]
            else:
                break
        x4 = int(x3)

        if x < 0:
            x4 = -x4
        if x4>2**31-1 or x4<-2**31:
            return 0
        else:
            return x4

solution = Solution()
x = 100
print(solution.reverse(x))