# Definition for a binary tree node.
class TreeNode(object):
    def __init__(self, x):
        self.val = x
        self.left = None
        self.right = None

class Solution(object):
    def pathSum(self, root, sum):
        """
        :type root: TreeNode
        :type sum: int
        :rtype: List[List[int]]
        """
        if root is None: return []
        path = []
        result = []
        self.pathSum2(root, sum, path, 0, result)
        return result

    def pathSum2(self, root, expectedSum, path, sum, result):
        path.append(root)
        sum += root.val
        isLeaf = False
        if root.left is None and root.right is None: isLeaf = True
        if isLeaf and expectedSum == sum:
            result.append([node2.val for node2 in path])

        if root.left: self.pathSum2(root.left, expectedSum, path, sum, result)
        if root.right: self.pathSum2(root.right, expectedSum, path, sum, result)

        path.pop()
        return

nums = [5,4,8,11,None,13,4,7,2,None,None,5,1]
TreeNodes = []
root = None
for i in range(len(nums)):
    if nums[i] is None: TreeNodes.append(None)
    else: TreeNodes.append(TreeNode(nums[i]))

lis = []
lis.append(TreeNodes[0])
i = 1
while lis:
    node = lis.pop(0)
    if node is None: continue
    if i > len(TreeNodes)-1:
        node.left = None
        node.right = None
    else:
        node.left = TreeNodes[i]
        node.right = TreeNodes[i+1]
        lis.append(TreeNodes[i])
        lis.append(TreeNodes[i+1])
        i += 2

root = TreeNodes[0]

sol = Solution()
result = sol.pathSum(root, 22)
print(result)