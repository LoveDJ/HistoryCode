class Solution:
    def minNumberInRotateArray(self, rotateArray):
        # write code here
        if rotateArray is None or len(rotateArray) == 0: return 0
        pStart = 0
        pEnd = len(rotateArray) - 1
        while pStart <= pEnd:
            if rotateArray[pStart] < rotateArray[pEnd]: return rotateArray[pStart]
            pMid = (pEnd + pStart) // 2
            if rotateArray[pMid] > rotateArray[pStart]:
                pStart = pMid + 1
            elif rotateArray[pMid] < rotateArray[pStart]:
                pEnd = pMid
            else:
                minNum = rotateArray[pStart]
                for num in rotateArray:
                    if num < minNum: minNum = num
                return minNum


sol = Solution()
print(sol.minNumberInRotateArray([3,4,5,1,2,3,3]))
