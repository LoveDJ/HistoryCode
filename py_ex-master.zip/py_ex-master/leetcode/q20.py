class Solution(object):
    def isValid(self, s):
        """
        :type s: str
        :rtype: bool
        """
        if s=="":
            return True
        dic = {"(":")", "{":"}", "[":"]"}
        stack = []
        for i in range(len(s)):
            if s[i] in dic.keys():
                stack.append(s[i])
            else:
                if len(stack) == 0:
                    return False
                if dic[stack[-1]] == s[i]:
                    stack.pop()
                else:
                    return False
        if len(stack)!=0:
            return False
        else:
            return True