class Solution(object):
    def twoSum(self, nums, target):
        """
        :type nums: List[int]
        :type target: int
        :rtype: List[int]
        """
        for i in range(len(nums)):
            nums2 = target - nums[i]
            low = i + 1
            high = len(nums) - 1
            while low <= high:
                mid = (low+high)//2
                if nums[mid] == nums2:
                    return [i, mid]
                else:
                    if nums[mid] > nums2:
                        high = mid - 1
                    elif nums[mid] < nums2:
                        low = mid + 1
        return None

solution = Solution()
nums = [0, 4, 3, 0]
target = 9
print(solution.twoSum(nums, target))