class Solution(object):
    def verifyPostorder(self, postorder):
        """
        :type postorder: List[int]
        :rtype: bool
        """
        if not postorder: return []
        self.verifyPostorder2(postorder,0, len(postorder)-1)

    def verifyPostorder2(self,postorder, beg, end):
        if beg >= end: return True
        i = beg
        while i < end and postorder[i]<postorder[end]: i += 1
        j = i
        while j < end:
            if postorder[j] < postorder[end]:return False
            j += 1
        return self.verifyPostorder2(postorder, beg, i-1) and self.verifyPostorder2(postorder, i, end-1)

sol = Solution()
postorer = [4, 8, 6, 12, 16, 14, 10]
print(sol.verifyPostorder(postorer))