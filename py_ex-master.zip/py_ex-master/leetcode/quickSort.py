import random
def partition(data, start, end):
    r = random.randint(start, end) #choose one number
    data[end], data[r] = data[r], data[end]
    small = start # 第一个最大的数
    index = start
    while index < end:
        if data[index] < data[end]:
            if index != small:
                data[small], data[index] = data[index], data[small]
            small += 1
        index += 1
    data[small], data[end] = data[end], data[small]
    return small
def quickSort(data, start, end):
    if data==None or len(data)==0 or start == end: return
    index = partition(data, start, end)
    if index > start: partition(data, start, index-1)
    if index < end: partition(data, index+1, end)

data = [1]
quickSort(data, 0, len(data)-1)
print(data)
