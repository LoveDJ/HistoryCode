# -*- coding:utf-8 -*-
class ListNode:
    def __init__(self, x):
        self.val = x
        self.next = None
class Solution:
    # 返回ListNode
    def ReverseList(self, pHead):
        # write code here
        if pHead is None: return None
        pa = None
        pCurr = pHead
        pb = pCurr.next
        while pCurr != None:
            if pa is None:
                pCurr.next = None
                pa = pCurr
                pCurr = pb
                if pb is not None:
                    pb = pb.next
            else:
                pCurr.next = pa
                pa = pCurr
                pCurr = pb
                if pb is not None:
                    pb = pb.next
        return pa

pHead = None
pCurr = None
nodeArr = [1,2,3,4,5]
for node in nodeArr:
    if pHead is None:
        pHead = ListNode(node)
        pCurr = pHead
    else:
        pCurr.next = ListNode(node)
        pCurr = pCurr.next

pCurr = pHead
while pCurr is not None:
    print(pCurr.val)
    pCurr = pCurr.next

sol = Solution()
pHead = sol.ReverseList(pHead)
pCurr = pHead
while pCurr is not None:
    print(pCurr.val)
    pCurr = pCurr.next