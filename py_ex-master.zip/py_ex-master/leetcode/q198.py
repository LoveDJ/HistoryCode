class Solution(object):
    def rob(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        if len(nums) == 0:
            return 0
        dp = []
        for i in range(len(nums)):
            if i == 0:
                dp.append(nums[0])
            elif i == 1:
                if nums[1]>nums[0]:
                    dp.append(nums[1])
                else:
                    dp.append(nums[0])
            else:
                if nums[i]+dp[i-2] > dp[i-1]:
                    dp.append(nums[i]+dp[i-2])
                else:
                    dp.append(dp[i-1])
        return dp[-1]