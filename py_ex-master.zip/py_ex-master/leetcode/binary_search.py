def binary_search(nums, target):
    low, high = 0, len(nums)-1
    while low <= high:
        mid = (low+high)//2
        if nums[mid] == target: return mid
        elif nums[mid] < target: low = mid + 1
        elif nums[mid] > target: high = mid - 1
    return None

nums = [1,2]
target = 2
index = binary_search(nums,target)
print(index)