class Solution(object):
    def translateNum(self, num):
        """
        :type num: int
        :rtype: int
        """

        dp = []
        sNum = str(num)
        for i in range(len(sNum)):
            if i == 0:
                dp.append(1)
            elif i == 1:
                if int(sNum[0:2]) < 26:
                    dp.append(2)
                else:
                    dp.append(1)
            else:
                if int(sNum[i - 1:i + 1]) < 26 and int(sNum[i - 1:i + 1]) > 9:
                    dp.append(dp[i - 1] + dp[i - 2])
                else:
                    dp.append(dp[i - 1])

        return dp[-1]

so = Solution()
print(so.translateNum(1727101694))