class Solution:
    # array 二维列表
    def GetArea(self, x, y):
        # write code here
        dp = []
        for i in range(len(x)):
            if i == 0:
                dp.append(x[i]*y[i])
            else:
                j = i-1
                length = x[i]
                while j >=0:
                    if y[i] <= y[j]:
                        length += x[j]
                        j -= 1
                    else: break
                area = length * y[i]
                dp.append(max(area, dp[-1]))
        return dp[-1]

sol = Solution()
x = [1,1,1,1,2,1,1]
y = [5,2,5,4,5,6]
print(sol.GetArea(x, y))