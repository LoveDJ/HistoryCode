class Solution(object):
    def strStr(self, haystack, needle):
        """
        :type haystack: str
        :type needle: str
        :rtype: int
        """
        if needle =="":
            return 0
        i = 0
        j = 0
        k = 0
        while k < len(haystack):
            if haystack[k] == needle[j]:
                i = k
                while j < len(needle) and i < len(haystack):
                    if haystack[i] == needle[j]:
                        i += 1
                        j += 1
                        continue
                    else:
                        break
                if j == len(needle):
                    return k
                else:
                    i = 0
                    j = 0
                k += 1
            else:
                k += 1
        return -1