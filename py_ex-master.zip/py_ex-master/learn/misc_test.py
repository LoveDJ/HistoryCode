""""
misc test
"""
import cv2 as cv
from scipy import misc
import numpy as np



image = cv.imread('./data/1.jpg')#加载图像
image = cv.cvtColor(image, cv.COLOR_BGR2RGB)
a = image/127.5 - 1
b = (a+1.)/2
misc.imsave('./data/2.jpg',b)
cv.imshow('image',b)

image2 = cv.imread('./data/2.jpg')
cv.waitKey(0)
