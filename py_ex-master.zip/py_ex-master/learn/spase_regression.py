import numpy as np

data = np.array([[14.9607083, 1.5953295, 2.9141118, 2.9490906, 2.3531784, 1.0412069, 0.8151355],
                 [-0.3579434, -0.5584693, -1.1981533, 1.2275879, 0.3332272, 0.5569235, -1.9695117],
                 [0.8765146, -0.6689517, 0.9050208, 1.1657989, 1.3203673, -0.7263651, 0.3727694],
                 [1.8098995, 0.2648723, -1.0164312, -0.2752811, 1.6298845, 0.5185340, 0.4962158],
                 [3.0404683, -0.4606268, 0.3767176, 0.9498028, 1.2291411, 1.6759266, -1.6201224],
                 [-4.4359221, -0.1008654, -0.9888361, 0.4612514, 1.1799055, -0.6183934, -1.7610674]])

R = np.corrcoef(data[:, 1:])
x1 = data[:,1]
x2 = data[:,2]
x3 = data[:,4]
y = data[:,0]
r1 = np.vstack((x1,x2,x3,y))
r2 = np.vstack((x1,x2,x3))

corr1 = np.corrcoef(r1)
corr2 = np.corrcoef(r2)

w1 = np.linalg.det(corr1)
w2 = np.linalg.det(corr2)
print(w1/w2)

print(np.std(y))

print(np.std(y)*np.mat(corr2).I*np.transpose(np.mat(corr1[:-1,-1])))
beta1 = 3.53404494/np.std(x1)
beta2 = 4.12519936/np.std(x2)
beta3 = -1.52597926/np.std(x3)
beta0 = np.mean(y)-(beta1*np.mean(x1)+beta2*np.mean(x2)+beta3*np.mean(x3))

print(123)