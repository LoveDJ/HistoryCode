import numpy as np
import time
import os
import math
from PointToPlane import Utils

dir_path = '/home/dj/code/python/py_ex/data/scanNet'

files = os.listdir(dir_path)
files = sorted(files)
lengthArr = []
for i,file_name in enumerate(files):
    if len(file_name)>8:
        file_path = os.path.join(dir_path, file_name)
        # print(file_path)
        points = Utils.readMesh(file_path)
        length = len(points)
        maxP = np.max(points, axis=0)
        minP = np.min(points, axis=0)
        # print(new_file)
        lengthArr.append(length)
        print(length)
        print('%.3f, %.3f, %.3f' % (minP[0] - 0.001, minP[1] - 0.001, minP[2] - 0.001))
        print('%.3f, %.3f, %.3f'%(maxP[0]+0.001, maxP[1]+0.001, maxP[2]+0.001))
print(lengthArr)
    # if os.path.exists(new_file):
    #     os.remove(new_file)
    #     f2 = open(new_file, 'w')
    #     f2.close()
    #
    # file = open(new_file, 'a+')
    # for point in points:
    #     x = point[0]
    #     y = point[1]
    #     z = point[2]
    #     file.write(str(x) + ' ' + str(y) + ' ' + str(z) + '\n')
    # file.close()