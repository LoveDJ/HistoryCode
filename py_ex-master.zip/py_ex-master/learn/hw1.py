[n,m] = list(map(int, input().split()))
record = []
for i in range(n):
    record.append([float(j)for j in input().split()])

def findPath2(self, n, m, arr, a, b):
    if a == n-1 and b == m-1:
        return 0
    if arr[a][3*b] != 0:
        return 1/arr[a][3*b]+self.findPath2(n, m, arr, a+1, b)
    if arr[a][3*b+1] != 0:
            return 1/arr[a][3*b+1]+self.findPath2(n, m, arr, a, b+1)

a = 0
b = 0
print(findPath2(n, m, record, a, b))


