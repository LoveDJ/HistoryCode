"""video demo"""
import cv2 as cv
import os


for root, dirs, files in os.walk('./data2'):
    videoWriter = cv.VideoWriter('./a.mp4',cv.VideoWriter_fourcc('M','J','P','G'),25,(256,256))
    for file in files:
        image = cv.imread(os.path.join(root, file))
        for i in range(500):
            videoWriter.write(image)
