'''

this script only read points and faces from ply file
more information about plyfile : https://github.com/dranjan/python-plyfile
date:2019-08-02
author:ding jian
email: jeanding001@163.com

'''
from plyfile import PlyData
import numpy as np
import os

def readMesh(plyPath):

    plydata = PlyData.read(plyPath)
    vertices = plydata['vertex']
    points = np.stack([vertices['x'], vertices['y'], vertices['z']], axis=1)
    # faces = np.array(plydata['face']['vertex_indices'])
    return points

plyPath = './points2.ply'
points = readMesh(plyPath)
# print(points)




a = -0.000181894
b = -0.00629982
c = 0.999998
d = 0.0303173
comn = np.sqrt(np.square(a) + np.square(b) + np.square(c))


if os.path.exists('./point_result.ply'):
    os.remove('./point_result.ply')
    f2 = open('./point_result.ply', 'w')
    f2.close()

file = open('./point_result.ply', 'a+')

file.write('ply\n')
file.write('format ascii 1.0\n')
file.write('element vertex %d\n' % (len(points)))
file.write('property float x\n')
file.write('property float y\n')
file.write('property float z\n')
file.write('property uchar red\n')
file.write('property uchar green\n')
file.write('property uchar blue\n')
file.write('end_header\n')


distancess = np.abs(np.dot(points, np.array([a, b, c]))-d)

inPointsDist = distancess[distancess<0.05]

for i, point in enumerate(points):
    x = point[0]
    y = point[1]
    z = point[2]
    dist = distancess[i]

    if dist < 0.05:
        file.write(str(x) + ' ' + str(y) + ' ' + str(z) + ' 0 255 0\n')
    else:
        file.write(str(x) + ' ' + str(y) + ' ' + str(z) + ' 255 0 0\n')

file.close()


