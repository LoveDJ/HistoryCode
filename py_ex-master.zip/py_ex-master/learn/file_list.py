'''

遍历文件夹
删除文件

'''


import os
import cv2 as cv
import shutil
dir_path = r'/home/dj/code/python/wireframe-dj/data/v1.1/test_all'
txt_path = '/home/dj/code/python/wireframe-dj/data/v1.1/test.txt'
if not os.path.exists(txt_path):
    f = open(txt_path,'w')
    f.close()
f = open(txt_path,'a+')
for root, dirs, files in os.walk(dir_path):
    for file_name in files:
        f.write(file_name+'\n')

f.close()
