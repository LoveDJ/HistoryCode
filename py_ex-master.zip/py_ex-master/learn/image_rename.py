'''

遍历文件夹
删除文件

'''


import os
import cv2 as cv
import shutil
dir_path = r'/home/dj/code/python/wireframe-dj/result/linepx/0_test/im'
txt_path = '/home/dj/code/python/wireframe-dj/data/v1.1/test.txt'
out_path = '/home/dj/code/python/wireframe-dj/data/v1.1/result'
# sub_paths = os.listdir(dir_path)
# for sub_path in sub_paths:
#     sub_path_all = os.path.join(dir_path, sub_path)
#     if os.path.isdir(sub_path_all):
#         for root, dirs, files in os.walk(sub_path_all):
#             for file_name in files:
#                 if file_name.endswith('.jpg'):
#                     file_path = os.path.join(root, file_name)
#                     new_file_name = sub_path + file_name
#                     new_file_path = os.path.join(out_path, new_file_name)
#                     shutil.copy(file_path, new_file_path)
f = open(txt_path,'r')
files = os.listdir(dir_path)
files.sort()

for file_name in files:
    txt_name = f.readline()
    pre_dir = txt_name[0:2]
    file_name_true = txt_name[2:-5]+'_wireframe.png'

    file_path_pre = os.path.join(out_path, pre_dir)
    if not os.path.exists(file_path_pre):
        os.makedirs(file_path_pre)
    file_path_new = os.path.join(file_path_pre, file_name_true)

    file_path = os.path.join(dir_path, file_name)
    im = cv.imread(file_path)
    cv.imwrite(file_path_new, im)

# for root, dirs, files in os.walk(dir_path):
#     for file_name in files:
#         txt_name = f.readline()
#         pre_dir = txt_name[0:2]
#         file_name_true = txt_name[2:-1]
#
#         file_path_new = os.path.join(out_path, pre_dir)
#         file_path_new = os.path.join(file_path_new, file_name_true)
#
#         file_path = os.path.join(root, file_name)
#
#         shutil.copy(file_path, file_path_new)
#         # img = cv.imread(file_path)
#         # new_file_path = file_path.replace('.jpg','_rgb.png')
#         # if not os.path.exists(new_file_path):
#         #     cv.imwrite(new_file_path, img)
