'''
depth map to point
date:2019-08-01
author:ding jian
email:jeanding001@163.com

'''

import cv2 as cv
import os
from PointToPlane import Utils
import numpy as np


IMAGE_HEIGHT = 760
IMAGE_WIDTH = 1280
rootPath = '/home/dj/data/SYNTHIA-SEQS-02-SPRING/Depth/Stereo_Left/Omni_F/'
files = os.listdir(rootPath)
files = sorted(files)


for i, file in enumerate(files):
    if i%90 == 0:
        file_path = os.path.join(rootPath, file)
        depthMap = cv.imread(file_path)
        # depthMap = cv.resize(depthMap,(80, 48) )
        depthMap = depthMap[:, :, 0]
        # cv.imshow('depth', depthMap)
        # cv.waitKey(0)

        f = 133.185
        u0 = 640.
        v0 = 380.
        if os.path.exists('../results/outdoor/'+ str(
                i) + 'point.ply'):
            os.remove('../results/outdoor/'+ str(i) + 'point.ply')
            f2 = open('../results/outdoor/'+ str(i) + 'point.ply',
                      'w')
            f2.close()

        file = open('../results/outdoor/'+ str(i) + 'point.ply',
                    'a+')

        file.write('ply\n')
        file.write('format ascii 1.0\n')
        file.write('element vertex 959860\n')
        file.write('property float x\n')
        file.write('property float y\n')
        file.write('property float z\n')
        file.write('end_header\n')

        count = 0

        for row in range(IMAGE_HEIGHT):
            for col in range(IMAGE_WIDTH):
                zi = depthMap[row][col]
                if zi != 255 and zi != 0:
                    xw = zi * (row - u0) / f
                    yw = zi * (col - v0) / f
                    zw = -zi/2
                    file.write(str(xw) + ' ' + str(yw) + ' ' + str(zw) + '\n')
                    count = count + 1


        file.close()
        print(count)



