'''像素取反'''

import cv2 as cv
import numpy as np

image = cv.imread('./data/lb.jpg')
cv.imshow('ori_image', image)
cv.waitKey(0)

#取反操作
new_image = cv.bitwise_not(image)

cv.imshow('not_image', new_image)
cv.waitKey(0)
