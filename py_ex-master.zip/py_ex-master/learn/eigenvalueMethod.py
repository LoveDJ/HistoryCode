'''
describe: least square method to fit plane
date: 2019-10-10
author: dingjian
eigenvalue method reference blog: https://blog.csdn.net/konglingshneg/article/details/82585868
'''

import numpy as np
from sympy import *

from pointToPlane import Utils


def leastSquare(points):

    x_vector = points[:, 0]
    y_vector = points[:, 1]
    z_vector = points[:, 2]


    X2_MEAN = np.mean(x_vector * x_vector)
    X_MEAN = np.mean(x_vector)
    X_MEAN_2 = math.pow(np.mean(x_vector), 2)

    Y2_MEAN = np.mean(y_vector * y_vector)
    Y_MEAN = np.mean(y_vector)
    Y_MEAN_2 = math.pow(np.mean(y_vector), 2)

    Z2_MEAN = np.mean(z_vector * z_vector)
    Z_MEAN = np.mean(z_vector)
    Z_MEAN_2 = math.pow(np.mean(z_vector), 2)

    XY_MEAN = np.mean(x_vector * y_vector)
    XZ_MEAN = np.mean(x_vector * z_vector)
    YZ_MEAN = np.mean(y_vector * z_vector)


    A11 = X2_MEAN - X_MEAN_2
    A12 = XY_MEAN - X_MEAN * Y_MEAN
    A13 = XZ_MEAN - X_MEAN * Z_MEAN

    A21 = A12
    A22 = Y2_MEAN - Y_MEAN_2
    A23 = YZ_MEAN - Y_MEAN * Z2_MEAN

    A31 = A13
    A32 = A23
    A33 = Z2_MEAN - Z_MEAN_2


    A = np.array([[A11, A12, A13], [A21, A22, A23], [A31, A32, A33]])

    lamds, eigenValues = np.linalg.eig(A)



    print('the plane para are a = %f , b = %f , c = %f')


plyPath = './data/points.ply'
points = Utils.readMesh(plyPath)
leastSquare(points)