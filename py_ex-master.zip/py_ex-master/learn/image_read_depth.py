'''
read depth image

'''

import cv2 as cv
dep_img = cv.imread(r'E:\cache\000005_depth.png')

print('123')


