""""
对像素进行操作
"""
import cv2 as cv
import numpy as np

'''对单个像素进行操作'''
def changeImage(image):
    height = image.shape[0]
    width = image.shape[1]
    channel = image.shape[2]

    for h in range(height):
        for w in range(width):
            for r in range(channel):
                pixel = image[h, w, r]
                new_pixel = 255 - pixel #对图像进行反色
                image[h, w, r] = new_pixel


def createBlueImage():
    blue_image = np.zeros([400,400,3])
    '''切片操作'''
    blue_image[: , : , 0] = np.ones([400,400])*255 # blue green red
    cv.imshow('blue_image', blue_image)

def createSingleImage():
    image = np.ones([400,400],np.uint8)*122
    cv.imshow('single channel image',image)


src = cv.imread('./data/lb.jpg')#加载图像
t1 = cv.getTickCount()

#changeImage(src)
#createBlueImage()
createSingleImage()

t2 = cv.getTickCount()
time = (t2 - t1)/cv.getTickFrequency()
print('time = %s'%(time*1000))

cv.namedWindow('window', cv.WINDOW_AUTOSIZE)
cv.imshow('window', src)
cv.waitKey(0)
cv.destroyAllWindows()



