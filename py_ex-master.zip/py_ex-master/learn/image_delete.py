'''

遍历文件夹
删除文件

'''


import os

IMAGE_GAP = 20

dir_path = r'H:\movie\pb'
i = 0
for root, dirs, files in os.walk(dir_path):
    for file_name in files:
        i = i+1
        file_path = os.path.join(root, file_name)
        if i%IMAGE_GAP != 0:
            os.remove(file_path)


