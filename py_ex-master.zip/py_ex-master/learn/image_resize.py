'''
image resize
'''

import cv2 as cv
import os

dir_path = '/home/dj/data/Plane_Recover_SYN_data'
sub_paths = os.listdir(dir_path)

for sub_path in sub_paths:
    sub_path_all = os.path.join(dir_path, sub_path)
    if os.path.isdir(sub_path_all):
        for root, dirs, files in os.walk(sub_path_all):
            for file_name in files:
                if file_name.endswith('.jpg'):
                    file_path = os.path.join(root, file_name)
                    new_root_path = root.replace('Plane_Recover_SYN_data', 'Plane_Recover_SYN_data_resize')
                    if not os.path.exists(new_root_path):
                        os.makedirs(new_root_path)
                    new_file_path = os.path.join(new_root_path, file_name)
                    img = cv.imread(file_path)
                    new_img = cv.resize(img, (320, 320), interpolation=cv.INTER_CUBIC)

                    cv.imwrite(new_file_path, new_img)


