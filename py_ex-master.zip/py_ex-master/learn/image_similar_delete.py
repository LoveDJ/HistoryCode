'''

相似的图片删除

'''

import os
import cv2 as cv
import numpy as np


dir_path = 'H:/code/python/cartoonGan_video/dataset/face2anime/trainA/1999'
i = 0
for root, dirs, files in os.walk(dir_path):
    pre_file_path = ''
    for file_name in files:
        file_path = os.path.join(root, file_name)
        if pre_file_path == '':
            pre_file_path = file_path

        else:
            image = cv.imread(file_path)
            pre_image = cv.imread(pre_file_path)

            diff_array = image-pre_image
            diff_sum = np.sum(diff_array)
            print('pre_file_path=',pre_file_path)
            print('file_path=', file_path)
            print('diff_sum=', diff_sum)
            if diff_sum < 100000000:
                os.remove(file_path)
            else:
                pre_file_path = file_path

