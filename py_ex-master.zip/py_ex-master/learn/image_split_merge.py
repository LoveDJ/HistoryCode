'''
通道分离与合并
'''
import cv2 as cv
import numpy as np


image = cv.imread('./data/lb.jpg')
#利用调试观察值
b, g, r = cv.split(image)


merge_image = cv.merge([b, g, r])

cv.imshow('merge_image', merge_image)
cv.waitKey(0)