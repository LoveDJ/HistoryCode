import numpy as np
from PointToPlane import Utils
import os

dir_path = '../results/outdoor'

files = os.listdir(dir_path)
files = sorted(files)
for i, file in enumerate(files):
    print('start '+str(i))
    file_path = os.path.join(dir_path, file)
    points = Utils.readMesh(file_path)
    x = Utils.normalize_vector(points[:, 0])*10000
    y = Utils.normalize_vector(points[:, 1])*10000
    z = Utils.normalize_vector(points[:, 2])*10000

    x = np.expand_dims(x, axis=1)
    y = np.expand_dims(y, axis=1)
    z = np.expand_dims(z, axis=1)

    points = np.concatenate((x, y, z),axis=1)
    Utils.writePoints(points, path='./'+str(i)+'.ply')