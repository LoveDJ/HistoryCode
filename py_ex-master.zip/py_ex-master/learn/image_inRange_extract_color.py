'''
利用inRange 提取颜色
HSV色彩空间
'''
import cv2 as cv
import numpy as np


image = cv.imread('./data/lb.jpg')
hsv_image = cv.cvtColor(image, cv.COLOR_BGR2HSV)
lowerb = np.array([35, 43, 46])
upperb = np.array([77, 255, 255])
extract_image = cv.inRange(hsv_image, lowerb, upperb)

cv.imshow('extract_image', extract_image)
cv.waitKey(0)