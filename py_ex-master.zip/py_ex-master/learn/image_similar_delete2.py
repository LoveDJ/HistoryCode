'''

利用scikit-image 删除相似图片 ssim指标
'''
import os
import cv2
from skimage.measure import compare_ssim
def delete(filename1):
    os.remove(filename1)
if __name__ == '__main__':
    path = r'H:\movie\pb'
    # save_path_img = r'E:\0115_test\rec_pic'
    # os.makedirs(save_path_img, exist_ok=True)
    img_path = path
    imgs_n = []
    num = []
    img_files = [os.path.join(rootdir, file) for rootdir, _, files in os.walk(path) for file in files if
                 (file.endswith('.jpg'))]
    for currIndex, filename in enumerate(img_files):
        if not os.path.exists(img_files[currIndex]):
            print('not exist', img_files[currIndex])
            break
        img = cv2.imread(img_files[currIndex])
        img1 = cv2.imread(img_files[currIndex + 1])
        ssim = compare_ssim(img, img1, multichannel=True)
        if ssim > 0.7:
            imgs_n.append(img_files[currIndex + 1])
            print(img_files[currIndex], img_files[currIndex + 1], ssim)
        else:
            print('small_ssim',img_files[currIndex], img_files[currIndex + 1], ssim)
        currIndex += 1
        if currIndex >= len(img_files)-1:
            break
    for image in imgs_n:
        delete(image)