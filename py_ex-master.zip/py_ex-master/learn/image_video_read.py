""""
读取操作
"""
import cv2 as cv
import numpy as np
import shutil


def get_image_info(image):
    print(type(image))
    print(image.shape)
    print(image.size)
    print(image.dtype)
    print(image)

src = cv.imread('./data/1.jpg')#加载图像
get_image_info(src)#图像信息
cv.namedWindow('window', cv.WINDOW_AUTOSIZE)
cv.imshow('window', src)
cv.waitKey(0)
gray = cv.cvtColor(src, cv.COLOR_BGR2GRAY)#转成灰度图像
cv.imwrite('./data/lb_copy.jpg', gray)#保存图像
cv.destroyAllWindows()



"""video demo"""
import cv2 as cv


def video_demo():
    videoCapture = cv.VideoCapture('./data/1.mp4')#获取摄像头
    fps = videoCapture.get(cv.CAP_PROP_FPS)
    size = (int(videoCapture.get(cv.CAP_PROP_FRAME_WIDTH)),
            int(videoCapture.get(cv.CAP_PROP_FRAME_HEIGHT)))
    out = cv.VideoWriter('./oto_other.mp4', cv.CAP_PROP_FOURCC, fps, size)
    while(True):
        ret, frame = videoCapture.read()
        out.write(frame)
        #frame = cv.flip(frame, 1)
        #cv.imshow('video', frame)
        c = cv.waitKey(50)
        if c == 27:
            break


video_demo()

