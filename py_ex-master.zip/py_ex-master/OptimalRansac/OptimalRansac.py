import numpy as np
import argparse
import time
import os
from PointToPlane import Utils
import SampleSet
import Resample
import Pruneset

def optimalRansac(x, s, t, acc, maxDataTrials=100, MaxTrials=10, maxit=20, nrtrials=8, low=50, ner=1):
    nes = 0 # Number of equal sets
    maxinl = 0 # Maximum number of inlierse
    iter = 0
    sinliers=[]
    M = []
    while nes < ner and iter < MaxTrials:
        iter = iter + 1
        M, inliers, ninliers = SampleSet.sampleSet(x, s, t, maxDataTrials)

        if ninliers > low:
            M, inliers, ninliers = Resample.resample(x, M, s, t, inliers, ninliers, nrtrials, maxit, low)

            if acc < t:
                M, putative, ninliers = Pruneset.pruneset(M, inliers, t, acc, low)

        if maxinl > low and maxinl == ninliers:
            if (np.sum(inliers==sinliers) == maxinl):
                nes = nes + 1
            else:
                nes = 0
                sinliers = inliers
        elif ninliers > maxinl:
            nes = 0
            maxinl = ninliers
            sinliers = inliers
        elif ninliers == maxinl - 1:
            nes = 0
            maxinl = ninliers
            sinliers = inliers

    return M, sinliers


parser = argparse.ArgumentParser(description='pointToPlane')
parser.add_argument('--distThd', dest='distThd',
                        help='default distance to judge whether a point is on plane',
                        default=0.05, type=float)
parser.add_argument('--corrThd', dest='corrThd',
                        help='default plane corr threshold is 0.99',
                        default=0.98, type=float)
parser.add_argument('--step', dest='step',
                        help='step of sparsing points',
                        default=10, type=int)
parser.add_argument('--pNum', dest='pNum',
                        help='the number of planes to extract',
                        default=10, type=int)
parser.add_argument('--pointsPath', dest='pointsPath',
                        help='the number of planes to extract',
                        default='../data/indoor.ply', type=str)


args = parser.parse_args()
plyPath = args.pointsPath
allPoints = Utils.readMesh(plyPath, step=args.step)

print('finish reading points mesh...the all points length = %d'%(len(allPoints)))
startTime = time.time()
allPoints = np.array(allPoints)
M, sinliers = optimalRansac(allPoints, 3, 0.1, 0.05)
endTime = time.time()

print('consume time = %.3f'%(endTime - startTime))

a = M[0]
b = M[1]
c = M[2]
comn = np.sqrt(np.square(a) + np.square(b) + np.square(c))


if os.path.exists('./point_optimalRansac_result.ply'):
    os.remove('./point_optimalRansac_result.ply')
    f2 = open('./point_optimalRansac_result.ply', 'w')
    f2.close()

file = open('./point_optimalRansac_result.ply', 'a+')

file.write('ply\n')
file.write('format ascii 1.0\n')
file.write('element vertex %d\n' % (len(allPoints)))
file.write('property float x\n')
file.write('property float y\n')
file.write('property float z\n')
file.write('property uchar red\n')
file.write('property uchar green\n')
file.write('property uchar blue\n')
file.write('end_header\n')

for point in allPoints:
    x = point[0]
    y = point[1]
    z = point[2]
    d = np.abs(a * x + b * y + c * z - 1) / comn

    if d < args.distThd:
        file.write(str(x) + ' ' + str(y) + ' ' + str(z) + ' 0 255 0\n')
    else:
        file.write(str(x) + ' ' + str(y) + ' ' + str(z) + ' 255 0 0\n')

file.close()