import numpy as np
import random
import Fittingfn
import Distfn

def sampleSet(x, s, t, maxDataTrials):

    degenerate = 1
    count = 0
    while degenerate == 1:
        sample = random.sample(list(x), s)
        degenerate = 0
        M = Fittingfn.fittingfn(sample)

        # if np.sum(np.sum(M==0))==9:
        #     degenerate = 1

        count = count + 1
        if count > maxDataTrials:
            print('Unable to select a nondegenerate data set')
            break

    inliersResults = Distfn.distfn(M, x, t)
    inliers = inliersResults[0]
    ninliers = len(inliers)

    return M, inliers, ninliers