import random
import numpy as np
import Rescore
import Fittingfn
import Distfn

def resample(x, M, s, t, inliers, ninliers, nrtrials, maxit, low):

    i = 0
    while i < nrtrials:
        i = i + 1
        sample = random.sample(list(inliers), max(s, round(ninliers/4)))
        sample = np.array(sample)
        # sample = random.sample(list(inliers), s)
        H = Fittingfn.fittingfn(sample)
        inlResutlts = Distfn.distfn(H, x, t)
        inl = inlResutlts[0]
        if len(inl)>low:
            H, inl, ntinliers = Rescore.rescore(x, s, t, inl, maxit, low)

            # Do we have a better set?!
            if ntinliers > ninliers:
                M = H
                ninliers = ntinliers
                inliers = inl
                i = 0

    return M, inliers, ninliers