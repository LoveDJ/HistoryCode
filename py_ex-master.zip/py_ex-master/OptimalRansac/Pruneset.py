import numpy as np
import Fittingfn
import Distfn

def pruneset(H, x, t, acc, low):
    length = len(x)

    repeat = 1

    while length > low and repeat ==1:
        inliers, d2 = Distfn.distfn(H, x, t)

        # remove the most extreme point
        rc = np.argmax(d2)
        t1 = max(d2)

        if t1 > acc and length - 1 > low:
            x = np.delete(x, rc, axis=0)
            H = Fittingfn.fittingfn(x)
        else:
            repeat = 0

        length = len(x)

    return H, x, length