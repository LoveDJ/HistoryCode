import numpy as np
import random
import Fittingfn
import Distfn

def rescore(x, s, t, inl, maxit, low):
    j = 0
    npinliers = len(inl)
    pinl = inl

    while j < maxit:
        j = j + 1

        M = Fittingfn.fittingfn(inl)
        inlResutls = Distfn.distfn(M, x, t)
        inl = inlResutls[0]
        ntinliers = len(inl)

        if ntinliers > low:
            if ntinliers != npinliers:
                npinliers = ntinliers
                pinl = inl
            elif not (pinl - inl).all() and len(pinl) == ntinliers:
                # The set is not changing after
                # re-rstimation. We are done!
                j = maxit
        else:
            j = maxit


    return M, inl, ntinliers