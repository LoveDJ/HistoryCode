import numpy as np

def distfn(M , x, t):
    a = M[0]
    b = M[1]
    c = M[2]

    comn = np.sqrt(np.square(a) + np.square(b) + np.square(c))
    dist = []
    inliers = []
    for point in x:
        d = np.abs(a * point[0] + b * point[1] + c * point[2] - 1) / comn
        if d < t:
            dist.append(d)
            inliers.append(point)

    inliers = np.array(inliers)
    dist = np.array(dist)
    return inliers, dist