import numpy as np
from sympy import *


def fittingfn(x):
    if len(x)==3:
        point_1 = x[0]
        point_2 = x[1]
        point_3 = x[2]
        a = Symbol('a')
        b = Symbol('b')
        c = Symbol('c')
        result = solve([point_1[0] * a + point_1[1] * b + point_1[2] * c - 1,
                        point_2[0] * a + point_2[1] * b + point_2[2] * c - 1,
                        point_3[0] * a + point_3[1] * b + point_3[2] * c - 1, ], [a, b, c])

        a = float(result[a])
        b = float(result[b])
        c = float(result[c])
    elif len(x) > 3:
        x_vector = x[:, 0]
        y_vector = x[:, 1]
        z_vector = x[:, 2]

        A11 = np.sum(x_vector * x_vector)
        A12 = np.sum(x_vector * y_vector)
        A13 = np.sum(x_vector)

        A21 = A12
        A22 = np.sum(y_vector * y_vector)
        A23 = np.sum(y_vector)

        A31 = A13
        A32 = A23
        A33 = len(x)

        B1 = np.sum(x_vector * z_vector)
        B2 = np.sum(y_vector * z_vector)
        B3 = np.sum(z_vector)

        a = Symbol('a')
        b = Symbol('b')
        c = Symbol('c')
        result = solve([A11 * a + A12 * b + A13 * c - B1,
                        A21 * a + A22 * b + A23 * c - B2,
                        A31 * a + A32 * b + A33 * c - B3,
                        ], [a, b, c])

        try:
            a = float(result[a])
            b = float(result[b])
            c = float(result[c])

            ct = 1 / c
            at = -a * ct
            bt = -b * ct


            a = at
            b = bt
            c = ct

        except Exception:
            print('error occur....')

    return [a, b, c]
