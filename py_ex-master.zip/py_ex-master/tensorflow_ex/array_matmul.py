import tensorflow as tf

para = tf.constant(2, shape=[4, 1, 9])
para = tf.reshape(para, shape=[4, 1, 3, 3])
para = tf.tile(para, multiples=[1, 100, 1, 1])  # 4*100*3*3

ray = tf.constant(3, shape=[4, 3, 100])
ray = tf.expand_dims(ray, 1) # 4*1*3*100
ray = tf.transpose(ray, perm=[0, 3, 1, 2]) # 4*100*1*3
result = tf.matmul(ray, para)

with tf.Session() as sess:
    sess.run([para, ray, result])
